"""
Aetheria Story Engine
=====================
Template-driven narrative chapters, world state management, and chronicle
logging. Called by bot.py whenever world-shaping events occur.

No LLM required — the engine selects and fills narrative templates that read
as genuine in-world prose.
"""

import json
import random
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# ── File paths ──────────────────────────────────────────────────────────────

_BASE          = Path(__file__).parent / "data"
WORLD_STATE_FILE  = _BASE / "world_state.json"
STORY_FILE        = _BASE / "story_history.json"
CHRONICLE_FILE    = _BASE / "chronicle.json"

# ── Default world state ─────────────────────────────────────────────────────

DEFAULT_WORLD_STATE: dict[str, Any] = {
    "current_age":    "Age of Heroes",
    "ruler_valoria":  None,
    "ruler_umbra":    None,
    "alive_bosses":   ["Ignaroth", "Astralion", "Umbryx", "Glacerius", "Tempestus"],
    "dead_bosses":    [],
    "active_wars":    [],
    "completed_wars": [],
    "city_control":   {
        "Valoria": None,
        "Umbra":   None,
    },
    "last_updated": None,
}

# ── Persistence ─────────────────────────────────────────────────────────────

def load_world_state() -> dict:
    if WORLD_STATE_FILE.exists():
        with open(WORLD_STATE_FILE) as f:
            return json.load(f)
    return dict(DEFAULT_WORLD_STATE)

def save_world_state(data: dict) -> None:
    data["last_updated"] = datetime.now(timezone.utc).isoformat()
    WORLD_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(WORLD_STATE_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def load_story_history() -> list:
    if STORY_FILE.exists():
        with open(STORY_FILE) as f:
            return json.load(f)
    return []

def save_story_history(data: list) -> None:
    STORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STORY_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def load_chronicle() -> list:
    if CHRONICLE_FILE.exists():
        with open(CHRONICLE_FILE) as f:
            return json.load(f)
    return []

def save_chronicle(data: list) -> None:
    CHRONICLE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CHRONICLE_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# ── Narrative templates ─────────────────────────────────────────────────────
# Each list holds multiple variants; the engine picks one at random.

_BOSS_DEATH: dict[str, list[str]] = {
    "Ignaroth": [
        "The volcano fell silent for the first time in living memory. **{killer}** stood at the summit, blade still burning, as **Ignaroth the Eternal Flame** let out its final roar and crumbled to cinders. The Age of Fire has drawn one step closer to its end.",
        "Smoke choked the sky above the Ember Peaks as **Ignaroth** fell. **{killer}** drove their weapon through the dragon's molten heart, and for a breathless moment the world grew cold. The gods of fire wept. The heroes of Aetheria cheered.",
    ],
    "Astralion": [
        "Stars flickered and died in the eastern sky as **Astralion, Warden of the Void**, was slain by **{killer}**. The celestial plane shuddered. Scholars across Aetheria abandoned their books and ran to their telescopes, unsure whether to record a triumph or a catastrophe.",
        "The rift between worlds sealed itself the instant **Astralion** drew its last breath. **{killer}** emerged from the astral plane scorched and trembling, carrying the Warden's crystallised eye as proof. Aetheria sleeps safely tonight — but at what cost?",
    ],
    "Umbryx": [
        "The shadow over the Hollow Wastes lifted at dawn. **Umbryx the Devourer of Light** has been slain by **{killer}**, and with it three centuries of cursed darkness have ended. Children who have never seen a proper sunrise finally beheld one.",
        "**{killer}** descended into the heart of the Voidspire and emerged alone. **Umbryx** is dead. The creature that had consumed eleven heroes before them is nothing but a stain on the stone. Light returns to the wastes. The cost was enormous.",
    ],
    "Glacerius": [
        "The Frosted Citadel collapsed at noon as **Glacerius the Undying Winter** was finally put down by **{killer}**. The eternal blizzard that had buried the northern passes for forty years is already beginning to thaw. Trade routes lost to ice may open again within the season.",
        "They said Glacerius could not die — that the cold itself was its lifeblood. **{killer}** proved them wrong. The blizzard died with the beast. Survivors of the northern villages are already emerging from their shelters, blinking in unfamiliar sunlight.",
    ],
    "Tempestus": [
        "The great storm that had circled the Stormspire for a generation dissipated within an hour of **Tempestus** falling to **{killer}**. Sailors who had avoided the cursed sea for decades are already adjusting their charts. A new route to the Eastern Continent is now possible.",
        "Thunder rolled across all of Aetheria when **Tempestus** died. **{killer}** struck the final blow from the eye of the hurricane — an act that sailors' songs will immortalise for a thousand years. The sky above the Stormspire is clear for the first time in recorded history.",
    ],
}

_BOSS_DEATH_GENERIC = [
    "A tremor rolled through Aetheria as **{boss}** drew its last breath. **{killer}** stood victorious where countless others had fallen. The creature's death sends ripples through the world's balance of power — what emerges to fill the void remains to be seen.",
    "The world is a slightly safer place today. **{boss}** has been slain by **{killer}**, ending a reign of terror that had cost Aetheria dearly. The body is still warm. The legends have already begun.",
]

_CITY_CONQUEST = [
    "**{city}** has fallen to **{conqueror}**. The old banners were torn down before noon; new ones flew by sunset. Citizens watch the streets with cautious eyes, uncertain what the change of power will bring. The history of Aetheria turns another page.",
    "The gates of **{city}** opened — or were broken open — before the forces of **{conqueror}**. Control of the city passes to new hands. Merchants adjust their loyalties. The previous rulers have gone underground, or fled, or worse.",
    "**{conqueror}** has taken **{city}** and declared sovereignty. The conquest was neither swift nor bloodless, but it is complete. The political map of Aetheria must be redrawn.",
]

_WAR_START = [
    "War has been declared. **{guild_a}** and **{guild_b}** have forsaken diplomacy. The border skirmishes that began as rumours are now open conflict. Heroes on both sides are choosing their allegiances. The first battles will begin soon.",
    "The drumbeats have started. A state of war now exists between **{guild_a}** and **{guild_b}**. Both factions are mobilising forces. Neutral territories are bracing for the shockwave. This conflict will reshape the balance of power in Aetheria.",
    "Negotiations between **{guild_a}** and **{guild_b}** have collapsed entirely. Envoys have been recalled. Weapons have been drawn. The war that many feared — and some hoped for — has begun.",
]

_WAR_END = [
    "The conflict between **{guild_a}** and **{guild_b}** has ended. **{winner}** emerged victorious. The terms of peace are being negotiated, but the cost on both sides was immense. The scars of this war will linger long after the last sword is sheathed.",
    "**{winner}** has prevailed. The war is over. **{loser}** has accepted defeat, and the fighting has stopped — for now. Whether this peace holds depends on what concessions are made and what grudges are left to fester.",
    "Silence falls over the battlefield where **{guild_a}** and **{guild_b}** clashed for so long. **{winner}** stands in the ashes of victory. Aetheria exhales. The rebuilding begins.",
]

_RULER_CHANGE = [
    "Power in **{realm}** passes to **{new_ruler}**. The throne has changed hands before, but never under quite these circumstances. Citizens wait to see whether this new era brings prosperity or simply a different kind of struggle.",
    "**{new_ruler}** has claimed dominion over **{realm}**. Loyal servants of the former ruler have scattered. The court is already shifting its allegiances. What kind of ruler **{new_ruler}** will be — fair or tyrannical — only time will reveal.",
    "A new name echoes through the halls of power in **{realm}**: **{new_ruler}**. Whether by conquest, election, or inheritance, the transition is complete. The realm watches and waits.",
]

_WORLD_EVENT_COMPLETE = [
    "The upheaval surrounding **{event}** has finally subsided. Heroes who were present tell dramatically different accounts of what truly happened. The Chronicles will have to reconcile them. What is certain is that Aetheria has been changed.",
    "**{event}** has run its course. The world returns to an uneasy normalcy, though nothing is quite the same as it was before. Those who lived through it will carry the memory for the rest of their lives.",
    "The age of **{event}** is over. Its effects — on the land, the people, and the balance of power — will ripple outward for years. The Chronicles record it as a turning point. Future generations will argue about whether it was.",
]

# ── Chapter generation ───────────────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def _chapter_entry(event_type: str, title: str, text: str, data: dict | None = None) -> dict:
    return {
        "event_type": event_type,
        "title":      title,
        "text":       text,
        "timestamp":  _now_iso(),
        "data":       data or {},
    }

def on_boss_death(boss_name: str, killer_name: str) -> dict:
    """Generate a story chapter and update world state when a boss is slain."""
    templates = _BOSS_DEATH.get(boss_name, _BOSS_DEATH_GENERIC)
    text = random.choice(templates).format(boss=boss_name, killer=killer_name)
    title = f"⚔️ The Fall of {boss_name}"

    ws = load_world_state()
    if boss_name in ws.get("alive_bosses", []):
        ws["alive_bosses"].remove(boss_name)
    if boss_name not in ws.get("dead_bosses", []):
        ws["dead_bosses"].append(boss_name)
    save_world_state(ws)

    chapter = _chapter_entry("boss_death", title, text, {"boss": boss_name, "killer": killer_name})
    history = load_story_history()
    history.append(chapter)
    save_story_history(history)
    return chapter


def on_city_conquest(city: str, conqueror: str) -> dict:
    """Generate a chapter and update world state when a city changes hands."""
    text  = random.choice(_CITY_CONQUEST).format(city=city, conqueror=conqueror)
    title = f"🏰 {conqueror} Conquers {city}"

    ws = load_world_state()
    ws.setdefault("city_control", {})[city] = conqueror
    if city == "Valoria":
        ws["ruler_valoria"] = conqueror
    elif city == "Umbra":
        ws["ruler_umbra"] = conqueror
    save_world_state(ws)

    chapter = _chapter_entry("city_conquest", title, text, {"city": city, "conqueror": conqueror})
    history = load_story_history()
    history.append(chapter)
    save_story_history(history)
    return chapter


def on_war_start(guild_a: str, guild_b: str) -> dict:
    """Generate a chapter when a guild war begins."""
    text  = random.choice(_WAR_START).format(guild_a=guild_a, guild_b=guild_b)
    title = f"⚔️ War Declared: {guild_a} vs {guild_b}"

    ws = load_world_state()
    war = {"parties": [guild_a, guild_b], "started": _now_iso()}
    ws.setdefault("active_wars", []).append(war)
    save_world_state(ws)

    chapter = _chapter_entry("war_start", title, text, {"guild_a": guild_a, "guild_b": guild_b})
    history = load_story_history()
    history.append(chapter)
    save_story_history(history)
    return chapter


def on_war_end(guild_a: str, guild_b: str, winner: str) -> dict:
    """Generate a chapter and archive the war when it ends."""
    loser = guild_b if winner == guild_a else guild_a
    text  = random.choice(_WAR_END).format(guild_a=guild_a, guild_b=guild_b, winner=winner, loser=loser)
    title = f"🏆 War Resolved: {winner} Victorious"

    ws = load_world_state()
    ws["active_wars"] = [
        w for w in ws.get("active_wars", [])
        if set(w.get("parties", [])) != {guild_a, guild_b}
    ]
    ws.setdefault("completed_wars", []).append({
        "parties": [guild_a, guild_b],
        "winner":  winner,
        "ended":   _now_iso(),
    })
    save_world_state(ws)

    chapter = _chapter_entry("war_end", title, text, {"guild_a": guild_a, "guild_b": guild_b, "winner": winner})
    history = load_story_history()
    history.append(chapter)
    save_story_history(history)
    return chapter


def on_ruler_change(realm: str, new_ruler: str) -> dict:
    """Generate a chapter when a realm gets a new ruler."""
    text  = random.choice(_RULER_CHANGE).format(realm=realm, new_ruler=new_ruler)
    title = f"👑 New Ruler of {realm}: {new_ruler}"

    ws = load_world_state()
    if realm == "Valoria":
        ws["ruler_valoria"] = new_ruler
    elif realm == "Umbra":
        ws["ruler_umbra"] = new_ruler
    save_world_state(ws)

    chapter = _chapter_entry("ruler_change", title, text, {"realm": realm, "new_ruler": new_ruler})
    history = load_story_history()
    history.append(chapter)
    save_story_history(history)
    return chapter


def on_world_event(event_title: str) -> dict:
    """Generate a short chapter when a scheduled world event concludes."""
    text  = random.choice(_WORLD_EVENT_COMPLETE).format(event=event_title)
    title = f"🌍 World Event Concluded: {event_title}"

    chapter = _chapter_entry("world_event", title, text, {"event": event_title})
    history = load_story_history()
    history.append(chapter)
    save_story_history(history)
    return chapter


# ── Chronicle logging ────────────────────────────────────────────────────────

_CHRONICLE_EMOJIS: dict[str, str] = {
    "boss_kill":           "⚔️",
    "level_milestone":     "⬆️",
    "hidden_class":        "✦",
    "guild_created":       "🏰",
    "guild_challenge_win": "🏆",
    "city_conquest":       "👑",
    "story_chapter":       "📖",
    "world_event":         "🌍",
    "player_joined":       "🌟",
    "custom":              "📜",
}

def log_chronicle(entry_type: str, description: str, data: dict | None = None) -> dict:
    """Append a new entry to the chronicle and return it."""
    entry = {
        "type":        entry_type,
        "emoji":       _CHRONICLE_EMOJIS.get(entry_type, "📜"),
        "description": description,
        "timestamp":   _now_iso(),
        "data":        data or {},
    }
    chronicle = load_chronicle()
    chronicle.append(entry)
    save_chronicle(chronicle)
    return entry


def world_state_embed_fields() -> list[dict]:
    """Return a list of {name, value} pairs for a Discord embed showing world state."""
    ws = load_world_state()
    fields = [
        {"name": "🌍 Current Age",         "value": ws.get("current_age", "Unknown")},
        {"name": "👑 Ruler of Valoria",    "value": ws.get("ruler_valoria") or "*Vacant*"},
        {"name": "👑 Ruler of Umbra",      "value": ws.get("ruler_umbra")   or "*Vacant*"},
        {"name": "🐉 Alive World Bosses",  "value": "\n".join(ws.get("alive_bosses", [])) or "*None*"},
        {"name": "💀 Slain World Bosses",  "value": "\n".join(ws.get("dead_bosses",  [])) or "*None*"},
    ]
    active = ws.get("active_wars", [])
    if active:
        wars_str = "\n".join(f"{w['parties'][0]} vs {w['parties'][1]}" for w in active)
        fields.append({"name": "⚔️ Active Wars", "value": wars_str})
    return fields
