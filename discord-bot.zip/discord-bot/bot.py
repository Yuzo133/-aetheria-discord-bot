"""
Aetheria Online — Discord RPG Bot
Full-featured RPG bot with character creation, levelling, inventory,
daily rewards, and auto-updated character sheets.
"""

import discord
from discord import app_commands
from discord.ui import View, Select
from discord.ext import tasks
import json
import os
import random
from datetime import datetime, timezone, timedelta
from pathlib import Path
import story_engine as se
import npc_engine as npc_eng

# ── File paths ─────────────────────────────────────────────────────────────────
DATA_FILE = Path(__file__).parent / "data" / "players.json"
DATA_FILE.parent.mkdir(parents=True, exist_ok=True)

# ── Constants ──────────────────────────────────────────────────────────────────
LEVEL_CAP = 100
XP_BASE = 100          # XP required from level 1→2
XP_SCALE = 1.15        # 15% more XP per level
DAILY_COOLDOWN_H = 24
SHEET_CHANNEL       = "charakter-blaetter"
CHRONICLE_CHANNEL   = "weltchronik"
GUILDS_FILE         = Path(__file__).parent / "data" / "guilds.json"
MAX_GUILD_NAME_LEN  = 30
MAX_GUILD_MEMBERS   = 50

# Daily reward tables
DAILY_XP = (30, 80)
DAILY_GOLD = (50, 200)
DAILY_ITEMS = [
    ("Health Potion", 0.40),
    ("Mana Potion", 0.30),
    ("Elixir of Fortune", 0.10),
    ("Ancient Rune", 0.05),
    ("Shadow Essence", 0.08),
    ("Dragon Scale Fragment", 0.07),
]

# ── Race definitions ───────────────────────────────────────────────────────────
# Stats: STR, DEF, AGI, MAG, HP
RACES: dict[str, dict] = {
    "Human":       {"str": 10, "def": 10, "agi": 10, "mag": 10, "hp": 100, "emoji": "🧑", "lore": "Versatile and adaptable, Humans thrive in any role."},
    "Elf":         {"str": 8,  "def": 8,  "agi": 14, "mag": 13, "hp": 90,  "emoji": "🧝", "lore": "Graceful forest-dwellers with keen senses and natural magic."},
    "High Elf":    {"str": 6,  "def": 8,  "agi": 12, "mag": 18, "hp": 85,  "emoji": "✨", "lore": "Ancient masters of arcane arts, their magic is unrivalled."},
    "Dark Elf":    {"str": 9,  "def": 7,  "agi": 16, "mag": 14, "hp": 88,  "emoji": "🌑", "lore": "Shadowy and swift, Dark Elves excel in deception and shadow magic."},
    "Dwarf":       {"str": 13, "def": 16, "agi": 6,  "mag": 8,  "hp": 120, "emoji": "⛏️", "lore": "Sturdy mountain-folk with unmatched endurance and craftsmanship."},
    "Orc":         {"str": 16, "def": 12, "agi": 8,  "mag": 4,  "hp": 130, "emoji": "💚", "lore": "Raw power incarnate — Orcs dominate through sheer brute force."},
    "Kitsune":     {"str": 8,  "def": 7,  "agi": 13, "mag": 16, "hp": 88,  "emoji": "🦊", "lore": "Fox-spirits of ancient wisdom, wielding illusion and spirit magic."},
    "Neko":        {"str": 9,  "def": 8,  "agi": 17, "mag": 10, "hp": 90,  "emoji": "🐱", "lore": "Cat-folk blessed with supernatural reflexes and curious minds."},
    "Wolfman":     {"str": 14, "def": 10, "agi": 14, "mag": 6,  "hp": 110, "emoji": "🐺", "lore": "Half-wolf warriors who grow deadlier under the moonlight."},
    "Vampire":     {"str": 11, "def": 9,  "agi": 14, "mag": 14, "hp": 95,  "emoji": "🧛", "lore": "Immortal hunters of the night, blending strength with dark sorcery."},
    "Demon":       {"str": 14, "def": 10, "agi": 10, "mag": 14, "hp": 105, "emoji": "😈", "lore": "Born of hellfire — Demons channel infernal power without restraint."},
    "Angel":       {"str": 8,  "def": 12, "agi": 10, "mag": 16, "hp": 100, "emoji": "😇", "lore": "Celestial beings radiating divine magic and protective light."},
    "Drakonian":   {"str": 14, "def": 14, "agi": 10, "mag": 10, "hp": 115, "emoji": "🐉", "lore": "Dragon-blooded warriors armoured in scales, breathing destruction."},
    "Fairy":       {"str": 5,  "def": 6,  "agi": 14, "mag": 18, "hp": 80,  "emoji": "🧚", "lore": "Tiny yet devastating wielders of wild, unpredictable fae magic."},
    "Titanblood":  {"str": 18, "def": 18, "agi": 6,  "mag": 6,  "hp": 140, "emoji": "⚡", "lore": "Descendants of giants — living fortresses of immovable strength."},
}

# ── Class definitions ──────────────────────────────────────────────────────────
# Bonus stats on top of race base
CLASSES: dict[str, dict] = {
    "Warrior":     {"str": 5,  "def": 4,  "agi": 1,  "mag": 0,  "hp": 20,  "emoji": "⚔️",  "lore": "Masters of melee combat who lead from the front."},
    "Mage":        {"str": 0,  "def": 1,  "agi": 2,  "mag": 7,  "hp": 0,   "emoji": "🔮",  "lore": "Scholars of arcane power who bend reality with spells."},
    "Assassin":    {"str": 3,  "def": 0,  "agi": 7,  "mag": 0,  "hp": 5,   "emoji": "🗡️",  "lore": "Silent blades operating from the shadows."},
    "Ranger":      {"str": 2,  "def": 2,  "agi": 6,  "mag": 0,  "hp": 10,  "emoji": "🏹",  "lore": "Wilderness experts striking from a distance with precision."},
    "Paladin":     {"str": 3,  "def": 5,  "agi": 0,  "mag": 3,  "hp": 15,  "emoji": "🛡️",  "lore": "Holy warriors fusing divine magic with martial prowess."},
    "Necromancer": {"str": 0,  "def": 1,  "agi": 1,  "mag": 8,  "hp": -5,  "emoji": "💀",  "lore": "Dark mages who command the dead and drain life force."},
    "Summoner":    {"str": 0,  "def": 2,  "agi": 2,  "mag": 6,  "hp": 5,   "emoji": "🌀",  "lore": "Conjurers who call powerful beings from other realms."},
    "Berserker":   {"str": 8,  "def": 2,  "agi": 3,  "mag": 0,  "hp": 25,  "emoji": "🪓",  "lore": "Rage-fuelled destroyers with no regard for their own safety."},
}

# ── Tier colours ───────────────────────────────────────────────────────────────
def level_tier(level: int) -> tuple[str, int]:
    if level >= 90: return "Legendary ✦", 0xFF9800
    if level >= 70: return "Epic ◆",      0x9C27B0
    if level >= 45: return "Rare ★",      0x2196F3
    if level >= 20: return "Uncommon ●",  0x4CAF50
    return              "Common ○",       0x9E9E9E

# ── Persistence ────────────────────────────────────────────────────────────────

def load_players() -> dict:
    if DATA_FILE.exists():
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {}

def save_players(data: dict):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# ── Player creation & stats ────────────────────────────────────────────────────

def compute_stats(race: str, cls: str, level: int, origin_class: str | None = None, train_bonuses: dict | None = None) -> dict:
    r = RACES[race]
    # Hidden classes aren't in CLASSES — fall back to the origin class, or zeros
    _ZERO = {"str": 0, "def": 0, "agi": 0, "mag": 0, "hp": 0}
    c  = CLASSES.get(cls) or CLASSES.get(origin_class or "", _ZERO)
    tb = train_bonuses or {}
    lvl_bonus = (level - 1) * 2
    return {
        "str": r["str"] + c["str"] + lvl_bonus + tb.get("str", 0),
        "def": r["def"] + c["def"] + lvl_bonus + tb.get("def", 0),
        "agi": r["agi"] + c["agi"] + lvl_bonus + tb.get("agi", 0),
        "mag": r["mag"] + c["mag"] + lvl_bonus + tb.get("mag", 0),
        "hp":  r["hp"]  + c["hp"]  + lvl_bonus * 5 + tb.get("hp", 0),
    }

def new_player(uid: str, username: str, race: str, cls: str) -> dict:
    return {
        "id": uid,
        "username": username,
        "race": race,
        "class": cls,
        "level": 1,
        "xp": 0,
        "gold": 100,
        "inventory": {"Health Potion": 2},
        "faction": None,
        "titles": [],
        "abilities": [],
        "train_bonuses": {"str": 0, "def": 0, "agi": 0, "mag": 0, "hp": 0},
        "last_daily": None,
        "sheet_message_id": None,   # per-guild; keyed by guild_id str
        "sheet_messages": {},        # {guild_id: message_id}
        "created_at": datetime.now(timezone.utc).isoformat(),
    }

# ── Levelling ──────────────────────────────────────────────────────────────────

def xp_for_next(level: int) -> int:
    return int(XP_BASE * (XP_SCALE ** (level - 1)))

def add_xp(player: dict, amount: int) -> list[int]:
    if player["level"] >= LEVEL_CAP:
        return []
    player["xp"] += amount
    gained = []
    while player["level"] < LEVEL_CAP:
        needed = xp_for_next(player["level"])
        if player["xp"] >= needed:
            player["xp"] -= needed
            player["level"] += 1
            gained.append(player["level"])
        else:
            break
    return gained

def xp_bar(current: int, total: int, length: int = 12) -> str:
    filled = int(length * current / total) if total else 0
    return "[" + "█" * filled + "░" * (length - filled) + "]"

# ── Inventory helpers ──────────────────────────────────────────────────────────

def add_item(player: dict, item: str, qty: int = 1):
    inv = player.setdefault("inventory", {})
    inv[item] = inv.get(item, 0) + qty

def remove_item(player: dict, item: str, qty: int = 1) -> bool:
    inv = player.get("inventory", {})
    if inv.get(item, 0) < qty:
        return False
    inv[item] -= qty
    if inv[item] == 0:
        del inv[item]
    return True

# ── Character sheet embed ──────────────────────────────────────────────────────

def build_sheet_embed(player: dict, member: discord.Member | None = None) -> discord.Embed:
    race        = player["race"]
    cls         = player["class"]
    level       = player["level"]
    origin_cls  = player.get("origin_class")        # set when hidden class unlocked
    hidden_cls  = player.get("hidden_class")         # name of the hidden class, or None

    tier_label, tier_color = level_tier(level)
    stats  = compute_stats(race, cls, level, origin_cls, player.get("train_bonuses"))
    r_data = RACES[race]

    # ── Hidden-class variant ────────────────────────────────────────────────
    if hidden_cls and hidden_cls in HIDDEN_CLASSES:
        hc     = HIDDEN_CLASSES[hidden_cls]
        color  = hc["color"]
        origin = CLASSES.get(origin_cls or "", {})
        origin_emoji = origin.get("emoji", "⚔️")

        embed = discord.Embed(
            title=f"{r_data['emoji']}  {player['username']}",
            description=(
                f"**{r_data['emoji']} {race}**\n"
                f"✦  **{hc['emoji']} {hidden_cls}**  ✦\n"
                f"*{tier_label} — Legendary*"
            ),
            color=color,
        )

        if member:
            embed.set_thumbnail(url=member.display_avatar.url)

        # Progress
        if level < LEVEL_CAP:
            needed  = xp_for_next(level)
            bar     = xp_bar(player["xp"], needed)
            xp_str  = f"Level **{level}** / {LEVEL_CAP}\n{bar} `{player['xp']:,} / {needed:,} XP`"
        else:
            xp_str  = f"Level **{LEVEL_CAP}** / {LEVEL_CAP}  👑  **MAX LEVEL**"
        embed.add_field(name="⚔️ Progress", value=xp_str, inline=False)

        # Stats — label them as "Transcendent"
        embed.add_field(
            name="📊 Stats  *(Transcendent)*",
            value=(
                f"❤️ HP  `{stats['hp']:>4}`\n"
                f"💪 STR `{stats['str']:>4}`\n"
                f"🛡️ DEF `{stats['def']:>4}`\n"
                f"💨 AGI `{stats['agi']:>4}`\n"
                f"✨ MAG `{stats['mag']:>4}`"
            ),
            inline=True,
        )

        # Economy
        inv      = player.get("inventory", {})
        inv_lines = "\n".join(f"`{qty}×` {item}" for item, qty in inv.items()) or "*Empty*"
        embed.add_field(name="💰 Economy", value=f"🪙 Gold: **{player['gold']:,}**", inline=True)
        embed.add_field(name="🎒 Inventory", value=inv_lines, inline=False)

        # Hidden class badge — the star of the show
        embed.add_field(
            name=f"╔══ {hc['emoji']}  HIDDEN CLASS  {hc['emoji']} ══╗",
            value=(
                f"**{hidden_cls}**\n"
                f"{hc['lore']}\n\n"
                f"*\"{hc['reveal']}\"*"
            ),
            inline=False,
        )

        # Origin (former class shown subtly)
        if origin_cls:
            embed.add_field(
                name=f"{origin_emoji} Origin",
                value=f"Formerly a **{origin_cls}** — until fate called.",
                inline=True,
            )

        embed.add_field(name=f"{r_data['emoji']} Race", value=r_data["lore"], inline=False)
        embed.set_footer(
            text=f"✦ One of the rarest beings in Aetheria  •  Updated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')} UTC"
        )
        return embed

    # ── Normal class variant (unchanged) ────────────────────────────────────
    c_data = CLASSES.get(cls, {"emoji": "⚔️", "lore": ""})
    color  = tier_color

    embed = discord.Embed(
        title=f"{r_data['emoji']} {player['username']}",
        description=(
            f"**{r_data['emoji']} {race}**  |  **{c_data['emoji']} {cls}**\n"
            f"*Tier: {tier_label}*"
        ),
        color=color,
    )

    if member:
        embed.set_thumbnail(url=member.display_avatar.url)

    # Level & XP
    if level < LEVEL_CAP:
        needed = xp_for_next(level)
        bar    = xp_bar(player["xp"], needed)
        xp_str = f"Level **{level}** / {LEVEL_CAP}\n{bar} `{player['xp']:,} / {needed:,} XP`"
    else:
        xp_str = f"Level **{LEVEL_CAP}** / {LEVEL_CAP}  👑  **MAX LEVEL**"

    embed.add_field(name="⚔️ Progress", value=xp_str, inline=False)

    embed.add_field(
        name="📊 Stats",
        value=(
            f"❤️ HP  `{stats['hp']:>4}`\n"
            f"💪 STR `{stats['str']:>4}`\n"
            f"🛡️ DEF `{stats['def']:>4}`\n"
            f"💨 AGI `{stats['agi']:>4}`\n"
            f"✨ MAG `{stats['mag']:>4}`"
        ),
        inline=True,
    )

    inv      = player.get("inventory", {})
    inv_lines = "\n".join(f"`{qty}×` {item}" for item, qty in inv.items()) or "*Empty*"
    embed.add_field(name="💰 Economy",   value=f"🪙 Gold: **{player['gold']:,}**", inline=True)
    embed.add_field(name="🎒 Inventory", value=inv_lines, inline=False)
    embed.add_field(name=f"{r_data['emoji']} Race",  value=r_data["lore"], inline=False)
    embed.add_field(name=f"{c_data['emoji']} Class", value=c_data["lore"], inline=False)

    faction = player.get("faction")
    if faction:
        embed.add_field(name="⚑ Faction", value=faction, inline=True)
    titles = player.get("titles", [])
    if titles:
        embed.add_field(name="🏅 Titles", value=" • ".join(titles), inline=False)
    abilities = player.get("abilities", [])
    if abilities:
        embed.add_field(name="⚡ Abilities", value=" • ".join(abilities), inline=False)
    # Active mount
    try:
        _m_data = npc_eng.get_player_mounts(player.get("id", ""))
        _active = _m_data.get("active")
        if _active and _active in npc_eng.MOUNT_REGISTRY:
            _m = npc_eng.MOUNT_REGISTRY[_active]
            embed.add_field(name="🐎 Mount", value=f"{_m['emoji']} {_active}", inline=True)
    except Exception:
        pass
    embed.set_footer(text=f"Aetheria Online • Updated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')} UTC")
    return embed

# ── Auto-update character sheet in #charakter-blaetter ────────────────────────

async def update_character_sheet(bot: discord.Client, player: dict, member: discord.Member):
    guild = member.guild
    if guild is None:
        return

    channel = discord.utils.get(guild.text_channels, name=SHEET_CHANNEL)
    if channel is None:
        return

    embed = build_sheet_embed(player, member)
    gid = str(guild.id)
    msg_id = player.get("sheet_messages", {}).get(gid)

    try:
        if msg_id:
            try:
                msg = await channel.fetch_message(int(msg_id))
                await msg.edit(embed=embed)
                return
            except discord.NotFound:
                pass  # message was deleted, post a new one

        new_msg = await channel.send(embed=embed)
        player.setdefault("sheet_messages", {})[gid] = str(new_msg.id)
    except discord.Forbidden:
        pass  # bot lacks permissions — silently skip

# ── Character creation Views ───────────────────────────────────────────────────

class RaceSelect(Select):
    def __init__(self):
        # Discord select menus support max 25 options; we have 15 races — fine
        options = [
            discord.SelectOption(
                label=f"{data['emoji']} {race}",
                value=race,
                description=data["lore"][:100],
            )
            for race, data in RACES.items()
        ]
        super().__init__(placeholder="Choose your race…", options=options, custom_id="race_select")

    async def callback(self, interaction: discord.Interaction):
        self.view.chosen_race = self.values[0]
        for item in self.view.children:
            item.disabled = True
        self.view.stop()
        await interaction.response.edit_message(
            content=f"Race chosen: **{RACES[self.view.chosen_race]['emoji']} {self.view.chosen_race}**\nNow choose your class:",
            view=ClassView(self.view.chosen_race),
        )


class ClassSelect(Select):
    def __init__(self, race: str):
        self.race = race
        options = [
            discord.SelectOption(
                label=f"{data['emoji']} {cls}",
                value=cls,
                description=data["lore"][:100],
            )
            for cls, data in CLASSES.items()
        ]
        super().__init__(placeholder="Choose your class…", options=options, custom_id="class_select")

    async def callback(self, interaction: discord.Interaction):
        chosen_class = self.values[0]
        for item in self.view.children:
            item.disabled = True
        self.view.stop()

        await interaction.response.defer(thinking=True)

        data = load_players()
        uid = str(interaction.user.id)

        player = new_player(uid, interaction.user.display_name, self.race, chosen_class)
        data[uid] = player
        save_players(data)

        embed = build_sheet_embed(player, interaction.user if isinstance(interaction.user, discord.Member) else None)
        embed.title = f"🌟 Welcome to Aetheria, {interaction.user.display_name}!"

        await interaction.edit_original_response(content=None, embed=embed, view=None)

        # Post character sheet to #charakter-blaetter
        if isinstance(interaction.user, discord.Member):
            await update_character_sheet(interaction.client, player, interaction.user)
            save_players(data)  # save updated sheet_messages


class RaceView(View):
    def __init__(self):
        super().__init__(timeout=120)
        self.chosen_race: str | None = None
        self.add_item(RaceSelect())


class ClassView(View):
    def __init__(self, race: str):
        super().__init__(timeout=120)
        self.add_item(ClassSelect(race))


# ── Bot & command tree ─────────────────────────────────────────────────────────

intents = discord.Intents.default()
intents.members = True
bot = discord.Client(intents=intents)
tree = app_commands.CommandTree(bot)

# ── /create ────────────────────────────────────────────────────────────────────

@tree.command(name="create", description="Create your Aetheria Online character!")
async def cmd_create(interaction: discord.Interaction):
    data = load_players()
    uid = str(interaction.user.id)

    if uid in data:
        embed = discord.Embed(
            description=(
                f"⚔️  **{interaction.user.display_name}**, you already have a character!\n"
                "Use `/profile` to view it, or `/reroll` to start fresh (resets everything)."
            ),
            color=0xE67E22,
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    await interaction.response.send_message(
        content="**Welcome to Aetheria Online!**\nFirst, choose your **race**:",
        view=RaceView(),
        ephemeral=True,
    )

# ── /reroll ────────────────────────────────────────────────────────────────────

class ConfirmRerollView(View):
    def __init__(self):
        super().__init__(timeout=30)

    @discord.ui.button(label="Yes, reroll!", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.stop()
        data = load_players()
        uid = str(interaction.user.id)
        # Remove old sheet messages if possible
        old = data.get(uid)
        if old and isinstance(interaction.user, discord.Member):
            gid = str(interaction.guild_id)
            msg_id = old.get("sheet_messages", {}).get(gid)
            if msg_id:
                channel = discord.utils.get(interaction.guild.text_channels, name=SHEET_CHANNEL)
                if channel:
                    try:
                        msg = await channel.fetch_message(int(msg_id))
                        await msg.delete()
                    except Exception:
                        pass
        if uid in data:
            del data[uid]
        save_players(data)
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            content="Your character has been deleted. Use `/create` to start fresh!",
            view=self,
        )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.stop()
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(content="Reroll cancelled.", view=self)


@tree.command(name="reroll", description="Delete your character and start fresh. This cannot be undone!")
async def cmd_reroll(interaction: discord.Interaction):
    data = load_players()
    uid = str(interaction.user.id)
    if uid not in data:
        await interaction.response.send_message("You don't have a character yet. Use `/create`!", ephemeral=True)
        return
    await interaction.response.send_message(
        "⚠️  **Are you sure?** This will permanently delete your character and all progress.",
        view=ConfirmRerollView(),
        ephemeral=True,
    )

# ── /profile ───────────────────────────────────────────────────────────────────

@tree.command(name="profile", description="View your character profile.")
@app_commands.describe(user="Another player to inspect")
async def cmd_profile(interaction: discord.Interaction, user: discord.Member = None):
    target = user or interaction.user
    data = load_players()
    uid = str(target.id)

    if uid not in data:
        msg = "You haven't created a character yet! Use `/create`." if target == interaction.user else f"**{target.display_name}** hasn't created a character yet."
        await interaction.response.send_message(f"❌  {msg}", ephemeral=True)
        return

    player = data[uid]
    embed = build_sheet_embed(player, target)

    # Show daily cooldown
    if player.get("last_daily"):
        last = datetime.fromisoformat(player["last_daily"])
        nxt = last + timedelta(hours=DAILY_COOLDOWN_H)
        now = datetime.now(timezone.utc)
        if now >= nxt:
            daily_str = "✅  Ready!"
        else:
            rem = nxt - now
            h, r = divmod(int(rem.total_seconds()), 3600)
            daily_str = f"⏳  {h}h {r // 60}m"
    else:
        daily_str = "✅  Ready!"

    embed.add_field(name="📅 Daily Reward", value=daily_str, inline=True)
    await interaction.response.send_message(embed=embed)

# ── /daily ─────────────────────────────────────────────────────────────────────

@tree.command(name="daily", description="Claim your daily XP, gold, and a possible item drop!")
async def cmd_daily(interaction: discord.Interaction):
    data = load_players()
    uid = str(interaction.user.id)

    if uid not in data:
        await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
        return

    player = data[uid]
    now = datetime.now(timezone.utc)

    if player.get("last_daily"):
        last = datetime.fromisoformat(player["last_daily"])
        nxt = last + timedelta(hours=DAILY_COOLDOWN_H)
        if now < nxt:
            rem = nxt - now
            h, r = divmod(int(rem.total_seconds()), 3600)
            await interaction.response.send_message(
                f"⏳  You already claimed today's reward! Come back in **{h}h {r // 60}m**.",
                ephemeral=True,
            )
            return

    xp_gain   = random.randint(*DAILY_XP)
    gold_gain  = random.randint(*DAILY_GOLD)

    # ── Guild perk bonuses ─────────────────────────────────────────────────
    _guild_bonus_xp   = 0
    _guild_bonus_gold = 0
    _guild_perk_name  = ""
    _guilds_data = load_guilds()
    _gkey, _g = _player_guild(_guilds_data, uid)
    if _g:
        _gp = _g.get("perks", [])
        if "War Training" in _gp:
            _guild_bonus_xp   = int(xp_gain * 0.15)
        if "Merchant's Alliance" in _gp:
            _guild_bonus_gold = int(gold_gain * 0.20)
        if _guild_bonus_xp or _guild_bonus_gold:
            _guild_perk_name = _g["name"]
    xp_gain   += _guild_bonus_xp
    gold_gain += _guild_bonus_gold
    # ──────────────────────────────────────────────────────────────────────

    # Mount bonuses
    _mount_b = npc_eng.get_active_mount_bonuses(uid)
    if _mount_b["bonus_xp"]:
        xp_gain   += int(xp_gain   * _mount_b["bonus_xp"]   / 100)
    if _mount_b["bonus_gold"]:
        gold_gain += int(gold_gain * _mount_b["bonus_gold"] / 100)

    player["gold"] += gold_gain
    player["last_daily"] = now.isoformat()

    old_level = player["level"]
    levels = add_xp(player, xp_gain)

    # Random item drop
    roll = random.random()
    cumulative = 0.0
    dropped_item = None
    for item, chance in DAILY_ITEMS:
        cumulative += chance
        if roll < cumulative:
            dropped_item = item
            add_item(player, item)
            break

    save_players(data)

    _, color = level_tier(player["level"])
    embed = discord.Embed(
        title="🎁  Daily Reward Claimed!",
        description=f"Welcome back, **{interaction.user.display_name}**!",
        color=color,
    )
    embed.add_field(name="XP Earned",   value=f"+{xp_gain} XP ✨",   inline=True)
    embed.add_field(name="Gold Earned", value=f"+{gold_gain} 🪙",     inline=True)
    embed.add_field(name="Total Gold",  value=f"{player['gold']:,} 🪙", inline=True)
    if _guild_perk_name:
        bonus_parts = []
        if _guild_bonus_xp:   bonus_parts.append(f"+{_guild_bonus_xp} XP ⚔️ War Training")
        if _guild_bonus_gold: bonus_parts.append(f"+{_guild_bonus_gold} 🪙 Merchant's Alliance")
        embed.add_field(
            name=f"🔮 Guild Bonus ({_guild_perk_name})",
            value="\n".join(bonus_parts),
            inline=False,
        )

    if dropped_item:
        embed.add_field(name="📦 Item Drop!", value=f"You found a **{dropped_item}**!", inline=False)

    if levels:
        embed.add_field(
            name="⬆️  Level Up!",
            value="\n".join(f"🎉 **Level {lvl}** reached!" for lvl in levels),
            inline=False,
        )
        if player["level"] == LEVEL_CAP:
            embed.add_field(name="👑  LEGENDARY!", value="You've reached the max level — a true legend of Aetheria!", inline=False)
    else:
        if player["level"] < LEVEL_CAP:
            needed = xp_for_next(player["level"])
            embed.add_field(
                name=f"Progress to Level {player['level'] + 1}",
                value=f"{xp_bar(player['xp'], needed)} `{player['xp']:,} / {needed:,}`",
                inline=False,
            )

    embed.set_thumbnail(url=interaction.user.display_avatar.url)
    embed.set_footer(text="Aetheria Online • Come back in 24 hours!")
    await interaction.response.send_message(embed=embed)

    # Update character sheet + hidden class check
    if isinstance(interaction.user, discord.Member):
        await update_character_sheet(bot, player, interaction.user)
        if _check_hidden_class_conditions(player):
            await trigger_hidden_class(player, interaction.user, data)
        save_players(data)
        # Chronicle level milestones
        for lvl in levels:
            if lvl in (10, 25, 50, 75, LEVEL_CAP):
                _, tier_color = level_tier(lvl)
                m_embed = discord.Embed(
                    title=f"⬆️ Level {lvl} Milestone!",
                    description=(
                        f"**{interaction.user.display_name}** "
                        f"({player['race']} {player['class']}) has reached **Level {lvl}** in Aetheria!"
                    ),
                    color=tier_color,
                )
                m_embed.set_footer(text="Aetheria Chronicle • Level Milestone")
                await _post_to_chronicle(m_embed)
                se.log_chronicle(
                    "level_milestone",
                    f"{player['username']} reached Level {lvl}.",
                    {"level": lvl, "race": player["race"], "class": player["class"]},
                )

# ── /inventory ─────────────────────────────────────────────────────────────────

@tree.command(name="inventory", description="View your inventory.")
async def cmd_inventory(interaction: discord.Interaction):
    data = load_players()
    uid = str(interaction.user.id)

    if uid not in data:
        await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
        return

    player = data[uid]
    inv = player.get("inventory", {})
    _, color = level_tier(player["level"])

    embed = discord.Embed(
        title=f"🎒 {interaction.user.display_name}'s Inventory",
        color=color,
    )
    embed.add_field(name="🪙 Gold", value=f"{player['gold']:,}", inline=False)

    if inv:
        lines = "\n".join(f"`{qty:>3}×` **{item}**" for item, qty in sorted(inv.items()))
        embed.add_field(name="Items", value=lines, inline=False)
    else:
        embed.add_field(name="Items", value="*Your inventory is empty.*", inline=False)

    embed.set_thumbnail(url=interaction.user.display_avatar.url)
    embed.set_footer(text="Claim /daily for a chance at item drops!")
    await interaction.response.send_message(embed=embed)

# ── /stats ─────────────────────────────────────────────────────────────────────

@tree.command(name="stats", description="View your detailed combat statistics.")
@app_commands.describe(user="Another player to inspect")
async def cmd_stats(interaction: discord.Interaction, user: discord.Member = None):
    target = user or interaction.user
    data = load_players()
    uid = str(target.id)

    if uid not in data:
        await interaction.response.send_message("❌  That player hasn't created a character yet.", ephemeral=True)
        return

    player = data[uid]
    race  = player["race"]
    cls   = player["class"]
    level = player["level"]
    stats = compute_stats(race, cls, level)
    _, color = level_tier(level)

    r = RACES[race]
    c = CLASSES[cls]

    embed = discord.Embed(
        title=f"📊 {target.display_name} — Combat Stats",
        description=f"{r['emoji']} **{race}**  ·  {c['emoji']} **{cls}**  ·  Level **{level}**",
        color=color,
    )
    embed.set_thumbnail(url=target.display_avatar.url)

    def stat_bar(val: int, mx: int = 50) -> str:
        filled = min(int(10 * val / mx), 10)
        return "▰" * filled + "▱" * (10 - filled)

    for stat_name, key, emoji in [
        ("HP",       "hp",  "❤️"),
        ("Strength", "str", "💪"),
        ("Defense",  "def", "🛡️"),
        ("Agility",  "agi", "💨"),
        ("Magic",    "mag", "✨"),
    ]:
        val = stats[key]
        mx = 200 if key == "hp" else 60
        embed.add_field(
            name=f"{emoji} {stat_name}",
            value=f"`{val:>4}` {stat_bar(val, mx)}",
            inline=True,
        )

    embed.set_footer(text="Stats scale with level — keep grinding!")
    await interaction.response.send_message(embed=embed)

# ── /leaderboard ───────────────────────────────────────────────────────────────

@tree.command(name="leaderboard", description="View the top 10 heroes of Aetheria.")
async def cmd_leaderboard(interaction: discord.Interaction):
    data = load_players()
    if not data:
        await interaction.response.send_message("No heroes yet — be the first with `/create`!", ephemeral=True)
        return

    sorted_players = sorted(data.values(), key=lambda p: (p["level"], p["xp"]), reverse=True)[:10]

    embed = discord.Embed(title="🏆  Aetheria Online — Leaderboard", color=0xFFD700)

    medals = ["🥇", "🥈", "🥉"] + ["🔹"] * 7
    lines = []
    for i, p in enumerate(sorted_players):
        tier, _ = level_tier(p["level"])
        r = RACES.get(p["race"], {})
        c = CLASSES.get(p["class"], {})
        lines.append(
            f"{medals[i]} **{p['username']}**  {r.get('emoji','')} {p['race']} {c.get('emoji','')} {p['class']}\n"
            f"    Level **{p['level']}**  ·  {tier}  ·  🪙 {p['gold']:,}"
        )

    embed.description = "\n\n".join(lines)
    embed.set_footer(text="Rankings by level, then XP")
    await interaction.response.send_message(embed=embed)

# ── /sheet ─────────────────────────────────────────────────────────────────────

@tree.command(name="sheet", description="(Re)post your character sheet to #charakter-blaetter.")
async def cmd_sheet(interaction: discord.Interaction):
    data = load_players()
    uid = str(interaction.user.id)

    if uid not in data:
        await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
        return

    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)
    player = data[uid]
    await update_character_sheet(bot, player, interaction.user)
    save_players(data)
    await interaction.followup.send(f"✅  Your sheet has been posted/updated in #{SHEET_CHANNEL}!", ephemeral=True)

# ── /races & /classes info ─────────────────────────────────────────────────────

@tree.command(name="races", description="Browse all playable races and their base stats.")
async def cmd_races(interaction: discord.Interaction):
    embed = discord.Embed(title="🌍  Playable Races of Aetheria", color=0x3F51B5)
    for race, d in RACES.items():
        embed.add_field(
            name=f"{d['emoji']} {race}",
            value=(
                f"{d['lore']}\n"
                f"❤️`{d['hp']}` 💪`{d['str']}` 🛡️`{d['def']}` 💨`{d['agi']}` ✨`{d['mag']}`"
            ),
            inline=False,
        )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@tree.command(name="classes", description="Browse all available classes and their bonuses.")
async def cmd_classes(interaction: discord.Interaction):
    embed = discord.Embed(title="⚔️  Available Classes of Aetheria", color=0x795548)
    for cls, d in CLASSES.items():
        bonuses = []
        for stat, key in [("❤️HP", "hp"), ("💪STR", "str"), ("🛡️DEF", "def"), ("💨AGI", "agi"), ("✨MAG", "mag")]:
            v = d[key]
            if v != 0:
                bonuses.append(f"{stat} {'+' if v > 0 else ''}{v}")
        embed.add_field(
            name=f"{d['emoji']} {cls}",
            value=f"{d['lore']}\n*Bonuses:* {', '.join(bonuses)}",
            inline=False,
        )
    await interaction.response.send_message(embed=embed, ephemeral=True)


# ── /hiddenclasses ─────────────────────────────────────────────────────────────

_HC_HINTS: dict[str, str] = {
    "Dragon Knight":   "*\"Blood calls to blood. The ancient wyrms stir for those of scale and steel.\"*",
    "Archmage":        "*\"When wisdom becomes infinite, the stars themselves become letters in a spell.\"*",
    "Demon Emperor":   "*\"Not all who rule do so with armies. Some rule with inevitability.\"*",
    "Archangel":       "*\"Divinity is not given. It is earned through absolute sacrifice and celestial grace.\"*",
    "Shadow Monarch":  "*\"The deepest shadow is not darkness — it is the shadow cast by your own legend.\"*",
    "World Wanderer":  "*\"Every path taken. Every realm seen. The journey itself becomes the class.\"*",
    "Titan Slayer":    "*\"When you have felled a god, what remains to fear?\"*",
    "Lord of the Void": "*\"Between worlds, between moments — that is where true power sleeps.\"*",
}


@tree.command(name="hiddenclasses", description="Glimpse the legendary Hidden Classes of Aetheria — if you dare.")
async def cmd_hiddenclasses(interaction: discord.Interaction):
    data = load_players()
    uid  = str(interaction.user.id)
    player_hidden = data.get(uid, {}).get("hidden_class")

    embed = discord.Embed(
        title="🌑  The Hidden Classes of Aetheria",
        description=(
            "These classes cannot be chosen.\n"
            "They choose their bearer.\n\n"
            "Only the most extraordinary heroes — those who have walked the hardest roads, "
            "wielded the rarest relics, and reached the highest peaks — will ever hear the call.\n"
            "The conditions are unknown. The chance is unknowable."
        ),
        color=0x1a1a2e,
    )

    for name, hc in HIDDEN_CLASSES.items():
        if name == player_hidden:
            # Player has unlocked this class — show full info
            embed.add_field(
                name=f"{hc['emoji']}  {name}  ✦ AWAKENED ✦",
                value=(
                    f"{hc['lore']}\n"
                    f"*You carry this class. You are one of the chosen few.*"
                ),
                inline=False,
            )
        else:
            # Redacted mystery entry
            redacted = "█" * len(name)
            embed.add_field(
                name=f"🌑  {redacted}",
                value=_HC_HINTS[name],
                inline=False,
            )

    if player_hidden:
        embed.set_footer(text=f"✦  You have awakened the {player_hidden}. Your name echoes through the ages.  ✦")
    else:
        embed.set_footer(text="These classes are ultra-rare. Many reach the end of their journey without hearing the call.")

    await interaction.response.send_message(embed=embed, ephemeral=True)


# ── Shop catalog ──────────────────────────────────────────────────────────────
# Each entry: display name → {buy, sell, emoji, description}
SHOP: dict[str, dict] = {
    "Health Potion":          {"buy": 80,   "sell": 30,  "emoji": "🧪", "desc": "Restores vitality in the heat of battle."},
    "Mana Potion":            {"buy": 80,   "sell": 30,  "emoji": "💧", "desc": "Replenishes magical energy reserves."},
    "Antidote":               {"buy": 60,   "sell": 20,  "emoji": "🌿", "desc": "Cures poisons and toxins."},
    "Iron Shield":            {"buy": 150,  "sell": 60,  "emoji": "🛡️", "desc": "A sturdy shield forged from iron ore."},
    "Steel Sword":            {"buy": 150,  "sell": 60,  "emoji": "⚔️", "desc": "A reliable blade for any adventurer."},
    "Enchanted Cloak":        {"buy": 350,  "sell": 140, "emoji": "🧥", "desc": "Woven with threads of protective magic."},
    "Lucky Charm":            {"buy": 200,  "sell": 80,  "emoji": "🍀", "desc": "Increases the chance of item drops on /daily."},
    "Elixir of Fortune":      {"buy": 300,  "sell": 120, "emoji": "✨", "desc": "Doubles gold earned on your next /daily."},
    "Ancient Rune":           {"buy": 500,  "sell": 200, "emoji": "🔯", "desc": "Grants a significant XP bonus on /daily."},
    "Shadow Essence":         {"buy": 400,  "sell": 160, "emoji": "🌑", "desc": "A rare alchemical ingredient from the dark realm."},
    "Dragon Scale Fragment":  {"buy": 600,  "sell": 250, "emoji": "🐉", "desc": "A fragment of a dragon's legendary armour."},
    "Philosopher's Stone":    {"buy": 1500, "sell": 600, "emoji": "💎", "desc": "Said to amplify any magical ability tenfold."},
}

# Split shop into pages of 8 for select menus (Discord limit: 25, but 8 keeps it readable)
SHOP_ITEMS = list(SHOP.keys())
SHOP_PAGE_SIZE = 8

def shop_page_items(page: int) -> list[str]:
    start = page * SHOP_PAGE_SIZE
    return SHOP_ITEMS[start:start + SHOP_PAGE_SIZE]

def total_shop_pages() -> int:
    return (len(SHOP_ITEMS) + SHOP_PAGE_SIZE - 1) // SHOP_PAGE_SIZE

# ── Shop Views ─────────────────────────────────────────────────────────────────

class BuySelect(Select):
    def __init__(self, page: int):
        self.page = page
        options = [
            discord.SelectOption(
                label=f"{SHOP[item]['emoji']} {item}",
                value=item,
                description=f"{SHOP[item]['desc'][:60]}  •  🪙 {SHOP[item]['buy']}",
            )
            for item in shop_page_items(page)
        ]
        super().__init__(placeholder="Select an item to buy…", options=options)

    async def callback(self, interaction: discord.Interaction):
        item = self.values[0]
        entry = SHOP[item]

        data = load_players()
        uid = str(interaction.user.id)
        if uid not in data:
            await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
            return

        player = data[uid]
        if player["gold"] < entry["buy"]:
            await interaction.response.send_message(
                f"❌  Not enough gold! **{item}** costs 🪙 {entry['buy']:,} but you only have 🪙 {player['gold']:,}.",
                ephemeral=True,
            )
            return

        player["gold"] -= entry["buy"]
        add_item(player, item)
        save_players(data)

        _, color = level_tier(player["level"])
        embed = discord.Embed(
            title=f"🛒  Purchase Successful!",
            description=f"You bought **{entry['emoji']} {item}** for 🪙 **{entry['buy']:,}**.",
            color=color,
        )
        embed.add_field(name="Remaining Gold", value=f"🪙 {player['gold']:,}", inline=True)
        embed.add_field(name="Owned", value=f"{player['inventory'].get(item, 0)}×", inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

        if isinstance(interaction.user, discord.Member):
            await update_character_sheet(bot, player, interaction.user)
            save_players(data)


class ShopView(View):
    def __init__(self, player: dict, page: int = 0):
        super().__init__(timeout=120)
        self.page = page
        self.player = player
        self.add_item(BuySelect(page))
        if total_shop_pages() > 1:
            if page > 0:
                self.add_item(self._nav_button("◀ Previous", -1))
            if page < total_shop_pages() - 1:
                self.add_item(self._nav_button("Next ▶", +1))

    def _nav_button(self, label: str, direction: int):
        btn = discord.ui.Button(label=label, style=discord.ButtonStyle.secondary)
        page = self.page
        async def callback(interaction: discord.Interaction):
            new_page = page + direction
            embed, view = build_shop_embed_and_view(self.player, new_page)
            await interaction.response.edit_message(embed=embed, view=view)
        btn.callback = callback
        return btn


def build_shop_embed_and_view(player: dict, page: int = 0):
    _, color = level_tier(player["level"])
    embed = discord.Embed(
        title="🏪  Aetheria Market",
        description=f"Your gold: 🪙 **{player['gold']:,}**  •  Page {page + 1}/{total_shop_pages()}",
        color=color,
    )
    for item in shop_page_items(page):
        entry = SHOP[item]
        embed.add_field(
            name=f"{entry['emoji']} {item}",
            value=f"{entry['desc']}\n💰 Buy: **{entry['buy']:,}** 🪙  •  Sell: {entry['sell']:,} 🪙",
            inline=False,
        )
    embed.set_footer(text="Select an item from the dropdown to buy it • Use /sell to sell items")
    return embed, ShopView(player, page)


# ── /shop ──────────────────────────────────────────────────────────────────────

@tree.command(name="shop", description="Browse and buy items from the Aetheria Market.")
async def cmd_shop(interaction: discord.Interaction):
    data = load_players()
    uid = str(interaction.user.id)
    if uid not in data:
        await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
        return

    player = data[uid]
    embed, view = build_shop_embed_and_view(player)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


# ── /sell ──────────────────────────────────────────────────────────────────────

@tree.command(name="sell", description="Sell an item from your inventory for gold.")
@app_commands.describe(item="Item name to sell", quantity="How many to sell (default: 1)")
async def cmd_sell(interaction: discord.Interaction, item: str, quantity: int = 1):
    data = load_players()
    uid = str(interaction.user.id)
    if uid not in data:
        await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
        return

    if quantity < 1:
        await interaction.response.send_message("❌  Quantity must be at least 1.", ephemeral=True)
        return

    player = data[uid]
    inv = player.get("inventory", {})

    # Case-insensitive match
    matched = next((k for k in inv if k.lower() == item.lower()), None)
    if matched is None:
        await interaction.response.send_message(
            f"❌  You don't have **{item}** in your inventory. Use `/inventory` to see what you own.",
            ephemeral=True,
        )
        return

    if inv.get(matched, 0) < quantity:
        await interaction.response.send_message(
            f"❌  You only have `{inv.get(matched, 0)}×` **{matched}** but tried to sell `{quantity}`.",
            ephemeral=True,
        )
        return

    # Determine sell price: shop items → fixed sell, crafted items → CRAFTED_ITEMS, else 10g
    if matched in SHOP:
        unit_price = SHOP[matched]["sell"]
    elif matched in CRAFTED_ITEMS:
        unit_price = CRAFTED_ITEMS[matched]
    else:
        unit_price = 10
    total_gold = unit_price * quantity

    remove_item(player, matched, quantity)
    player["gold"] += total_gold
    save_players(data)

    _, color = level_tier(player["level"])
    embed = discord.Embed(
        title="💰  Item Sold!",
        description=(
            f"Sold `{quantity}×` **{matched}** for 🪙 **{total_gold:,}**\n"
            f"*(🪙 {unit_price:,} each)*"
        ),
        color=color,
    )
    embed.add_field(name="New Balance", value=f"🪙 {player['gold']:,}", inline=True)
    remaining = player["inventory"].get(matched, 0)
    embed.add_field(name="Remaining", value=f"{remaining}×" if remaining else "None", inline=True)
    await interaction.response.send_message(embed=embed, ephemeral=True)

    if isinstance(interaction.user, discord.Member):
        await update_character_sheet(bot, player, interaction.user)
        save_players(data)


# ── Duel engine ───────────────────────────────────────────────────────────────

MAX_ROUNDS   = 5
DODGE_SCALE  = 0.008   # each AGI point adds 0.8% dodge chance, cap 40%
CRIT_CHANCE  = 0.12    # 12% base crit chance (×1.5 dmg)
DUEL_XP_WIN  = 60
DUEL_XP_LOSS = 20

def _dmg(atk_str: int, atk_mag: int, def_def: int) -> int:
    """Physical + magical damage reduced by defence."""
    raw = int((atk_str * 0.7 + atk_mag * 0.3) * random.uniform(0.85, 1.15))
    reduction = max(0, def_def * 0.4)
    return max(1, int(raw - reduction))

def simulate_duel(p1: dict, p2: dict) -> dict:
    """
    Simulate a full duel and return a result dict with:
      winner_idx (0 or 1), rounds (list of str log lines), hp1, hp2
    """
    s1 = compute_stats(p1["race"], p1["class"], p1["level"])
    s2 = compute_stats(p2["race"], p2["class"], p2["level"])

    hp1 = s1["hp"]
    hp2 = s2["hp"]

    dodge1 = min(0.40, s1["agi"] * DODGE_SCALE)
    dodge2 = min(0.40, s2["agi"] * DODGE_SCALE)

    logs = []
    n1 = p1["username"]
    n2 = p2["username"]
    r1 = RACES[p1["race"]]["emoji"]
    r2 = RACES[p2["race"]]["emoji"]

    for rnd in range(1, MAX_ROUNDS + 1):
        line = f"**Round {rnd}**\n"
        rnd_lines = []

        # p1 attacks p2
        if random.random() < dodge2:
            rnd_lines.append(f"  ↪ {r2} **{n2}** dodges {r1} {n1}'s strike!")
        else:
            dmg = _dmg(s1["str"], s1["mag"], s2["def"])
            crit = random.random() < CRIT_CHANCE
            if crit:
                dmg = int(dmg * 1.5)
                rnd_lines.append(f"  💥 **CRIT!** {r1} **{n1}** hits {r2} {n2} for **{dmg}** damage!")
            else:
                rnd_lines.append(f"  ⚔️ {r1} **{n1}** hits {r2} {n2} for **{dmg}** damage.")
            hp2 = max(0, hp2 - dmg)

        # p2 attacks p1
        if hp2 > 0:
            if random.random() < dodge1:
                rnd_lines.append(f"  ↪ {r1} **{n1}** dodges {r2} {n2}'s strike!")
            else:
                dmg = _dmg(s2["str"], s2["mag"], s1["def"])
                crit = random.random() < CRIT_CHANCE
                if crit:
                    dmg = int(dmg * 1.5)
                    rnd_lines.append(f"  💥 **CRIT!** {r2} **{n2}** hits {r1} {n1} for **{dmg}** damage!")
                else:
                    rnd_lines.append(f"  ⚔️ {r2} **{n2}** hits {r1} {n1} for **{dmg}** damage.")
                hp1 = max(0, hp1 - dmg)

        rnd_lines.append(f"  ❤️ {n1}: **{hp1}** HP  |  {n2}: **{hp2}** HP")
        logs.append(line + "\n".join(rnd_lines))

        if hp1 <= 0 or hp2 <= 0:
            break

    winner_idx = 0 if hp1 >= hp2 else 1
    return {"winner_idx": winner_idx, "rounds": logs, "hp1": hp1, "hp2": hp2}


# ── Duel challenge View ────────────────────────────────────────────────────────

class DuelChallengeView(View):
    def __init__(self, challenger: discord.Member, opponent: discord.Member, wager: int):
        super().__init__(timeout=60)
        self.challenger = challenger
        self.opponent   = opponent
        self.wager      = wager

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.opponent.id:
            await interaction.response.send_message(
                "⛔  Only the challenged player can respond to this duel.", ephemeral=True
            )
            return False
        return True

    @discord.ui.button(label="⚔️  Accept", style=discord.ButtonStyle.danger)
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.stop()
        for item in self.children:
            item.disabled = True

        await interaction.response.defer()

        data = load_players()
        cid = str(self.challenger.id)
        oid = str(self.opponent.id)

        # Re-validate everything at accept time
        if cid not in data or oid not in data:
            await interaction.followup.send("❌  One of the fighters no longer has a character.")
            return

        cp = data[cid]
        op = data[oid]

        if self.wager > 0:
            if cp["gold"] < self.wager:
                await interaction.followup.send(f"❌  {self.challenger.display_name} no longer has enough gold!")
                return
            if op["gold"] < self.wager:
                await interaction.followup.send(f"❌  {self.opponent.display_name} no longer has enough gold!")
                return

        result = simulate_duel(cp, op)
        players = [cp, op]
        members = [self.challenger, self.opponent]
        winner_p = players[result["winner_idx"]]
        loser_p  = players[1 - result["winner_idx"]]
        winner_m = members[result["winner_idx"]]
        loser_m  = members[1 - result["winner_idx"]]

        # Apply gold wager
        if self.wager > 0:
            winner_p["gold"] += self.wager
            loser_p["gold"]  -= self.wager

        # Apply XP
        w_levels = add_xp(winner_p, DUEL_XP_WIN)
        add_xp(loser_p, DUEL_XP_LOSS)

        save_players(data)

        # Hidden class check for both fighters
        for p, m in zip(players, members):
            if isinstance(m, discord.Member) and _check_hidden_class_conditions(p):
                await trigger_hidden_class(p, m, data)

        _, w_color = level_tier(winner_p["level"])

        # Build result embed
        round_text = "\n\n".join(result["rounds"])
        if len(round_text) > 3000:
            # Keep last 3 rounds if too long
            round_text = "\n\n".join(result["rounds"][-3:])

        embed = discord.Embed(
            title="⚔️  Duel Results — Aetheria Arena",
            description=round_text,
            color=w_color,
        )

        r_w = RACES[winner_p["race"]]["emoji"]
        r_l = RACES[loser_p["race"]]["emoji"]
        embed.add_field(
            name=f"🏆  {r_w} {winner_m.display_name} wins!",
            value=(
                f"+{DUEL_XP_WIN} XP"
                + (f"  •  +🪙 {self.wager:,}" if self.wager > 0 else "")
                + (f"\n🎉 **Level Up → {winner_p['level']}!**" if w_levels else "")
            ),
            inline=True,
        )
        embed.add_field(
            name=f"💀  {r_l} {loser_m.display_name} falls…",
            value=(
                f"+{DUEL_XP_LOSS} XP (consolation)"
                + (f"  •  -🪙 {self.wager:,}" if self.wager > 0 else "")
            ),
            inline=True,
        )

        if self.wager > 0:
            embed.add_field(
                name="💰  Gold transferred",
                value=f"🪙 {self.wager:,} from {loser_m.display_name} → {winner_m.display_name}",
                inline=False,
            )

        embed.set_footer(text="Aetheria Online • Use /duel to challenge someone!")
        await interaction.edit_original_response(embed=embed, view=None)

        # Update both character sheets
        for p, m in zip(players, members):
            if isinstance(m, discord.Member):
                await update_character_sheet(bot, p, m)
        save_players(data)

    @discord.ui.button(label="🏳️  Decline", style=discord.ButtonStyle.secondary)
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.stop()
        for item in self.children:
            item.disabled = True
        embed = discord.Embed(
            description=f"🏳️  **{self.opponent.display_name}** declined the duel challenge.",
            color=0x9E9E9E,
        )
        await interaction.response.edit_message(embed=embed, view=self)

    async def on_timeout(self):
        for item in self.children:
            item.disabled = True


# ── /duel ──────────────────────────────────────────────────────────────────────

@tree.command(name="duel", description="Challenge another player to a PvP duel!")
@app_commands.describe(
    opponent="The player you want to challenge",
    wager="Gold to wager (0 for a friendly duel)",
)
async def cmd_duel(interaction: discord.Interaction, opponent: discord.Member, wager: int = 0):
    data = load_players()
    cid = str(interaction.user.id)
    oid = str(opponent.id)

    # Guard rails
    if opponent.id == interaction.user.id:
        await interaction.response.send_message("❌  You can't duel yourself!", ephemeral=True)
        return
    if opponent.bot:
        await interaction.response.send_message("❌  You can't duel a bot.", ephemeral=True)
        return
    if wager < 0:
        await interaction.response.send_message("❌  Wager must be 0 or more.", ephemeral=True)
        return
    if cid not in data:
        await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
        return
    if oid not in data:
        await interaction.response.send_message(
            f"❌  **{opponent.display_name}** doesn't have a character yet.", ephemeral=True
        )
        return

    cp = data[cid]
    op = data[oid]

    if wager > 0 and cp["gold"] < wager:
        await interaction.response.send_message(
            f"❌  You only have 🪙 {cp['gold']:,} but wagered 🪙 {wager:,}.", ephemeral=True
        )
        return
    if wager > 0 and op["gold"] < wager:
        await interaction.response.send_message(
            f"❌  **{opponent.display_name}** only has 🪙 {op['gold']:,} and can't cover the wager.", ephemeral=True
        )
        return

    cr = RACES[cp["race"]]
    orr = RACES[op["race"]]
    cc = CLASSES[cp["class"]]
    oc = CLASSES[op["class"]]

    cs = compute_stats(cp["race"], cp["class"], cp["level"])
    os_ = compute_stats(op["race"], op["class"], op["level"])

    embed = discord.Embed(
        title="⚔️  Duel Challenge!",
        description=(
            f"{cr['emoji']} **{interaction.user.display_name}** challenges "
            f"{orr['emoji']} **{opponent.display_name}** to a duel!\n\n"
            + (f"🪙 **Wager: {wager:,} gold**\n\n" if wager > 0 else "*(Friendly duel — no gold at stake)*\n\n")
            + f"**{opponent.display_name}**, do you accept?"
        ),
        color=0xE74C3C,
    )
    embed.add_field(
        name=f"{cr['emoji']} {interaction.user.display_name}  (Lvl {cp['level']})",
        value=(
            f"{cc['emoji']} {cp['class']}\n"
            f"❤️ {cs['hp']}  💪 {cs['str']}  🛡️ {cs['def']}  💨 {cs['agi']}  ✨ {cs['mag']}"
        ),
        inline=True,
    )
    embed.add_field(
        name=f"{orr['emoji']} {opponent.display_name}  (Lvl {op['level']})",
        value=(
            f"{oc['emoji']} {op['class']}\n"
            f"❤️ {os_['hp']}  💪 {os_['str']}  🛡️ {os_['def']}  💨 {os_['agi']}  ✨ {os_['mag']}"
        ),
        inline=True,
    )
    embed.set_footer(text="Challenge expires in 60 seconds")

    view = DuelChallengeView(
        challenger=interaction.user if isinstance(interaction.user, discord.Member) else opponent,
        opponent=opponent,
        wager=wager,
    )
    await interaction.response.send_message(embed=embed, view=view)


# ── Quest data tables ─────────────────────────────────────────────────────────

GUILD_QUEST_FILE = Path(__file__).parent / "data" / "guild_quests.json"
GUILD_QUEST_CHANNEL = "quests"

QUEST_MONSTERS = [
    "Forest Wolves", "Cave Trolls", "Shadow Wraiths", "Swamp Basilisks",
    "Corrupted Knights", "Stone Golems", "Sea Serpents", "Frost Giants",
    "Plague Rats", "Lava Elementals", "Void Spawn", "Ancient Undead",
    "Rogue Assassins", "Cursed Vampires", "Demon Scouts", "Bandit Raiders",
    "Giant Scorpions", "Spectral Archers", "Blood Cultists", "Iron Sentinels",
]
QUEST_MATERIALS = [
    "Moonflower Petals", "Dragon Crystals", "Ancient Bone Dust",
    "Shadow Ore", "Celestial Herbs", "Runic Fragments", "Void Shards",
    "Crimson Mushrooms", "Storm Feathers", "Abyssal Pearls",
    "Starstone Dust", "Frostbloom Roots", "Ember Sap", "Ghostfire Moss",
]
QUEST_LOCATIONS = [
    "the Whispering Forest", "the Shattered Peaks", "the Sunken Ruins",
    "the Crimson Desert", "the Frozen Wastes", "the Shadow Realm",
    "the Ancient Catacombs", "the Burning Wastes", "the Emerald Swamp",
    "the Celestial Spire", "the Drowned Harbour", "the Obsidian Plateau",
    "the Verdant Labyrinth", "the Storm Coast",
]
QUEST_NPCS = [
    "a Royal Merchant", "an Elvish Scholar", "a Dwarven Blacksmith",
    "an Injured Ranger", "a Fleeing Noble", "a Young Mage Apprentice",
    "a Wounded Knight", "a Lost Cartographer",
]
QUEST_BOSSES = [
    "the Lich King Malachar", "the Dragon Queen Seraphex",
    "Lord Shadowbane the Destroyer", "the Ancient Demon Gorathul",
    "Admiral Vex the Pirate Warlord", "the Corrupted Archangel Uriel",
    "Titanborn Kragoth", "the Shadow Witch Velindra",
    "the Abyssal Hydra Zyrath", "High Inquisitor Caldren the Pale",
]

DIFFICULTY: dict[str, dict] = {
    "easy":   {"label": "Easy",   "emoji": "🟢", "color": 0x4CAF50, "duration_min": 10,  "xp": (0.5, 0.9),  "gold": (0.4, 0.8),  "success": 0.92, "item_chance": 0.18},
    "medium": {"label": "Medium", "emoji": "🟡", "color": 0xFFC107, "duration_min": 30,  "xp": (1.0, 1.7),  "gold": (0.8, 1.5),  "success": 0.70, "item_chance": 0.38},
    "hard":   {"label": "Hard",   "emoji": "🔴", "color": 0xF44336, "duration_min": 60,  "xp": (2.0, 3.5),  "gold": (1.5, 2.8),  "success": 0.48, "item_chance": 0.62},
}

GUILD_QUEST_DURATION_MIN = 120   # 2-hour window to complete a guild quest


# ── Quest generation ───────────────────────────────────────────────────────────

def _pick_quest_template(level: int, diff: str) -> dict:
    d = DIFFICULTY[diff]
    base_xp   = max(20, level * 12)
    base_gold = max(10, level * 6)
    xp_lo, xp_hi     = d["xp"]
    gl_lo, gl_hi     = d["gold"]
    xp_reward   = int(base_xp   * random.uniform(xp_lo, xp_hi))
    gold_reward = int(base_gold * random.uniform(gl_lo, gl_hi))

    qtype = random.choice(["hunt", "gather", "escort", "explore", "bounty"])

    if qtype == "hunt":
        count   = random.choice([3, 5, 8, 10, 15])
        monster = random.choice(QUEST_MONSTERS)
        name = f"Slay {count} {monster}"
        desc = f"**{monster}** are terrorising the region. Hunt down `{count}` of them and bring proof."
    elif qtype == "gather":
        count    = random.choice([5, 10, 15, 20])
        material = random.choice(QUEST_MATERIALS)
        name = f"Gather {count}× {material}"
        desc = f"The guild needs `{count}` **{material}**. Head out and collect them before supplies run dry."
    elif qtype == "escort":
        npc      = random.choice(QUEST_NPCS)
        location = random.choice(QUEST_LOCATIONS)
        name = f"Escort {npc} to safety"
        desc = f"Safely escort **{npc}** through {location}. Ambushes are likely."
    elif qtype == "explore":
        location = random.choice(QUEST_LOCATIONS)
        name = f"Chart {location}"
        desc = f"Little is known about {location}. Return with detailed maps and survive."
    else:  # bounty
        boss = random.choice(QUEST_BOSSES)
        name = f"Bounty: {boss}"
        desc = f"A bounty has been placed on **{boss}**. Only the truly brave need apply."
        xp_reward   = int(xp_reward   * 1.4)
        gold_reward = int(gold_reward * 1.5)

    now = datetime.now(timezone.utc)
    return {
        "name":         name,
        "desc":         desc,
        "type":         qtype,
        "difficulty":   diff,
        "xp_reward":    xp_reward,
        "gold_reward":  gold_reward,
        "item_chance":  d["item_chance"],
        "success":      d["success"],
        "duration_min": d["duration_min"],
        "started_at":   now.isoformat(),
        "completes_at": (now + timedelta(minutes=d["duration_min"])).isoformat(),
    }


def generate_quest_offer(level: int, diff: str) -> dict:
    return _pick_quest_template(level, diff)


# ── Guild quest persistence ────────────────────────────────────────────────────

def load_guild_quests() -> dict:
    if GUILD_QUEST_FILE.exists():
        with open(GUILD_QUEST_FILE, "r") as f:
            return json.load(f)
    return {}

def save_guild_quests(data: dict):
    GUILD_QUEST_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(GUILD_QUEST_FILE, "w") as f:
        json.dump(data, f, indent=2)


def _new_guild_quest(level_avg: int) -> dict:
    """Generate a guild-scale quest (always Hard tier with bigger multipliers)."""
    base_xp   = max(80, level_avg * 18)
    base_gold = max(40, level_avg * 10)
    xp_reward   = int(base_xp   * random.uniform(2.5, 4.0))
    gold_reward = int(base_gold * random.uniform(2.0, 3.5))

    qtype = random.choice(["hunt", "gather", "explore", "bounty"])
    if qtype == "hunt":
        count = random.choice([20, 30, 50])
        monster = random.choice(QUEST_MONSTERS)
        name = f"[GUILD] Purge {count} {monster}"
        desc = f"A massive horde of **{monster}** threatens the realm. All guild members must join the hunt. Target: `{count}` kills."
    elif qtype == "gather":
        count    = random.choice([30, 50, 75])
        material = random.choice(QUEST_MATERIALS)
        name = f"[GUILD] Supply Run: {material}"
        desc = f"The guild vaults are nearly empty. Collectively gather `{count}` **{material}** before the siege begins."
    elif qtype == "explore":
        location = random.choice(QUEST_LOCATIONS)
        name = f"[GUILD] Siege of {location}"
        desc = f"The guild must establish a foothold in {location}. All heroes are called to explore and secure the area."
    else:
        boss = random.choice(QUEST_BOSSES)
        name = f"[GUILD] Raid: {boss}"
        desc = f"**{boss}** has been located. This is a guild-wide raid — no hero can face this threat alone."
        xp_reward   = int(xp_reward   * 1.3)
        gold_reward = int(gold_reward * 1.3)

    now = datetime.now(timezone.utc)
    return {
        "id":           f"gq_{int(now.timestamp())}_{random.randint(100,999)}",
        "name":         name,
        "desc":         desc,
        "xp_reward":    xp_reward,
        "gold_reward":  gold_reward,
        "item_chance":  0.55,
        "participants": [],
        "completed_by": [],
        "posted_at":    now.isoformat(),
        "expires_at":   (now + timedelta(minutes=GUILD_QUEST_DURATION_MIN)).isoformat(),
        "message_id":   None,
    }


# ── Solo quest Views ───────────────────────────────────────────────────────────

def _quest_offer_embed(quest: dict, player: dict) -> discord.Embed:
    d = DIFFICULTY[quest["difficulty"]]
    embed = discord.Embed(
        title=f"{d['emoji']} {quest['name']}",
        description=quest["desc"],
        color=d["color"],
    )
    embed.add_field(name="Difficulty",  value=f"{d['emoji']} {d['label']}", inline=True)
    embed.add_field(name="Duration",    value=f"⏳ {quest['duration_min']} min",  inline=True)
    embed.add_field(name="Success Rate", value=f"🎯 {int(quest['success']*100)}%", inline=True)
    embed.add_field(name="XP Reward",   value=f"✨ ~{quest['xp_reward']}", inline=True)
    embed.add_field(name="Gold Reward", value=f"🪙 ~{quest['gold_reward']}", inline=True)
    embed.add_field(name="Item Drop",   value=f"📦 {int(quest['item_chance']*100)}% chance", inline=True)
    return embed


class QuestChoiceView(View):
    """Shows 3 difficulty buttons. Clicking one commits to that quest."""

    def __init__(self, player: dict, offers: dict[str, dict]):
        super().__init__(timeout=90)
        self.player = player
        self.offers = offers   # {"easy": quest_dict, "medium": ..., "hard": ...}

        for diff, label, style in [
            ("easy",   "🟢 Easy",   discord.ButtonStyle.success),
            ("medium", "🟡 Medium", discord.ButtonStyle.primary),
            ("hard",   "🔴 Hard",   discord.ButtonStyle.danger),
        ]:
            btn = discord.ui.Button(label=label, style=style, custom_id=f"quest_{diff}")
            btn.callback = self._make_callback(diff)
            self.add_item(btn)

    def _make_callback(self, diff: str):
        async def callback(interaction: discord.Interaction):
            uid = str(interaction.user.id)
            data = load_players()
            if uid not in data:
                await interaction.response.send_message("❌  No character found.", ephemeral=True)
                return
            player = data[uid]
            if player.get("active_quest"):
                await interaction.response.send_message("❌  You already have an active quest!", ephemeral=True)
                return

            chosen = self.offers[diff]
            player["active_quest"] = chosen
            save_players(data)

            for item in self.children:
                item.disabled = True
            self.stop()

            d = DIFFICULTY[diff]
            embed = discord.Embed(
                title=f"⚔️  Quest Accepted: {chosen['name']}",
                description=(
                    f"{chosen['desc']}\n\n"
                    f"Return in **{chosen['duration_min']} minutes** to claim your reward with `/quest complete`."
                ),
                color=d["color"],
            )
            embed.set_footer(text="Good luck, adventurer!")
            await interaction.response.edit_message(embed=embed, view=self)
        return callback


# ── Quest command group ────────────────────────────────────────────────────────

quest_group = app_commands.Group(name="quest", description="Solo quest commands")
tree.add_command(quest_group)


@quest_group.command(name="start", description="Pick a quest scaled to your level.")
async def quest_start(interaction: discord.Interaction):
    data = load_players()
    uid  = str(interaction.user.id)
    if uid not in data:
        await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
        return

    player = data[uid]
    if player.get("active_quest"):
        q = player["active_quest"]
        d = DIFFICULTY[q["difficulty"]]
        completes = datetime.fromisoformat(q["completes_at"])
        now       = datetime.now(timezone.utc)
        if now < completes:
            rem = completes - now
            h, r = divmod(int(rem.total_seconds()), 3600)
            await interaction.response.send_message(
                f"⏳  You're already on a quest: **{q['name']}**\nReady in **{h}h {r // 60}m**. Use `/quest complete` when ready.",
                ephemeral=True,
            )
        else:
            await interaction.response.send_message(
                f"✅  Your quest **{q['name']}** is ready! Use `/quest complete` to claim your reward.",
                ephemeral=True,
            )
        return

    level  = player["level"]
    offers = {diff: generate_quest_offer(level, diff) for diff in ["easy", "medium", "hard"]}

    embed = discord.Embed(
        title="📋  Quest Board — Choose Your Mission",
        description=f"Three quests await, **{interaction.user.display_name}** (Level {level}). Pick your challenge:",
        color=0x3F51B5,
    )
    for diff, q in offers.items():
        d = DIFFICULTY[diff]
        embed.add_field(
            name=f"{d['emoji']} {d['label']} — {q['name']}",
            value=(
                f"{q['desc']}\n"
                f"⏳ {q['duration_min']}min  •  🎯 {int(q['success']*100)}%  •  "
                f"✨ ~{q['xp_reward']} XP  •  🪙 ~{q['gold_reward']}  •  📦 {int(q['item_chance']*100)}% drop"
            ),
            inline=False,
        )
    embed.set_footer(text="Select a difficulty below • Expires in 90 seconds")
    await interaction.response.send_message(embed=embed, view=QuestChoiceView(player, offers), ephemeral=True)


@quest_group.command(name="status", description="Check your active quest progress.")
async def quest_status(interaction: discord.Interaction):
    data = load_players()
    uid  = str(interaction.user.id)
    if uid not in data:
        await interaction.response.send_message("❌  Create a character first!", ephemeral=True)
        return

    player = data[uid]
    q = player.get("active_quest")
    if not q:
        await interaction.response.send_message(
            "📋  You have no active quest. Start one with `/quest start`!", ephemeral=True
        )
        return

    d = DIFFICULTY[q["difficulty"]]
    completes = datetime.fromisoformat(q["completes_at"])
    now       = datetime.now(timezone.utc)
    ready     = now >= completes

    embed = discord.Embed(
        title=f"{d['emoji']} Active Quest: {q['name']}",
        description=q["desc"],
        color=d["color"],
    )
    embed.add_field(name="Difficulty",   value=f"{d['emoji']} {d['label']}", inline=True)
    embed.add_field(name="Success Rate", value=f"🎯 {int(q['success']*100)}%", inline=True)
    embed.add_field(name="XP Reward",    value=f"✨ ~{q['xp_reward']}", inline=True)
    embed.add_field(name="Gold Reward",  value=f"🪙 ~{q['gold_reward']}", inline=True)
    if ready:
        embed.add_field(name="Status", value="✅  **Ready to claim!** Use `/quest complete`", inline=False)
    else:
        rem = completes - now
        h, r = divmod(int(rem.total_seconds()), 3600)
        bar_total = q["duration_min"] * 60
        bar_elapsed = bar_total - int(rem.total_seconds())
        prog = xp_bar(bar_elapsed, bar_total, 14)
        embed.add_field(name="Status", value=f"⏳  {prog}  `{h}h {r // 60}m remaining`", inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)


@quest_group.command(name="complete", description="Return from your quest and claim your reward!")
async def quest_complete(interaction: discord.Interaction):
    data = load_players()
    uid  = str(interaction.user.id)
    if uid not in data:
        await interaction.response.send_message("❌  Create a character first!", ephemeral=True)
        return

    player = data[uid]
    q = player.get("active_quest")
    if not q:
        await interaction.response.send_message(
            "📋  You have no active quest. Use `/quest start` to begin one!", ephemeral=True
        )
        return

    completes = datetime.fromisoformat(q["completes_at"])
    now       = datetime.now(timezone.utc)
    if now < completes:
        rem = completes - now
        h, r = divmod(int(rem.total_seconds()), 3600)
        await interaction.response.send_message(
            f"⏳  **{q['name']}** isn't done yet — return in **{h}h {r // 60}m**.",
            ephemeral=True,
        )
        return

    d = DIFFICULTY[q["difficulty"]]

    # Roll success
    success = random.random() < q["success"]

    if success:
        # Vary the rewards slightly for flavour
        xp_gain   = int(q["xp_reward"]   * random.uniform(0.85, 1.15))
        gold_gain  = int(q["gold_reward"] * random.uniform(0.85, 1.15))
        player["gold"] += gold_gain
        levels = add_xp(player, xp_gain)

        # Item drop
        dropped = None
        if random.random() < q["item_chance"]:
            dropped = random.choice(list(SHOP.keys()))
            add_item(player, dropped)

        player.pop("active_quest", None)
        save_players(data)

        _, color = level_tier(player["level"])
        embed = discord.Embed(
            title=f"✅  Quest Complete: {q['name']}",
            description=f"You returned victorious, **{interaction.user.display_name}**! The realm thanks you.",
            color=color,
        )
        embed.add_field(name="XP Earned",   value=f"+{xp_gain} ✨",   inline=True)
        embed.add_field(name="Gold Earned",  value=f"+{gold_gain} 🪙", inline=True)
        if dropped:
            embed.add_field(name="📦 Item Drop!", value=f"**{SHOP[dropped]['emoji']} {dropped}**", inline=True)
        if levels:
            embed.add_field(
                name="⬆️  Level Up!",
                value="\n".join(f"🎉 **Level {lvl}** reached!" for lvl in levels),
                inline=False,
            )
        embed.set_footer(text="Start a new quest with /quest start")
    else:
        # Failed quest — small consolation XP
        consolation_xp = max(5, q["xp_reward"] // 8)
        add_xp(player, consolation_xp)
        player.pop("active_quest", None)
        save_players(data)

        embed = discord.Embed(
            title=f"💀  Quest Failed: {q['name']}",
            description=(
                f"You fought bravely, **{interaction.user.display_name}**, but the quest ended in defeat.\n"
                f"Consolation: +{consolation_xp} XP for the effort."
            ),
            color=0x9E9E9E,
        )
        embed.set_footer(text="Dust yourself off and try again with /quest start")

    embed.set_thumbnail(url=interaction.user.display_avatar.url)
    await interaction.response.send_message(embed=embed)

    if isinstance(interaction.user, discord.Member):
        await update_character_sheet(bot, player, interaction.user)
        if _check_hidden_class_conditions(player):
            await trigger_hidden_class(player, interaction.user, data)
        save_players(data)


# ── Guild quest Accept View ────────────────────────────────────────────────────

class GuildQuestAcceptView(View):
    """Persistent-style view attached to a guild quest message in #guilds."""

    def __init__(self, quest_id: str, guild_id: str):
        super().__init__(timeout=None)   # no timeout — persists until bot restart
        self.quest_id = quest_id
        self.guild_id = guild_id

    @discord.ui.button(label="⚔️  Accept Quest", style=discord.ButtonStyle.danger, custom_id="gq_accept")
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        uid  = str(interaction.user.id)
        gid  = self.guild_id
        data = load_players()

        if uid not in data:
            await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
            return

        gq_data = load_guild_quests()
        quests  = gq_data.get(gid, [])
        quest   = next((q for q in quests if q["id"] == self.quest_id), None)

        if not quest:
            await interaction.response.send_message("❌  This quest no longer exists.", ephemeral=True)
            return

        expires = datetime.fromisoformat(quest["expires_at"])
        if datetime.now(timezone.utc) > expires:
            await interaction.response.send_message("❌  This guild quest has expired.", ephemeral=True)
            return

        if uid in quest["participants"]:
            await interaction.response.send_message(
                "✅  You've already accepted this quest! Use `/guildquest complete` when the time is up.",
                ephemeral=True,
            )
            return

        quest["participants"].append(uid)
        save_guild_quests(gq_data)

        player = data[uid]
        r = RACES[player["race"]]["emoji"]
        await interaction.response.send_message(
            f"{r} **{interaction.user.display_name}** has joined the guild quest! "
            f"Use `/guildquest complete` in {GUILD_QUEST_DURATION_MIN} min to claim rewards.",
            ephemeral=False,
        )

        # Update the embed participant count
        try:
            count = len(quest["participants"])
            msg   = await interaction.channel.fetch_message(int(quest["message_id"]))
            new_embed = msg.embeds[0] if msg.embeds else None
            if new_embed:
                # Find and update the participants field
                for i, field in enumerate(new_embed.fields):
                    if "Heroes Enlisted" in field.name:
                        new_embed.set_field_at(i, name="⚔️  Heroes Enlisted", value=str(count), inline=True)
                        break
                await msg.edit(embed=new_embed)
        except Exception:
            pass


# ── Guild quest command group ──────────────────────────────────────────────────

guildquest_group = app_commands.Group(name="guildquest", description="Guild-wide quest commands")
tree.add_command(guildquest_group)


@guildquest_group.command(name="post", description="Post a new guild quest to #guilds.")
async def guildquest_post(interaction: discord.Interaction):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This only works inside a server.", ephemeral=True)
        return

    data = load_players()
    uid  = str(interaction.user.id)
    if uid not in data:
        await interaction.response.send_message("❌  Create a character first!", ephemeral=True)
        return

    channel = discord.utils.get(interaction.guild.text_channels, name=GUILD_QUEST_CHANNEL)
    if channel is None:
        await interaction.response.send_message(
            f"❌  No `#{GUILD_QUEST_CHANNEL}` channel found. Create it and try again.", ephemeral=True
        )
        return

    # Determine average level for scaling (use poster's level if only one player)
    levels = [p["level"] for p in data.values() if "level" in p]
    avg_level = int(sum(levels) / len(levels)) if levels else 1

    quest    = _new_guild_quest(avg_level)
    gid      = str(interaction.guild_id)
    gq_data  = load_guild_quests()
    gq_data.setdefault(gid, []).append(quest)

    expires = datetime.fromisoformat(quest["expires_at"])
    embed = discord.Embed(
        title=f"🏰  {quest['name']}",
        description=quest["desc"],
        color=0x7B1FA2,
    )
    embed.add_field(name="✨  XP Reward",       value=str(quest["xp_reward"]),              inline=True)
    embed.add_field(name="🪙  Gold Reward",      value=str(quest["gold_reward"]),             inline=True)
    embed.add_field(name="📦  Item Drop Chance", value=f"{int(quest['item_chance']*100)}%",  inline=True)
    embed.add_field(name="⚔️  Heroes Enlisted",  value="0",                                   inline=True)
    embed.add_field(name="⏳  Expires",          value=f"<t:{int(expires.timestamp())}:R>",  inline=True)
    embed.set_footer(text=f"Scaled to avg guild level {avg_level}  •  Posted by {interaction.user.display_name}")

    view = GuildQuestAcceptView(quest_id=quest["id"], guild_id=gid)
    msg  = await channel.send(embed=embed, view=view)

    quest["message_id"] = str(msg.id)
    save_guild_quests(gq_data)

    await interaction.response.send_message(
        f"✅  Guild quest posted to {channel.mention}! Rally your allies and accept it there.", ephemeral=True
    )


@guildquest_group.command(name="complete", description="Claim rewards for all guild quests you've accepted.")
async def guildquest_complete(interaction: discord.Interaction):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This only works inside a server.", ephemeral=True)
        return

    uid    = str(interaction.user.id)
    gid    = str(interaction.guild_id)
    data   = load_players()
    gq_data = load_guild_quests()

    if uid not in data:
        await interaction.response.send_message("❌  Create a character first!", ephemeral=True)
        return

    quests = gq_data.get(gid, [])
    now    = datetime.now(timezone.utc)
    player = data[uid]

    claimable = [
        q for q in quests
        if uid in q["participants"]
        and uid not in q["completed_by"]
        and now >= datetime.fromisoformat(q["expires_at"])
    ]
    not_ready = [
        q for q in quests
        if uid in q["participants"]
        and uid not in q["completed_by"]
        and now < datetime.fromisoformat(q["expires_at"])
    ]

    if not claimable and not not_ready:
        await interaction.response.send_message(
            f"📋  You haven't accepted any active guild quests. Head to `#{GUILD_QUEST_CHANNEL}` and click **Accept Quest**!",
            ephemeral=True,
        )
        return

    if not claimable and not_ready:
        q   = not_ready[0]
        rem = datetime.fromisoformat(q["expires_at"]) - now
        h, r = divmod(int(rem.total_seconds()), 3600)
        await interaction.response.send_message(
            f"⏳  **{q['name']}** isn't done yet — return in **{h}h {r // 60}m**.",
            ephemeral=True,
        )
        return

    # Claim all ready quests
    total_xp   = 0
    total_gold = 0
    drops: list[str] = []
    quest_names: list[str] = []

    for q in claimable:
        xp_gain   = int(q["xp_reward"]   * random.uniform(0.85, 1.15))
        gold_gain  = int(q["gold_reward"] * random.uniform(0.85, 1.15))
        total_xp   += xp_gain
        total_gold += gold_gain
        if random.random() < q["item_chance"]:
            item = random.choice(list(SHOP.keys()))
            drops.append(item)
            add_item(player, item)
        q["completed_by"].append(uid)
        quest_names.append(q["name"])

    player["gold"] += total_gold
    levels = add_xp(player, total_xp)
    save_players(data)
    save_guild_quests(gq_data)

    _, color = level_tier(player["level"])
    embed = discord.Embed(
        title="🏰  Guild Quest Rewards Claimed!",
        description=(
            f"**{interaction.user.display_name}** returned from:\n"
            + "\n".join(f"  • {n}" for n in quest_names)
        ),
        color=color,
    )
    embed.add_field(name="Total XP",   value=f"+{total_xp} ✨",   inline=True)
    embed.add_field(name="Total Gold", value=f"+{total_gold} 🪙", inline=True)
    if drops:
        embed.add_field(name="📦 Item Drops", value="\n".join(f"• {SHOP[i]['emoji']} {i}" for i in drops), inline=False)
    if levels:
        embed.add_field(
            name="⬆️  Level Up!",
            value="\n".join(f"🎉 **Level {lvl}** reached!" for lvl in levels),
            inline=False,
        )
    embed.set_thumbnail(url=interaction.user.display_avatar.url)
    await interaction.response.send_message(embed=embed)

    if isinstance(interaction.user, discord.Member):
        await update_character_sheet(bot, player, interaction.user)
        if _check_hidden_class_conditions(player):
            await trigger_hidden_class(player, interaction.user, data)
        save_players(data)


# ── Crafting system ───────────────────────────────────────────────────────────
# Each recipe: output_item → {ingredients: {item: qty}, output_qty, min_level, desc, emoji, sell_value}
# Crafted items that aren't in SHOP get a sell_value used by /sell

CRAFTED_ITEMS: dict[str, int] = {
    "Grand Health Potion":    120,
    "Grand Mana Potion":      120,
    "Antidote Salve":          80,
    "Lucky Rune":             280,
    "Arcane Staff":           500,
    "Blessed Sword":          420,
    "Shadowblade":            650,
    "Void Cloak":             700,
    "Elixir of Power":        550,
    "Berserker's Brew":       750,
    "Dragonscale Armour":    1200,
    "Enchanted Runeblade":   1100,
    "Angel's Grace":         1400,
    "Crystal of Eternity":   3000,
    "Drakonian Crest":       5000,
}

RECIPES: dict[str, dict] = {
    "Grand Health Potion": {
        "emoji":       "🧪",
        "desc":        "A potent healing draught brewed from three ordinary potions.",
        "ingredients": {"Health Potion": 3},
        "output_qty":  1,
        "min_level":   1,
    },
    "Grand Mana Potion": {
        "emoji":       "💧",
        "desc":        "A supercharged mana restore distilled from three standard flasks.",
        "ingredients": {"Mana Potion": 3},
        "output_qty":  1,
        "min_level":   1,
    },
    "Antidote Salve": {
        "emoji":       "🌿",
        "desc":        "A powerful salve that cures even the most stubborn toxins.",
        "ingredients": {"Antidote": 2, "Health Potion": 1},
        "output_qty":  1,
        "min_level":   1,
    },
    "Lucky Rune": {
        "emoji":       "🍀",
        "desc":        "A rune imbued with fortune — combine luck with ancient knowledge.",
        "ingredients": {"Lucky Charm": 1, "Ancient Rune": 1},
        "output_qty":  1,
        "min_level":   10,
    },
    "Arcane Staff": {
        "emoji":       "🔯",
        "desc":        "A staff crackling with arcane power, forged from ancient runes and mana.",
        "ingredients": {"Ancient Rune": 2, "Mana Potion": 2},
        "output_qty":  1,
        "min_level":   10,
    },
    "Blessed Sword": {
        "emoji":       "⚔️",
        "desc":        "A steel blade etched with holy runes — sacred and deadly.",
        "ingredients": {"Steel Sword": 1, "Ancient Rune": 1},
        "output_qty":  1,
        "min_level":   10,
    },
    "Void Cloak": {
        "emoji":       "🌑",
        "desc":        "An enchanted cloak soaked in shadow essence — renders the wearer near-invisible.",
        "ingredients": {"Enchanted Cloak": 1, "Shadow Essence": 2},
        "output_qty":  1,
        "min_level":   20,
    },
    "Elixir of Power": {
        "emoji":       "✨",
        "desc":        "Fortune and arcane knowledge fused into a single overwhelming elixir.",
        "ingredients": {"Elixir of Fortune": 1, "Ancient Rune": 1},
        "output_qty":  1,
        "min_level":   15,
    },
    "Shadowblade": {
        "emoji":       "🗡️",
        "desc":        "A blade forged in shadow essence — it strikes before the target can see it coming.",
        "ingredients": {"Steel Sword": 1, "Shadow Essence": 2},
        "output_qty":  1,
        "min_level":   15,
    },
    "Berserker's Brew": {
        "emoji":       "🪓",
        "desc":        "A volatile concoction that sends the drinker into an unstoppable rage.",
        "ingredients": {"Elixir of Fortune": 1, "Mana Potion": 1, "Shadow Essence": 1},
        "output_qty":  1,
        "min_level":   25,
    },
    "Dragonscale Armour": {
        "emoji":       "🐉",
        "desc":        "Armour crafted from genuine dragon scales — nearly impenetrable.",
        "ingredients": {"Dragon Scale Fragment": 3, "Iron Shield": 1},
        "output_qty":  1,
        "min_level":   20,
    },
    "Enchanted Runeblade": {
        "emoji":       "💫",
        "desc":        "The pinnacle of blade-crafting: a blessed sword further refined with runes.",
        "ingredients": {"Blessed Sword": 1, "Ancient Rune": 2},
        "output_qty":  1,
        "min_level":   25,
    },
    "Angel's Grace": {
        "emoji":       "😇",
        "desc":        "A divine concoction of philosopher's wisdom and mana — said to grant celestial clarity.",
        "ingredients": {"Philosopher's Stone": 1, "Mana Potion": 3},
        "output_qty":  1,
        "min_level":   40,
    },
    "Crystal of Eternity": {
        "emoji":       "💎",
        "desc":        "The Philosopher's Stone refined with dragon power — an artefact of legend.",
        "ingredients": {"Philosopher's Stone": 1, "Dragon Scale Fragment": 2},
        "output_qty":  1,
        "min_level":   50,
    },
    "Drakonian Crest": {
        "emoji":       "🏆",
        "desc":        "The ultimate trophy of a master crafter — only the mightiest can forge this.",
        "ingredients": {"Dragon Scale Fragment": 5, "Philosopher's Stone": 1},
        "output_qty":  1,
        "min_level":   70,
    },
}

CRAFT_PAGE_SIZE = 4


def _can_craft(player: dict, recipe_name: str) -> tuple[bool, str]:
    """Returns (can_craft, reason_if_not)."""
    r = RECIPES[recipe_name]
    if player["level"] < r["min_level"]:
        return False, f"Requires Level {r['min_level']} (you are {player['level']})"
    inv = player.get("inventory", {})
    missing = []
    for item, qty in r["ingredients"].items():
        have = inv.get(item, 0)
        if have < qty:
            missing.append(f"`{qty - have}× more` {item}")
    if missing:
        return False, "Missing: " + ", ".join(missing)
    return True, ""


def _craft_item(player: dict, recipe_name: str) -> bool:
    """Deduct ingredients and add output. Returns False if cannot craft."""
    ok, _ = _can_craft(player, recipe_name)
    if not ok:
        return False
    r = RECIPES[recipe_name]
    for item, qty in r["ingredients"].items():
        remove_item(player, item, qty)
    add_item(player, recipe_name, r["output_qty"])
    return True


def _recipe_sell_value(item_name: str) -> int:
    if item_name in SHOP:
        return SHOP[item_name]["sell"]
    return CRAFTED_ITEMS.get(item_name, 10)


# ── Craft list paginator ───────────────────────────────────────────────────────

class CraftListView(View):
    def __init__(self, player: dict, page: int = 0):
        super().__init__(timeout=120)
        self.player = player
        self.page   = page
        self._add_nav()

    def _add_nav(self):
        self.clear_items()
        total = (len(RECIPES) + CRAFT_PAGE_SIZE - 1) // CRAFT_PAGE_SIZE
        if self.page > 0:
            prev = discord.ui.Button(label="◀ Prev", style=discord.ButtonStyle.secondary)
            prev.callback = self._nav(-1)
            self.add_item(prev)
        if self.page < total - 1:
            nxt = discord.ui.Button(label="Next ▶", style=discord.ButtonStyle.secondary)
            nxt.callback = self._nav(+1)
            self.add_item(nxt)

    def _nav(self, direction: int):
        async def callback(interaction: discord.Interaction):
            self.page += direction
            self._add_nav()
            embed = _build_recipe_list_embed(self.player, self.page)
            await interaction.response.edit_message(embed=embed, view=self)
        return callback


def _build_recipe_list_embed(player: dict, page: int) -> discord.Embed:
    keys  = list(RECIPES.keys())
    total = (len(keys) + CRAFT_PAGE_SIZE - 1) // CRAFT_PAGE_SIZE
    start = page * CRAFT_PAGE_SIZE
    slice_ = keys[start:start + CRAFT_PAGE_SIZE]

    _, color = level_tier(player["level"])
    embed = discord.Embed(
        title="⚒️  Aetheria Crafting Compendium",
        description=f"Page {page+1}/{total}  •  Craft with `/craft make <recipe>`",
        color=color,
    )
    for name in slice_:
        r = RECIPES[name]
        can, reason = _can_craft(player, name)
        status = "✅ Craftable" if can else f"❌ {reason}"
        ingr = "  +  ".join(f"`{qty}× {item}`" for item, qty in r["ingredients"].items())
        sell = _recipe_sell_value(name)
        embed.add_field(
            name=f"{r['emoji']} {name}  (Lv {r['min_level']}+)",
            value=f"{r['desc']}\n**Ingredients:** {ingr}\n**Sell value:** 🪙 {sell}  •  {status}",
            inline=False,
        )
    embed.set_footer(text="Use /craft make <name> to forge an item")
    return embed


# ── Craft command group ────────────────────────────────────────────────────────

craft_group = app_commands.Group(name="craft", description="Crafting commands")
tree.add_command(craft_group)


@craft_group.command(name="list", description="Browse all crafting recipes.")
async def craft_list(interaction: discord.Interaction):
    data = load_players()
    uid  = str(interaction.user.id)
    if uid not in data:
        await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
        return
    player = data[uid]
    embed  = _build_recipe_list_embed(player, 0)
    await interaction.response.send_message(embed=embed, view=CraftListView(player), ephemeral=True)


async def _recipe_autocomplete(interaction: discord.Interaction, current: str):
    data = load_players()
    uid  = str(interaction.user.id)
    player = data.get(uid, {})
    return [
        app_commands.Choice(name=f"{RECIPES[n]['emoji']} {n}", value=n)
        for n in RECIPES
        if current.lower() in n.lower()
    ][:25]


@craft_group.command(name="make", description="Craft an item from your inventory materials.")
@app_commands.describe(recipe="The recipe to craft (start typing to search)")
@app_commands.autocomplete(recipe=_recipe_autocomplete)
async def craft_make(interaction: discord.Interaction, recipe: str):
    data = load_players()
    uid  = str(interaction.user.id)
    if uid not in data:
        await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
        return

    if recipe not in RECIPES:
        await interaction.response.send_message(
            f"❌  Unknown recipe **{recipe}**. Use `/craft list` to see all recipes.", ephemeral=True
        )
        return

    player   = data[uid]
    ok, reason = _can_craft(player, recipe)
    if not ok:
        r = RECIPES[recipe]
        embed = discord.Embed(
            title=f"⚒️  Cannot Craft: {r['emoji']} {recipe}",
            description=f"❌  {reason}",
            color=0xE74C3C,
        )
        ingr = "\n".join(f"  `{qty}×` **{item}**  — have `{player.get('inventory', {}).get(item, 0)}`"
                         for item, qty in r["ingredients"].items())
        embed.add_field(name="Required Ingredients", value=ingr, inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    _craft_item(player, recipe)
    save_players(data)

    r = RECIPES[recipe]
    _, color = level_tier(player["level"])
    embed = discord.Embed(
        title=f"⚒️  Crafted: {r['emoji']} {recipe}!",
        description=r["desc"],
        color=color,
    )
    ingr_used = "\n".join(f"  `-{qty}×` {item}" for item, qty in r["ingredients"].items())
    embed.add_field(name="Materials Used",   value=ingr_used, inline=True)
    embed.add_field(name="Item Created",     value=f"`{r['output_qty']}×` **{r['emoji']} {recipe}**", inline=True)
    embed.add_field(name="Sell Value",       value=f"🪙 {_recipe_sell_value(recipe)}", inline=True)

    # Show updated inventory counts for used ingredients
    inv = player.get("inventory", {})
    remaining = "\n".join(
        f"  {item}: `{inv.get(item, 0)}` remaining"
        for item in r["ingredients"]
    )
    embed.add_field(name="Remaining Stock", value=remaining, inline=False)
    embed.set_thumbnail(url=interaction.user.display_avatar.url)
    embed.set_footer(text="Use /inventory to see your full inventory • /sell to sell crafted items")
    await interaction.response.send_message(embed=embed)

    if isinstance(interaction.user, discord.Member):
        await update_character_sheet(bot, player, interaction.user)
        save_players(data)


# ── Trade system ──────────────────────────────────────────────────────────────

active_trades: dict[str, dict] = {}   # trade_id → session dict


def _trade_id(uid1: str, uid2: str) -> str:
    return f"trade_{min(uid1, uid2)}_{max(uid1, uid2)}"


def _trade_embed(session: dict) -> discord.Embed:
    members = session["members"]
    embed = discord.Embed(
        title="🔄  Aetheria Trade",
        description=(
            "Add items or gold to your side, then both players click **✅ Confirm**.\n"
            "Any change resets both confirmations."
        ),
        color=0x00BCD4,
    )
    for side, icon in (("offerer", "📤"), ("offeree", "📥")):
        uid       = session[f"{side}_id"]
        m         = members.get(uid)
        name      = m.display_name if m else uid
        items     = session[f"{side}_items"]
        gold      = session[f"{side}_gold"]
        confirmed = session[f"{side}_confirmed"]
        item_lines = "\n".join(f"`{qty}×` {item}" for item, qty in items.items()) or "*Nothing*"
        status     = "✅  Confirmed" if confirmed else "⏳  Pending…"
        embed.add_field(
            name=f"{icon} {name} offers:",
            value=f"{item_lines}\n🪙 {gold:,}\n{status}",
            inline=True,
        )
    embed.set_footer(text="Session expires after 3 minutes of inactivity.")
    return embed


# ── Trade modals ───────────────────────────────────────────────────────────────

class AddItemModal(discord.ui.Modal, title="Add Item to Trade"):
    item_name = discord.ui.TextInput(label="Item Name", placeholder="e.g. Health Potion", max_length=60)
    quantity  = discord.ui.TextInput(label="Quantity", placeholder="1", default="1", max_length=4)

    def __init__(self, trade_id: str, side: str):
        super().__init__()
        self.trade_id = trade_id
        self.side     = side

    async def on_submit(self, interaction: discord.Interaction):
        session = active_trades.get(self.trade_id)
        if not session:
            await interaction.response.send_message("❌  Trade expired.", ephemeral=True)
            return

        uid    = str(interaction.user.id)
        data   = load_players()
        player = data.get(uid)
        if not player:
            await interaction.response.send_message("❌  No character found.", ephemeral=True)
            return

        inv     = player.get("inventory", {})
        raw     = self.item_name.value.strip()
        matched = next((k for k in inv if k.lower() == raw.lower()), None)
        if not matched:
            await interaction.response.send_message(
                f"❌  **{raw}** isn't in your inventory. Use `/inventory` to check.", ephemeral=True
            )
            return

        try:
            qty = max(1, int(self.quantity.value.strip()))
        except ValueError:
            qty = 1

        already = session[f"{self.side}_items"].get(matched, 0)
        if already + qty > inv.get(matched, 0):
            await interaction.response.send_message(
                f"❌  You only have `{inv.get(matched,0)}×` **{matched}** (already offering `{already}`).",
                ephemeral=True,
            )
            return

        session[f"{self.side}_items"][matched] = already + qty
        session["offerer_confirmed"] = False
        session["offeree_confirmed"] = False

        embed = _trade_embed(session)
        try:
            await session["message"].edit(embed=embed)
        except Exception:
            pass
        await interaction.response.send_message(
            f"✅  Added `{qty}×` **{matched}** to your offer.", ephemeral=True
        )


class AddGoldModal(discord.ui.Modal, title="Add Gold to Trade"):
    amount = discord.ui.TextInput(label="Gold Amount", placeholder="e.g. 500", max_length=10)

    def __init__(self, trade_id: str, side: str):
        super().__init__()
        self.trade_id = trade_id
        self.side     = side

    async def on_submit(self, interaction: discord.Interaction):
        session = active_trades.get(self.trade_id)
        if not session:
            await interaction.response.send_message("❌  Trade expired.", ephemeral=True)
            return

        uid    = str(interaction.user.id)
        data   = load_players()
        player = data.get(uid)
        if not player:
            await interaction.response.send_message("❌  No character found.", ephemeral=True)
            return

        try:
            gold = max(0, int(self.amount.value.strip().replace(",", "").replace(".", "")))
        except ValueError:
            await interaction.response.send_message("❌  Enter a whole number.", ephemeral=True)
            return

        if gold > player["gold"]:
            await interaction.response.send_message(
                f"❌  You only have 🪙 {player['gold']:,}.", ephemeral=True
            )
            return

        session[f"{self.side}_gold"]  = gold
        session["offerer_confirmed"]  = False
        session["offeree_confirmed"]  = False

        embed = _trade_embed(session)
        try:
            await session["message"].edit(embed=embed)
        except Exception:
            pass
        await interaction.response.send_message(
            f"✅  Set your gold offer to 🪙 **{gold:,}**.", ephemeral=True
        )


# ── TradeView ──────────────────────────────────────────────────────────────────

class TradeView(View):
    def __init__(self, session: dict):
        super().__init__(timeout=180)
        self.session = session

    def _side(self, uid: str) -> str | None:
        if uid == self.session["offerer_id"]: return "offerer"
        if uid == self.session["offeree_id"]: return "offeree"
        return None

    @discord.ui.button(label="🎒 Add Item", style=discord.ButtonStyle.primary, row=0)
    async def btn_add_item(self, interaction: discord.Interaction, _: discord.ui.Button):
        side = self._side(str(interaction.user.id))
        if not side:
            await interaction.response.send_message("⛔  You're not part of this trade.", ephemeral=True)
            return
        await interaction.response.send_modal(AddItemModal(self.session["id"], side))

    @discord.ui.button(label="🪙 Add Gold", style=discord.ButtonStyle.primary, row=0)
    async def btn_add_gold(self, interaction: discord.Interaction, _: discord.ui.Button):
        side = self._side(str(interaction.user.id))
        if not side:
            await interaction.response.send_message("⛔  You're not part of this trade.", ephemeral=True)
            return
        await interaction.response.send_modal(AddGoldModal(self.session["id"], side))

    @discord.ui.button(label="🗑️ Clear My Offer", style=discord.ButtonStyle.secondary, row=0)
    async def btn_clear(self, interaction: discord.Interaction, _: discord.ui.Button):
        side = self._side(str(interaction.user.id))
        if not side:
            await interaction.response.send_message("⛔  You're not part of this trade.", ephemeral=True)
            return
        self.session[f"{side}_items"]    = {}
        self.session[f"{side}_gold"]     = 0
        self.session["offerer_confirmed"] = False
        self.session["offeree_confirmed"] = False
        await interaction.response.edit_message(embed=_trade_embed(self.session), view=self)

    @discord.ui.button(label="✅ Confirm", style=discord.ButtonStyle.success, row=1)
    async def btn_confirm(self, interaction: discord.Interaction, _: discord.ui.Button):
        side = self._side(str(interaction.user.id))
        if not side:
            await interaction.response.send_message("⛔  You're not part of this trade.", ephemeral=True)
            return

        self.session[f"{side}_confirmed"] = True

        # Check if both confirmed → execute
        if self.session["offerer_confirmed"] and self.session["offeree_confirmed"]:
            data    = load_players()
            offerer = data.get(self.session["offerer_id"], {})
            offeree = data.get(self.session["offeree_id"], {})

            # Last-moment validation
            errors: list[str] = []
            for item, qty in self.session["offerer_items"].items():
                if offerer.get("inventory", {}).get(item, 0) < qty:
                    errors.append(f"{offerer.get('username','?')} is missing {qty}× {item}")
            for item, qty in self.session["offeree_items"].items():
                if offeree.get("inventory", {}).get(item, 0) < qty:
                    errors.append(f"{offeree.get('username','?')} is missing {qty}× {item}")
            if offerer.get("gold", 0) < self.session["offerer_gold"]:
                errors.append(f"{offerer.get('username','?')} doesn't have enough gold")
            if offeree.get("gold", 0) < self.session["offeree_gold"]:
                errors.append(f"{offeree.get('username','?')} doesn't have enough gold")

            if errors:
                self.session["offerer_confirmed"] = False
                self.session["offeree_confirmed"] = False
                await interaction.response.edit_message(
                    content="⚠️  Validation failed — offer reset:\n" + "\n".join(f"• {e}" for e in errors),
                    embed=_trade_embed(self.session), view=self,
                )
                return

            # ── Atomic transfer ────────────────────────────────────────────
            for item, qty in self.session["offerer_items"].items():
                remove_item(offerer, item, qty)
                add_item(offeree, item, qty)
            for item, qty in self.session["offeree_items"].items():
                remove_item(offeree, item, qty)
                add_item(offerer, item, qty)
            offerer["gold"] += self.session["offeree_gold"]  - self.session["offerer_gold"]
            offeree["gold"] += self.session["offerer_gold"]  - self.session["offeree_gold"]
            save_players(data)
            active_trades.pop(self.session["id"], None)
            self.stop()
            for item in self.children:
                item.disabled = True

            # Build result embed
            m_off = self.session["members"].get(self.session["offerer_id"])
            m_ofe = self.session["members"].get(self.session["offeree_id"])
            n_off = m_off.display_name if m_off else "?"
            n_ofe = m_ofe.display_name if m_ofe else "?"

            result = discord.Embed(
                title="✅  Trade Complete!",
                description="Items and gold have been exchanged.",
                color=0x4CAF50,
            )
            def _side_summary(items: dict, gold: int) -> str:
                lines = [f"`{qty}×` {it}" for it, qty in items.items()]
                if gold: lines.append(f"🪙 {gold:,}")
                return "\n".join(lines) if lines else "*nothing*"

            result.add_field(
                name=f"📤 {n_off} → {n_ofe}",
                value=_side_summary(self.session["offerer_items"], self.session["offerer_gold"]),
                inline=True,
            )
            result.add_field(
                name=f"📥 {n_ofe} → {n_off}",
                value=_side_summary(self.session["offeree_items"], self.session["offeree_gold"]),
                inline=True,
            )
            await interaction.response.edit_message(content=None, embed=result, view=self)

            # Update both character sheets
            for uid, m in self.session["members"].items():
                p = data.get(uid)
                if p and isinstance(m, discord.Member):
                    await update_character_sheet(bot, p, m)
            save_players(data)
            return

        # Only one side confirmed — update embed to show status
        await interaction.response.edit_message(embed=_trade_embed(self.session), view=self)

    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.danger, row=1)
    async def btn_cancel(self, interaction: discord.Interaction, _: discord.ui.Button):
        side = self._side(str(interaction.user.id))
        if not side:
            await interaction.response.send_message("⛔  You're not part of this trade.", ephemeral=True)
            return
        active_trades.pop(self.session["id"], None)
        self.stop()
        for item in self.children:
            item.disabled = True
        m    = self.session["members"].get(str(interaction.user.id))
        name = m.display_name if m else "Someone"
        await interaction.response.edit_message(
            embed=discord.Embed(description=f"❌  **{name}** cancelled the trade.", color=0xE74C3C),
            view=self,
        )

    async def on_timeout(self):
        active_trades.pop(self.session.get("id", ""), None)
        for item in self.children:
            item.disabled = True
        try:
            if self.session.get("message"):
                await self.session["message"].edit(
                    embed=discord.Embed(description="⏰  Trade expired after 3 minutes.", color=0x9E9E9E),
                    view=self,
                )
        except Exception:
            pass


# ── /trade ─────────────────────────────────────────────────────────────────────

@tree.command(name="trade", description="Open a trade window with another player.")
@app_commands.describe(partner="The player you want to trade with")
async def cmd_trade(interaction: discord.Interaction, partner: discord.Member):
    uid = str(interaction.user.id)
    pid = str(partner.id)

    if partner.id == interaction.user.id:
        await interaction.response.send_message("❌  You can't trade with yourself!", ephemeral=True)
        return
    if partner.bot:
        await interaction.response.send_message("❌  You can't trade with a bot.", ephemeral=True)
        return

    data = load_players()
    if uid not in data:
        await interaction.response.send_message("❌  Create a character first with `/create`!", ephemeral=True)
        return
    if pid not in data:
        await interaction.response.send_message(
            f"❌  **{partner.display_name}** doesn't have a character yet.", ephemeral=True
        )
        return

    trade_id = _trade_id(uid, pid)
    if trade_id in active_trades:
        await interaction.response.send_message(
            "❌  You already have an active trade with this player! Finish or cancel it first.",
            ephemeral=True,
        )
        return

    session: dict = {
        "id":                 trade_id,
        "offerer_id":         uid,
        "offeree_id":         pid,
        "offerer_items":      {},
        "offeree_items":      {},
        "offerer_gold":       0,
        "offeree_gold":       0,
        "offerer_confirmed":  False,
        "offeree_confirmed":  False,
        "members":            {uid: interaction.user, pid: partner},
        "message":            None,
    }
    active_trades[trade_id] = session

    embed = _trade_embed(session)
    embed.description = (
        f"**{interaction.user.display_name}** wants to trade with **{partner.display_name}**!\n\n"
        "Use the buttons below to add items or gold to your side, then both click **✅ Confirm** to execute."
    )
    view = TradeView(session)
    await interaction.response.send_message(embed=embed, view=view)
    session["message"] = await interaction.original_response()


# ══════════════════════════════════════════════════════════════════════════════
# ── GUILD SYSTEM ──────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

def load_guilds() -> dict:
    if GUILDS_FILE.exists():
        with open(GUILDS_FILE) as f:
            return json.load(f)
    return {}

def save_guilds(data: dict):
    GUILDS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(GUILDS_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def _guild_slug(name: str) -> str:
    import re
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")

def _guild_key(discord_guild_id: str | int, name: str) -> str:
    return f"{discord_guild_id}_{_guild_slug(name)}"

def _player_guild(guilds: dict, uid: str) -> tuple[str, dict] | tuple[None, None]:
    """Return (key, guild_dict) for the guild the player is in, or (None, None)."""
    for key, g in guilds.items():
        if uid in g["members"]:
            return key, g
    return None, None

async def _get_or_create_guild_role(
    discord_guild: discord.Guild, guild_name: str
) -> discord.Role | None:
    role = discord.utils.get(discord_guild.roles, name=guild_name)
    if role is None:
        try:
            role = await discord_guild.create_role(
                name=guild_name,
                hoist=True,
                mentionable=True,
                reason="Aetheria: player guild created",
            )
        except discord.Forbidden:
            return None
    return role

async def _assign_guild_role(member: discord.Member, guild_name: str):
    role = await _get_or_create_guild_role(member.guild, guild_name)
    if role:
        try:
            await member.add_roles(role, reason=f"Aetheria: joined guild {guild_name}")
        except discord.Forbidden:
            pass

async def _remove_guild_role(member: discord.Member, guild_name: str):
    role = discord.utils.get(member.guild.roles, name=guild_name)
    if role and role in member.roles:
        try:
            await member.remove_roles(role, reason=f"Aetheria: left guild {guild_name}")
        except discord.Forbidden:
            pass

async def _create_guild_camp(
    discord_guild: discord.Guild,
    guild_name: str,
    guild_role: discord.Role | None,
) -> discord.TextChannel | None:
    """Create a private guild camp text channel visible only to guild members."""
    channel_name = _guild_slug(guild_name).replace("_", "-")
    overwrites: dict = {
        discord_guild.default_role: discord.PermissionOverwrite(view_channel=False),
    }
    if guild_role:
        overwrites[guild_role] = discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            read_message_history=True,
            attach_files=True,
        )
    if discord_guild.me:
        overwrites[discord_guild.me] = discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            manage_messages=True,
            embed_links=True,
        )
    try:
        ch = await discord_guild.create_text_channel(
            name=f"camp-{channel_name}",
            overwrites=overwrites,
            topic=f"⚔️ Private Guild Camp for {guild_name} — members only.",
            reason=f"Aetheria: guild camp for {guild_name}",
        )
        return ch
    except discord.Forbidden:
        return None


async def _send_to_camp(guilds_data: dict, guild_key: str, embed: discord.Embed):
    """Post an embed into the guild's private camp channel."""
    g = guilds_data.get(guild_key)
    if not g:
        return
    camp_id = g.get("camp_channel_id")
    if not camp_id:
        return
    for dg in bot.guilds:
        if str(dg.id) == g["discord_guild_id"]:
            ch = dg.get_channel(int(camp_id))
            if ch and isinstance(ch, discord.TextChannel):
                try:
                    await ch.send(embed=embed)
                except discord.Forbidden:
                    pass
            break


GUILD_PERKS: dict[str, dict] = {
    "Expanded Roster I": {
        "emoji":    "🛡️",
        "cost":     5_000,
        "desc":     "Raise max members from 50 → 75.",
        "effect":   "member_cap_75",
        "requires": None,
    },
    "Expanded Roster II": {
        "emoji":    "🛡️🛡️",
        "cost":     15_000,
        "desc":     "Raise max members from 75 → 100.",
        "effect":   "member_cap_100",
        "requires": "Expanded Roster I",
    },
    "War Training": {
        "emoji":    "⚔️",
        "cost":     8_000,
        "desc":     "+15% XP from /daily for all guild members.",
        "effect":   "daily_xp_bonus",
        "requires": None,
    },
    "Battle Hardened": {
        "emoji":    "💪",
        "cost":     12_000,
        "desc":     "+10% combat power in /guild challenge.",
        "effect":   "challenge_power_bonus",
        "requires": "War Training",
    },
    "Merchant's Alliance": {
        "emoji":    "💰",
        "cost":     8_000,
        "desc":     "+20% gold from /daily for all guild members.",
        "effect":   "daily_gold_bonus",
        "requires": None,
    },
    "Guild Banner": {
        "emoji":    "🚩",
        "cost":     3_000,
        "desc":     "Unlock a custom motto shown on /guild info.",
        "effect":   "banner",
        "requires": None,
    },
}


def _guild_member_cap(g: dict) -> int:
    perks = g.get("perks", [])
    if "Expanded Roster II" in perks:
        return 100
    if "Expanded Roster I" in perks:
        return 75
    return MAX_GUILD_MEMBERS


def _guild_embed(g: dict, discord_guild: discord.Guild) -> discord.Embed:
    owner = discord_guild.get_member(int(g["owner_id"]))
    owner_str = owner.mention if owner else f"<@{g['owner_id']}>"

    vl_mentions = []
    for vid in g["vice_leaders"]:
        m = discord_guild.get_member(int(vid))
        vl_mentions.append(m.mention if m else f"<@{vid}>")

    regular = [uid for uid in g["members"] if uid != g["owner_id"] and uid not in g["vice_leaders"]]
    reg_mentions = []
    for uid in regular:
        m = discord_guild.get_member(int(uid))
        reg_mentions.append(m.mention if m else f"<@{uid}>")

    embed = discord.Embed(
        title=f"⚔️  {g['name']}",
        color=0xFFD700,
    )
    perks    = g.get("perks", [])
    cap      = _guild_member_cap(g)
    treasury = g.get("treasury", 0)
    banner   = g.get("banner", "")

    if banner:
        embed.description = f"*{banner}*"

    embed.add_field(name="👑 Guild Master", value=owner_str, inline=True)
    embed.add_field(name="Members", value=f"{len(g['members'])} / {cap}", inline=True)

    camp_id  = g.get("camp_channel_id")
    camp_str = f"<#{camp_id}>" if camp_id else "*Not created*"
    embed.add_field(name="🏕️ Guild Camp", value=camp_str, inline=True)

    embed.add_field(name="🏦 Treasury",   value=f"🪙 **{treasury:,}**", inline=True)

    wins   = g.get("challenge_wins", 0)
    losses = g.get("challenge_losses", 0)
    embed.add_field(name="⚔️ War Record", value=f"**{wins}W** — **{losses}L**", inline=True)
    embed.add_field(name="\u200b", value="\u200b", inline=True)

    if perks:
        perk_lines = []
        for p in perks:
            pd = GUILD_PERKS.get(p, {})
            perk_lines.append(f"{pd.get('emoji','✦')} **{p}** — {pd.get('desc','')}")
        embed.add_field(name="🔮 Active Perks", value="\n".join(perk_lines), inline=False)

    if vl_mentions:
        embed.add_field(name="🥈 Vice Leaders", value="\n".join(vl_mentions), inline=False)
    if reg_mentions:
        embed.add_field(name="🛡️ Members", value="\n".join(reg_mentions[:20]) + ("…" if len(reg_mentions) > 20 else ""), inline=False)

    created = g.get("created_at", "")[:10]
    embed.set_footer(text=f"Founded {created}  •  Aetheria Online")
    return embed


# ── Guild invite accept/decline view ──────────────────────────────────────────

class GuildInviteView(View):
    def __init__(self, inviter_id: int, invitee: discord.Member, guild_key: str, guild_name: str):
        super().__init__(timeout=120)
        self.inviter_id  = inviter_id
        self.invitee     = invitee
        self.guild_key   = guild_key
        self.guild_name  = guild_name

    async def _resolve(self, interaction: discord.Interaction, accepted: bool):
        if interaction.user.id != self.invitee.id:
            await interaction.response.send_message("This invite isn't for you.", ephemeral=True)
            return

        self.stop()
        for item in self.children:
            item.disabled = True  # type: ignore

        guilds  = load_guilds()
        players = load_players()
        uid     = str(interaction.user.id)
        g       = guilds.get(self.guild_key)

        if not accepted:
            await interaction.response.edit_message(
                content=f"❌ **{interaction.user.display_name}** declined the invitation to **{self.guild_name}**.",
                embed=None, view=self,
            )
            return

        # Validate: guild still exists, player not already in one, not full
        if not g:
            await interaction.response.edit_message(content="❌ That guild no longer exists.", embed=None, view=self)
            return
        _, existing = _player_guild(guilds, uid)
        if existing:
            await interaction.response.edit_message(
                content=f"❌ You're already in **{existing['name']}**. Leave first.", embed=None, view=self
            )
            return
        if len(g["members"]) >= MAX_GUILD_MEMBERS:
            await interaction.response.edit_message(content="❌ That guild is full.", embed=None, view=self)
            return

        # Join
        g["members"].append(uid)
        if uid in players:
            players[uid]["guild_key"] = self.guild_key
        save_guilds(guilds)
        save_players(players)

        if isinstance(interaction.user, discord.Member):
            await _assign_guild_role(interaction.user, self.guild_name)

        await interaction.response.edit_message(
            content=f"✅ **{interaction.user.display_name}** has joined **{self.guild_name}**!",
            embed=None, view=self,
        )

    @discord.ui.button(label="✅ Accept", style=discord.ButtonStyle.success)
    async def btn_accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._resolve(interaction, True)

    @discord.ui.button(label="❌ Decline", style=discord.ButtonStyle.danger)
    async def btn_decline(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._resolve(interaction, False)


# ── /guild command group ───────────────────────────────────────────────────────

guild_group = app_commands.Group(name="guild", description="Create and manage your player guild.")


@guild_group.command(name="create", description="Found a new guild. You will become its Guild Master.")
@app_commands.describe(name="The name of your guild (max 30 characters).")
async def guild_create(interaction: discord.Interaction, name: str):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    name = name.strip()
    if not name or len(name) > MAX_GUILD_NAME_LEN:
        await interaction.response.send_message(
            f"❌ Guild name must be 1–{MAX_GUILD_NAME_LEN} characters.", ephemeral=True
        )
        return

    players = load_players()
    uid     = str(interaction.user.id)
    if uid not in players:
        await interaction.response.send_message("❌ Create a character first with `/create`!", ephemeral=True)
        return

    guilds = load_guilds()
    dg_id  = str(interaction.guild.id)
    key    = _guild_key(dg_id, name)

    _, existing = _player_guild(guilds, uid)
    if existing:
        await interaction.response.send_message(
            f"❌ You're already in **{existing['name']}**. Leave or disband it first.", ephemeral=True
        )
        return
    if key in guilds:
        await interaction.response.send_message(
            f"❌ A guild named **{name}** already exists on this server.", ephemeral=True
        )
        return

    guilds[key] = {
        "name":              name,
        "discord_guild_id":  dg_id,
        "owner_id":          uid,
        "vice_leaders":      [],
        "members":           [uid],
        "created_at":        datetime.now(timezone.utc).isoformat(),
        "camp_channel_id":   None,
        "challenge_wins":    0,
        "challenge_losses":  0,
        "last_challenge":    None,
        "treasury":          0,
        "perks":             [],
        "donations":         {},
        "banner":            "",
    }
    players[uid]["guild_key"] = key
    save_guilds(guilds)
    save_players(players)

    # Create role first, then camp channel (channel overwrites need the role)
    role = await _get_or_create_guild_role(interaction.guild, name)
    await _assign_guild_role(interaction.user, name)
    camp = await _create_guild_camp(interaction.guild, name, role)
    if camp:
        guilds[key]["camp_channel_id"] = str(camp.id)
        save_guilds(guilds)

    # Chronicle
    se.log_chronicle(
        "guild_created",
        f"Guild **{name}** was founded by {interaction.user.display_name}.",
        {"guild_name": name, "founder": interaction.user.display_name},
    )
    chron_embed = discord.Embed(
        title=f"🏰 New Guild Founded: {name}",
        description=f"**{interaction.user.display_name}** has established a new guild in Aetheria. Adventurers are welcome.",
        color=0x4CAF50,
    )
    chron_embed.set_footer(text="Aetheria Chronicle • Guild Founded")
    await _post_to_chronicle(chron_embed)

    embed = discord.Embed(
        title=f"⚔️  Guild Founded: {name}",
        description=(
            f"**{interaction.user.display_name}** has founded **{name}**!\n\n"
            f"{'🏕️ Your private guild camp is ready: ' + camp.mention if camp else ''}\n\n"
            "Use `/guild invite` to recruit members, `/guild promote` to appoint a Vice Leader.\n"
            "Use `/guild challenge` to declare war on another guild!"
        ),
        color=0xFFD700,
    )
    embed.set_footer(text="Aetheria Online • Guild System")
    await interaction.response.send_message(embed=embed)

    # Welcome message in camp
    if camp:
        welcome = discord.Embed(
            title=f"🏕️  Welcome to {name}'s Camp!",
            description=(
                f"This is your guild's private space, {interaction.user.mention}.\n\n"
                "Only guild members can see and post here.\n"
                "Use `/guild invite` to bring your allies in."
            ),
            color=0xFFD700,
        )
        try:
            await camp.send(embed=welcome)
        except discord.Forbidden:
            pass


@guild_group.command(name="invite", description="Invite a player to your guild.")
@app_commands.describe(member="The player to invite.")
async def guild_invite(interaction: discord.Interaction, member: discord.Member):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    uid    = str(interaction.user.id)
    guilds = load_guilds()
    key, g = _player_guild(guilds, uid)

    if not g:
        await interaction.response.send_message("❌ You're not in a guild.", ephemeral=True)
        return
    if uid != g["owner_id"] and uid not in g["vice_leaders"]:
        await interaction.response.send_message("❌ Only the Guild Master or Vice Leaders can invite members.", ephemeral=True)
        return
    if member.bot:
        await interaction.response.send_message("❌ You can't invite bots.", ephemeral=True)
        return
    if str(member.id) in g["members"]:
        await interaction.response.send_message(f"❌ **{member.display_name}** is already in your guild.", ephemeral=True)
        return
    cap = _guild_member_cap(g)
    if len(g["members"]) >= cap:
        await interaction.response.send_message(f"❌ Your guild is full ({cap} members max). Upgrade with `/guild upgrade`.", ephemeral=True)
        return
    _, target_g = _player_guild(guilds, str(member.id))
    if target_g:
        await interaction.response.send_message(
            f"❌ **{member.display_name}** is already in **{target_g['name']}**.", ephemeral=True
        )
        return

    players = load_players()
    if str(member.id) not in players:
        await interaction.response.send_message(
            f"❌ **{member.display_name}** doesn't have an Aetheria character yet.", ephemeral=True
        )
        return

    embed = discord.Embed(
        title=f"⚔️  Guild Invitation",
        description=(
            f"{member.mention}, you have been invited to join **{g['name']}** "
            f"by **{interaction.user.display_name}**!\n\n"
            "You have 2 minutes to accept or decline."
        ),
        color=0xFFD700,
    )
    view = GuildInviteView(interaction.user.id, member, key, g["name"])
    await interaction.response.send_message(embed=embed, view=view)


@guild_group.command(name="kick", description="Remove a member from your guild.")
@app_commands.describe(member="The member to kick.")
async def guild_kick(interaction: discord.Interaction, member: discord.Member):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    uid    = str(interaction.user.id)
    tid    = str(member.id)
    guilds = load_guilds()
    key, g = _player_guild(guilds, uid)

    if not g:
        await interaction.response.send_message("❌ You're not in a guild.", ephemeral=True)
        return
    if uid != g["owner_id"] and uid not in g["vice_leaders"]:
        await interaction.response.send_message("❌ Only the Guild Master or Vice Leaders can kick members.", ephemeral=True)
        return
    if tid == uid:
        await interaction.response.send_message("❌ You can't kick yourself. Use `/guild leave` or `/guild disband`.", ephemeral=True)
        return
    if tid == g["owner_id"]:
        await interaction.response.send_message("❌ You can't kick the Guild Master.", ephemeral=True)
        return
    if tid not in g["members"]:
        await interaction.response.send_message(f"❌ **{member.display_name}** is not in your guild.", ephemeral=True)
        return
    # Vice leaders can't kick other vice leaders
    if uid in g["vice_leaders"] and tid in g["vice_leaders"]:
        await interaction.response.send_message("❌ Vice Leaders cannot kick other Vice Leaders.", ephemeral=True)
        return

    g["members"].remove(tid)
    if tid in g["vice_leaders"]:
        g["vice_leaders"].remove(tid)
    save_guilds(guilds)

    players = load_players()
    if tid in players:
        players[tid].pop("guild_key", None)
        save_players(players)

    await _remove_guild_role(member, g["name"])

    embed = discord.Embed(
        description=f"🚪 **{member.display_name}** has been removed from **{g['name']}**.",
        color=0xE53935,
    )
    await interaction.response.send_message(embed=embed)


@guild_group.command(name="promote", description="Promote a member to Vice Leader.")
@app_commands.describe(member="The member to promote.")
async def guild_promote(interaction: discord.Interaction, member: discord.Member):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    uid    = str(interaction.user.id)
    tid    = str(member.id)
    guilds = load_guilds()
    key, g = _player_guild(guilds, uid)

    if not g:
        await interaction.response.send_message("❌ You're not in a guild.", ephemeral=True)
        return
    if uid != g["owner_id"]:
        await interaction.response.send_message("❌ Only the Guild Master can promote members.", ephemeral=True)
        return
    if tid not in g["members"]:
        await interaction.response.send_message(f"❌ **{member.display_name}** is not in your guild.", ephemeral=True)
        return
    if tid in g["vice_leaders"]:
        await interaction.response.send_message(f"❌ **{member.display_name}** is already a Vice Leader.", ephemeral=True)
        return
    if tid == uid:
        await interaction.response.send_message("❌ You're already the Guild Master.", ephemeral=True)
        return

    g["vice_leaders"].append(tid)
    save_guilds(guilds)

    embed = discord.Embed(
        description=f"🥈 **{member.display_name}** has been promoted to Vice Leader of **{g['name']}**!",
        color=0xFFD700,
    )
    await interaction.response.send_message(embed=embed)


@guild_group.command(name="demote", description="Demote a Vice Leader back to member.")
@app_commands.describe(member="The Vice Leader to demote.")
async def guild_demote(interaction: discord.Interaction, member: discord.Member):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    uid    = str(interaction.user.id)
    tid    = str(member.id)
    guilds = load_guilds()
    key, g = _player_guild(guilds, uid)

    if not g:
        await interaction.response.send_message("❌ You're not in a guild.", ephemeral=True)
        return
    if uid != g["owner_id"]:
        await interaction.response.send_message("❌ Only the Guild Master can demote Vice Leaders.", ephemeral=True)
        return
    if tid not in g["vice_leaders"]:
        await interaction.response.send_message(f"❌ **{member.display_name}** is not a Vice Leader.", ephemeral=True)
        return

    g["vice_leaders"].remove(tid)
    save_guilds(guilds)

    embed = discord.Embed(
        description=f"🛡️ **{member.display_name}** has been demoted to member in **{g['name']}**.",
        color=0x9E9E9E,
    )
    await interaction.response.send_message(embed=embed)


@guild_group.command(name="leave", description="Leave your current guild.")
async def guild_leave(interaction: discord.Interaction):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    uid    = str(interaction.user.id)
    guilds = load_guilds()
    key, g = _player_guild(guilds, uid)

    if not g:
        await interaction.response.send_message("❌ You're not in a guild.", ephemeral=True)
        return
    if uid == g["owner_id"]:
        await interaction.response.send_message(
            "❌ You're the Guild Master — you can't leave. Use `/guild disband` to dissolve the guild, "
            "or `/guild transfer` to pass leadership (contact a Vice Leader).",
            ephemeral=True,
        )
        return

    g["members"].remove(uid)
    if uid in g["vice_leaders"]:
        g["vice_leaders"].remove(uid)
    save_guilds(guilds)

    players = load_players()
    if uid in players:
        players[uid].pop("guild_key", None)
        save_players(players)

    await _remove_guild_role(interaction.user, g["name"])

    embed = discord.Embed(
        description=f"🚪 You have left **{g['name']}**.",
        color=0x9E9E9E,
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@guild_group.command(name="disband", description="Permanently disband your guild (Guild Master only).")
async def guild_disband(interaction: discord.Interaction):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    uid    = str(interaction.user.id)
    guilds = load_guilds()
    key, g = _player_guild(guilds, uid)

    if not g:
        await interaction.response.send_message("❌ You're not in a guild.", ephemeral=True)
        return
    if uid != g["owner_id"]:
        await interaction.response.send_message("❌ Only the Guild Master can disband the guild.", ephemeral=True)
        return

    guild_name = g["name"]
    member_ids = list(g["members"])

    # Remove the guild
    del guilds[key]
    save_guilds(guilds)

    # Clear guild_key from all members
    players = load_players()
    for mid in member_ids:
        if mid in players:
            players[mid].pop("guild_key", None)
    save_players(players)

    # Delete the guild camp channel
    camp_id = g.get("camp_channel_id")
    if camp_id:
        ch = interaction.guild.get_channel(int(camp_id))
        if ch:
            try:
                await ch.delete(reason=f"Aetheria: guild {guild_name} disbanded")
            except discord.Forbidden:
                pass

    # Remove the Discord role from everyone and delete it
    role = discord.utils.get(interaction.guild.roles, name=guild_name)
    if role:
        try:
            await role.delete(reason=f"Aetheria: guild {guild_name} disbanded")
        except discord.Forbidden:
            pass

    embed = discord.Embed(
        title=f"💀  Guild Disbanded",
        description=f"**{guild_name}** has been dissolved. Its members walk alone.",
        color=0xE53935,
    )
    await interaction.response.send_message(embed=embed)


@guild_group.command(name="info", description="View info about your guild or search by name.")
@app_commands.describe(name="Guild name to look up (leave empty to view your own).")
async def guild_info(interaction: discord.Interaction, name: str = ""):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    guilds = load_guilds()
    dg_id  = str(interaction.guild.id)

    if name:
        key = _guild_key(dg_id, name.strip())
        g   = guilds.get(key)
        if not g or g["discord_guild_id"] != dg_id:
            await interaction.response.send_message(f"❌ No guild named **{name.strip()}** found.", ephemeral=True)
            return
    else:
        uid = str(interaction.user.id)
        key, g = _player_guild(guilds, uid)
        if not g:
            await interaction.response.send_message("❌ You're not in a guild. Use `/guild create` or get invited.", ephemeral=True)
            return

    embed = _guild_embed(g, interaction.guild)
    await interaction.response.send_message(embed=embed)


@guild_group.command(name="list", description="List all active guilds on this server.")
async def guild_list(interaction: discord.Interaction):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    guilds = load_guilds()
    dg_id  = str(interaction.guild.id)
    server_guilds = [(k, g) for k, g in guilds.items() if g["discord_guild_id"] == dg_id]

    if not server_guilds:
        await interaction.response.send_message("⚔️ No guilds have been founded on this server yet. Use `/guild create`!", ephemeral=True)
        return

    embed = discord.Embed(
        title="⚔️  Guilds of Aetheria",
        description=f"{len(server_guilds)} guild(s) active on this server.",
        color=0xFFD700,
    )
    for _, g in sorted(server_guilds, key=lambda x: -len(x[1]["members"])):
        owner = interaction.guild.get_member(int(g["owner_id"]))
        owner_name = owner.display_name if owner else f"<@{g['owner_id']}>"
        embed.add_field(
            name=f"⚔️  {g['name']}",
            value=f"👑 {owner_name}  •  🛡️ {len(g['members'])} members",
            inline=False,
        )
    embed.set_footer(text="Aetheria Online • Guild System")
    await interaction.response.send_message(embed=embed)


CHALLENGE_COOLDOWN_H  = 24
CHALLENGE_WIN_GOLD    = 400   # gold per winner member
CHALLENGE_LOSS_GOLD   = 75    # consolation gold per loser member


def _guild_power(member_ids: list[str], players: dict, perks: list | None = None) -> int:
    """Sum total stats of all guild members who have characters."""
    total = 0
    for uid in member_ids:
        p = players.get(uid)
        if not p:
            continue
        origin = p.get("origin_class")
        stats  = compute_stats(p["race"], p["class"], p["level"], origin)
        total += sum(stats.values())
    if perks and "Battle Hardened" in perks:
        total = int(total * 1.10)
    return total


class GuildChallengeView(View):
    def __init__(
        self,
        challenger_key: str,
        challenged_key: str,
        challenger_name: str,
        challenged_name: str,
        challenger_master_id: int,
        challenged_master_id: int,
    ):
        super().__init__(timeout=180)
        self.challenger_key       = challenger_key
        self.challenged_key       = challenged_key
        self.challenger_name      = challenger_name
        self.challenged_name      = challenged_name
        self.challenger_master_id = challenger_master_id
        self.challenged_master_id = challenged_master_id

    async def _resolve(self, interaction: discord.Interaction, accepted: bool):
        uid = interaction.user.id
        if uid != self.challenged_master_id:
            # Also let vice leaders respond
            guilds = load_guilds()
            g = guilds.get(self.challenged_key, {})
            if str(uid) not in g.get("vice_leaders", []):
                await interaction.response.send_message(
                    "Only the challenged guild's Master or Vice Leaders can respond.", ephemeral=True
                )
                return

        self.stop()
        for item in self.children:
            item.disabled = True  # type: ignore

        guilds  = load_guilds()
        chal    = guilds.get(self.challenger_key)
        chald   = guilds.get(self.challenged_key)

        if not chal or not chald:
            await interaction.response.edit_message(
                content="❌ One of the guilds no longer exists.", embed=None, view=self
            )
            return

        if not accepted:
            chal["last_challenge"] = None   # reset cooldown on decline
            save_guilds(guilds)
            embed = discord.Embed(
                description=f"🏳️ **{self.challenged_name}** has declined the challenge from **{self.challenger_name}**.",
                color=0x9E9E9E,
            )
            await interaction.response.edit_message(embed=embed, view=self)
            return

        # ── Run the battle ──────────────────────────────────────────────────
        players = load_players()
        pow_a   = _guild_power(chal["members"],  players, chal.get("perks"))
        pow_b   = _guild_power(chald["members"], players, chald.get("perks"))

        # Add ±20 % randomness so smaller guilds can still win
        roll_a  = pow_a * random.uniform(0.80, 1.20)
        roll_b  = pow_b * random.uniform(0.80, 1.20)

        if roll_a >= roll_b:
            winner_key, winner = self.challenger_key, chal
            loser_key,  loser  = self.challenged_key, chald
            winner_pow, loser_pow = int(pow_a), int(pow_b)
        else:
            winner_key, winner = self.challenged_key, chald
            loser_key,  loser  = self.challenger_key, chal
            winner_pow, loser_pow = int(pow_b), int(pow_a)

        # Update stats & distribute gold
        winner["challenge_wins"]   = winner.get("challenge_wins",   0) + 1
        loser["challenge_losses"]  = loser.get("challenge_losses",  0) + 1
        now_iso = datetime.now(timezone.utc).isoformat()
        chal["last_challenge"]  = now_iso
        chald["last_challenge"] = now_iso
        save_guilds(guilds)

        for uid in winner["members"]:
            if uid in players:
                players[uid]["gold"] = players[uid].get("gold", 0) + CHALLENGE_WIN_GOLD
        for uid in loser["members"]:
            if uid in players:
                players[uid]["gold"] = players[uid].get("gold", 0) + CHALLENGE_LOSS_GOLD
        save_players(players)

        # ── Result embed ────────────────────────────────────────────────────
        result = discord.Embed(
            title="⚔️  GUILD WAR RESULT",
            description=(
                f"## 🏆  {winner['name']} VICTORIOUS!\n\n"
                f"The war between **{self.challenger_name}** and **{self.challenged_name}** has ended."
            ),
            color=0xFFD700,
        )
        result.add_field(
            name=f"⚔️  {self.challenger_name}",
            value=f"Power: `{int(pow_a):,}`",
            inline=True,
        )
        result.add_field(
            name=f"⚔️  {self.challenged_name}",
            value=f"Power: `{int(pow_b):,}`",
            inline=True,
        )
        result.add_field(name="\u200b", value="\u200b", inline=True)
        result.add_field(
            name="🏆 Winner",
            value=f"**{winner['name']}** — each member earns 🪙 **{CHALLENGE_WIN_GOLD:,}**",
            inline=True,
        )
        result.add_field(
            name="🏳️ Defeated",
            value=f"**{loser['name']}** — consolation 🪙 **{CHALLENGE_LOSS_GOLD:,}** per member",
            inline=True,
        )
        result.set_footer(text="Aetheria Online • Guild Wars")

        await interaction.response.edit_message(embed=result, view=self)

        # Post to #announcements
        await _post_to_announcements(result)

        # Post result summaries to each guild camp
        winner_camp_msg = discord.Embed(
            title="🏆  Victory!",
            description=f"Your guild defeated **{loser['name']}** in glorious battle!\nEach member receives 🪙 **{CHALLENGE_WIN_GOLD:,}**.",
            color=0xFFD700,
        )
        loser_camp_msg = discord.Embed(
            title="🏳️  Defeated",
            description=f"Your guild fell to **{winner['name']}** in battle.\nConsolation: 🪙 **{CHALLENGE_LOSS_GOLD:,}** per member. Train harder.",
            color=0xE53935,
        )
        await _send_to_camp(guilds, winner_key, winner_camp_msg)
        await _send_to_camp(guilds, loser_key,  loser_camp_msg)

        # Chronicle + story engine
        chapter = se.on_war_end(self.challenger_name, self.challenged_name, winner["name"])
        chron_embed = discord.Embed(
            title=chapter["title"],
            description=chapter["text"],
            color=0xFFD700,
        )
        chron_embed.set_footer(text="Aetheria Chronicle • Guild War")
        await _post_to_chronicle(chron_embed)
        se.log_chronicle(
            "guild_challenge_win",
            f"**{winner['name']}** defeated **{loser['name']}** in guild battle.",
            {"winner": winner["name"], "loser": loser["name"]},
        )

    @discord.ui.button(label="⚔️ Accept the Challenge", style=discord.ButtonStyle.danger)
    async def btn_accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._resolve(interaction, True)

    @discord.ui.button(label="🏳️ Decline", style=discord.ButtonStyle.secondary)
    async def btn_decline(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._resolve(interaction, False)


@guild_group.command(name="challenge", description="Declare war on another guild!")
@app_commands.describe(name="The name of the guild you want to challenge.")
async def guild_challenge(interaction: discord.Interaction, name: str):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    uid    = str(interaction.user.id)
    guilds = load_guilds()
    dg_id  = str(interaction.guild.id)

    my_key, my_g = _player_guild(guilds, uid)
    if not my_g:
        await interaction.response.send_message("❌ You're not in a guild.", ephemeral=True)
        return
    if uid != my_g["owner_id"] and uid not in my_g["vice_leaders"]:
        await interaction.response.send_message("❌ Only the Guild Master or Vice Leaders can issue challenges.", ephemeral=True)
        return

    # Cooldown check (24 h)
    last = my_g.get("last_challenge")
    if last:
        since = datetime.now(timezone.utc) - datetime.fromisoformat(last)
        if since.total_seconds() < CHALLENGE_COOLDOWN_H * 3600:
            remaining = timedelta(hours=CHALLENGE_COOLDOWN_H) - since
            h = int(remaining.total_seconds() // 3600)
            m = int((remaining.total_seconds() % 3600) // 60)
            await interaction.response.send_message(
                f"⏳ Your guild can challenge again in **{h}h {m}m**.", ephemeral=True
            )
            return

    target_key = _guild_key(dg_id, name.strip())
    target_g   = guilds.get(target_key)
    if not target_g or target_g["discord_guild_id"] != dg_id:
        await interaction.response.send_message(f"❌ No guild named **{name.strip()}** found on this server.", ephemeral=True)
        return
    if target_key == my_key:
        await interaction.response.send_message("❌ You can't challenge your own guild.", ephemeral=True)
        return

    # Set placeholder cooldown so the guild can't spam challenges while waiting
    my_g["last_challenge"] = datetime.now(timezone.utc).isoformat()
    save_guilds(guilds)

    target_master_id = int(target_g["owner_id"])
    players = load_players()
    pow_me     = _guild_power(my_g["members"],     players, my_g.get("perks"))
    pow_them   = _guild_power(target_g["members"], players, target_g.get("perks"))

    embed = discord.Embed(
        title="⚔️  GUILD WAR DECLARED!",
        description=(
            f"**{my_g['name']}** has challenged **{target_g['name']}** to battle!\n\n"
            f"<@{target_g['owner_id']}>, do you accept?"
        ),
        color=0xE53935,
    )
    embed.add_field(name=f"⚔️  {my_g['name']}",     value=f"{len(my_g['members'])} warriors • Power `{pow_me:,}`",     inline=True)
    embed.add_field(name=f"⚔️  {target_g['name']}", value=f"{len(target_g['members'])} warriors • Power `{pow_them:,}`", inline=True)
    embed.add_field(
        name="Stakes",
        value=f"🏆 Winners each earn 🪙 **{CHALLENGE_WIN_GOLD:,}**\n🏳️ Losers each earn 🪙 **{CHALLENGE_LOSS_GOLD:,}** consolation",
        inline=False,
    )
    embed.set_footer(text="Guild Master or Vice Leaders of the challenged guild have 3 minutes to respond.")

    view = GuildChallengeView(
        challenger_key       = my_key,
        challenged_key       = target_key,
        challenger_name      = my_g["name"],
        challenged_name      = target_g["name"],
        challenger_master_id = int(my_g["owner_id"]),
        challenged_master_id = target_master_id,
    )
    await interaction.response.send_message(embed=embed, view=view)

    # Also post to both guild camps
    camp_embed = discord.Embed(
        title="⚔️  War Declared!",
        description=f"Your guild has been challenged by **{my_g['name']}**! The Master or a Vice Leader must respond in #announcements.",
        color=0xE53935,
    )
    await _send_to_camp(guilds, target_key, camp_embed)
    notif = discord.Embed(
        title="⚔️  Challenge Sent!",
        description=f"You have challenged **{target_g['name']}**. Await their response.",
        color=0xFFD700,
    )
    await _send_to_camp(guilds, my_key, notif)


@guild_group.command(name="donate", description="Donate gold to your guild's treasury.")
@app_commands.describe(amount="Amount of gold to donate.")
async def guild_donate(interaction: discord.Interaction, amount: int):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return
    if amount <= 0:
        await interaction.response.send_message("❌ Amount must be positive.", ephemeral=True)
        return

    uid     = str(interaction.user.id)
    players = load_players()
    if uid not in players:
        await interaction.response.send_message("❌ Create a character first with `/create`!", ephemeral=True)
        return

    player = players[uid]
    if player["gold"] < amount:
        await interaction.response.send_message(
            f"❌ You only have 🪙 **{player['gold']:,}**.", ephemeral=True
        )
        return

    guilds = load_guilds()
    key, g = _player_guild(guilds, uid)
    if not g:
        await interaction.response.send_message("❌ You're not in a guild.", ephemeral=True)
        return

    player["gold"] -= amount
    g["treasury"]   = g.get("treasury", 0) + amount
    g["donations"]  = g.get("donations", {})
    g["donations"][uid] = g["donations"].get(uid, 0) + amount
    save_players(players)
    save_guilds(guilds)

    embed = discord.Embed(
        description=(
            f"🏦 **{interaction.user.display_name}** donated 🪙 **{amount:,}** to **{g['name']}**!\n"
            f"Treasury: 🪙 **{g['treasury']:,}**"
        ),
        color=0xFFD700,
    )
    await interaction.response.send_message(embed=embed)

    # Notify the camp
    camp_msg = discord.Embed(
        title="🏦 Donation Received!",
        description=f"{interaction.user.mention} donated 🪙 **{amount:,}**. Treasury now at 🪙 **{g['treasury']:,}**.",
        color=0xFFD700,
    )
    await _send_to_camp(guilds, key, camp_msg)


async def _perk_autocomplete(interaction: discord.Interaction, current: str):
    uid    = str(interaction.user.id)
    guilds = load_guilds()
    _, g   = _player_guild(guilds, uid)
    if not g:
        return []
    owned = g.get("perks", [])
    choices = []
    for name, pd in GUILD_PERKS.items():
        if name in owned:
            continue
        req = pd.get("requires")
        if req and req not in owned:
            continue
        label = f"{pd['emoji']} {name} — 🪙 {pd['cost']:,} — {pd['desc']}"
        if current.lower() in name.lower():
            choices.append(app_commands.Choice(name=label[:100], value=name))
    return choices[:25]


@guild_group.command(name="upgrade", description="Spend guild treasury gold to unlock a perk.")
@app_commands.describe(perk="The perk to unlock.")
@app_commands.autocomplete(perk=_perk_autocomplete)
async def guild_upgrade(interaction: discord.Interaction, perk: str):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    uid    = str(interaction.user.id)
    guilds = load_guilds()
    key, g = _player_guild(guilds, uid)

    if not g:
        await interaction.response.send_message("❌ You're not in a guild.", ephemeral=True)
        return
    if uid != g["owner_id"] and uid not in g.get("vice_leaders", []):
        await interaction.response.send_message("❌ Only the Guild Master or Vice Leaders can purchase upgrades.", ephemeral=True)
        return
    if perk not in GUILD_PERKS:
        await interaction.response.send_message("❌ Unknown perk. Use the autocomplete to pick one.", ephemeral=True)
        return

    pd    = GUILD_PERKS[perk]
    owned = g.get("perks", [])
    if perk in owned:
        await interaction.response.send_message(f"❌ Your guild already has **{perk}**.", ephemeral=True)
        return
    req = pd.get("requires")
    if req and req not in owned:
        await interaction.response.send_message(
            f"❌ **{perk}** requires **{req}** first.", ephemeral=True
        )
        return

    treasury = g.get("treasury", 0)
    if treasury < pd["cost"]:
        await interaction.response.send_message(
            f"❌ Not enough treasury gold. Need 🪙 **{pd['cost']:,}**, have 🪙 **{treasury:,}**.\n"
            f"Members can donate with `/guild donate`.",
            ephemeral=True,
        )
        return

    g["treasury"] = treasury - pd["cost"]
    g.setdefault("perks", []).append(perk)
    save_guilds(guilds)

    embed = discord.Embed(
        title=f"{pd['emoji']}  Perk Unlocked: {perk}!",
        description=(
            f"**{g['name']}** has unlocked **{perk}**!\n\n"
            f"{pd['desc']}\n\n"
            f"Treasury remaining: 🪙 **{g['treasury']:,}**"
        ),
        color=0xFFD700,
    )
    embed.set_footer(text="Aetheria Online • Guild Upgrades")
    await interaction.response.send_message(embed=embed)

    camp_msg = discord.Embed(
        title=f"{pd['emoji']}  New Guild Perk: {perk}",
        description=f"Your guild just unlocked **{perk}**!\n{pd['desc']}",
        color=0xFFD700,
    )
    await _send_to_camp(guilds, key, camp_msg)


@guild_group.command(name="perks", description="View all available guild perks and their costs.")
async def guild_perks(interaction: discord.Interaction):
    uid    = str(interaction.user.id)
    guilds = load_guilds()
    _, g   = _player_guild(guilds, uid)
    owned  = g.get("perks", []) if g else []

    embed = discord.Embed(
        title="🔮  Guild Perk Tree",
        description="Spend your guild treasury to unlock powerful upgrades for all members.",
        color=0xFFD700,
    )
    for name, pd in GUILD_PERKS.items():
        req = pd.get("requires")
        if name in owned:
            status = "✅ **Unlocked**"
        elif req and req not in owned:
            status = f"🔒 Requires **{req}**"
        else:
            status = f"🪙 **{pd['cost']:,}** to unlock"
        embed.add_field(
            name=f"{pd['emoji']}  {name}",
            value=f"{pd['desc']}\n{status}",
            inline=False,
        )
    treasury = g.get("treasury", 0) if g else 0
    embed.set_footer(text=f"Guild Treasury: 🪙 {treasury:,}  •  Donate with /guild donate")
    await interaction.response.send_message(embed=embed, ephemeral=True)


@guild_group.command(name="setbanner", description="Set a custom motto for your guild (requires Guild Banner perk).")
@app_commands.describe(text="Your guild's motto or description (max 100 characters).")
async def guild_setbanner(interaction: discord.Interaction, text: str):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    uid    = str(interaction.user.id)
    guilds = load_guilds()
    key, g = _player_guild(guilds, uid)

    if not g:
        await interaction.response.send_message("❌ You're not in a guild.", ephemeral=True)
        return
    if uid != g["owner_id"] and uid not in g.get("vice_leaders", []):
        await interaction.response.send_message("❌ Only the Guild Master or Vice Leaders can set the banner.", ephemeral=True)
        return
    if "Guild Banner" not in g.get("perks", []):
        await interaction.response.send_message(
            "❌ Your guild needs the **Guild Banner** perk first. Unlock it with `/guild upgrade`.", ephemeral=True
        )
        return

    text = text.strip()[:100]
    g["banner"] = text
    save_guilds(guilds)

    await interaction.response.send_message(
        f"🚩 Guild banner set to: *\"{text}\"*", ephemeral=True
    )


tree.add_command(guild_group)


# ══════════════════════════════════════════════════════════════════════════════
# ── HIDDEN CLASSES ────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

HIDDEN_CLASSES: dict[str, dict] = {
    "Dragon Knight": {
        "emoji":   "🐲",
        "color":   0xFF5722,
        "lore":    "A warrior who has bonded with dragon blood itself. Their strikes carry the fury of ancient wyrms.",
        "reveal":  "The ground trembles. Scales ripple across skin. A Dragon Knight has awakened.",
        "conditions": {
            "races":   ["Drakonian"],
            "classes": ["Warrior", "Paladin"],
            "level":   50,
            "items":   [],
        },
    },
    "Archmage": {
        "emoji":   "🌌",
        "color":   0x3F51B5,
        "lore":    "The pinnacle of magical mastery. An Archmage bends the very laws of reality.",
        "reveal":  "Arcane constellations form overhead. The universe itself bows to an Archmage.",
        "conditions": {
            "races":   ["High Elf", "Elf"],
            "classes": ["Mage"],
            "level":   60,
            "items":   ["Arcane Staff"],
        },
    },
    "Demon Emperor": {
        "emoji":   "👑",
        "color":   0xB71C1C,
        "lore":    "A demon who has transcended all limits — not merely powerful, but terrifyingly sovereign.",
        "reveal":  "Hellfire ignites the horizon. All lesser demons kneel. The Demon Emperor rises.",
        "conditions": {
            "races":   ["Demon"],
            "classes": ["Necromancer", "Berserker"],
            "level":   65,
            "items":   [],
        },
    },
    "Archangel": {
        "emoji":   "🕊️",
        "color":   0xFFF9C4,
        "lore":    "Ascended beyond mortality, an Archangel radiates divine light that scorches the corrupt.",
        "reveal":  "Golden wings tear through the clouds. A divine horn sounds. An Archangel has ascended.",
        "conditions": {
            "races":   ["Angel"],
            "classes": ["Paladin"],
            "level":   55,
            "items":   ["Angel's Grace"],
        },
    },
    "Shadow Monarch": {
        "emoji":   "👁️",
        "color":   0x1A237E,
        "lore":    "Ruler of all shadows. The Shadow Monarch commands darkness as an extension of their own will.",
        "reveal":  "Light flees. Shadows pool and writhe. The Shadow Monarch has claimed their throne.",
        "conditions": {
            "races":   ["Dark Elf", "Vampire"],
            "classes": ["Assassin", "Necromancer"],
            "level":   60,
            "items":   ["Shadowblade"],
        },
    },
    "World Wanderer": {
        "emoji":   "🌍",
        "color":   0x00695C,
        "lore":    "One who has walked every road in every realm. Their experience is a weapon no blade can match.",
        "reveal":  "The world itself pauses. A hero who has seen everything steps into legend as a World Wanderer.",
        "conditions": {
            "races":   [],   # any
            "classes": [],   # any
            "level":   80,
            "items":   [],
        },
    },
    "Titan Slayer": {
        "emoji":   "⚡",
        "color":   0x795548,
        "lore":    "Born to bring down titans. Their strength is not merely physical — it is mythic.",
        "reveal":  "The earth splits. Mountains crack. A Titan Slayer stands where giants once did.",
        "conditions": {
            "races":   ["Titanblood", "Orc"],
            "classes": ["Berserker", "Warrior"],
            "level":   55,
            "items":   ["Dragonscale Armour"],
        },
    },
    "Lord of the Void": {
        "emoji":   "🌀",
        "color":   0x311B92,
        "lore":    "Master of the space between worlds. The Void Lord erases enemies from existence itself.",
        "reveal":  "Reality tears open. Stars wink out. A Lord of the Void has emerged from the abyss.",
        "conditions": {
            "races":   ["Demon", "Vampire"],
            "classes": ["Necromancer"],
            "level":   70,
            "items":   ["Crystal of Eternity"],
        },
    },
}

ANNOUNCEMENTS_CHANNEL = "welt-events"


async def _post_to_announcements(embed: discord.Embed):
    """Post an embed to #welt-events in every guild the bot is in."""
    for guild in bot.guilds:
        ch = discord.utils.get(guild.text_channels, name=ANNOUNCEMENTS_CHANNEL)
        if ch:
            try:
                await ch.send(embed=embed)
            except discord.Forbidden:
                pass


async def _post_to_chronicle(embed: discord.Embed):
    """Post an embed to #weltchronik in every guild the bot is in."""
    for guild in bot.guilds:
        ch = discord.utils.get(guild.text_channels, name=CHRONICLE_CHANNEL)
        if ch:
            try:
                await ch.send(embed=embed)
            except discord.Forbidden:
                pass


def _check_hidden_class_conditions(player: dict) -> str | None:
    """Return the name of a newly eligible hidden class, or None."""
    if player.get("hidden_class"):
        return None   # already has one

    inv = player.get("inventory", {})
    race  = player.get("race", "")
    cls   = player.get("class", "")
    level = player.get("level", 1)

    for name, hc in HIDDEN_CLASSES.items():
        c = hc["conditions"]
        race_ok  = not c["races"]   or race  in c["races"]
        class_ok = not c["classes"] or cls   in c["classes"]
        level_ok = level >= c["level"]
        items_ok = all(inv.get(item, 0) > 0 for item in c["items"])
        if race_ok and class_ok and level_ok and items_ok:
            return name
    return None


_HIDDEN_CLASS_RARITY = 0.15   # 15% chance to awaken per trigger, even if conditions met


async def _grant_hidden_class_role(guild: discord.Guild, member: discord.Member, class_name: str, color: int):
    """Find or create a role for the hidden class and assign it."""
    role = discord.utils.get(guild.roles, name=class_name)
    if role is None:
        try:
            role = await guild.create_role(
                name=class_name,
                color=discord.Color(color),
                hoist=True,
                mentionable=False,
                reason="Aetheria: hidden class unlocked",
            )
        except discord.Forbidden:
            return   # Bot lacks Manage Roles permission — skip silently
    try:
        await member.add_roles(role, reason=f"Aetheria: {class_name} hidden class awakened")
    except discord.Forbidden:
        pass


async def trigger_hidden_class(player: dict, member: discord.Member, data: dict):
    """Unlock a hidden class for a player with a rarity gate, role grant, and two-stage announcement."""
    unlocked = _check_hidden_class_conditions(player)
    if not unlocked:
        return

    # Ultra-rare: 15% chance per trigger even when all conditions are met
    if random.random() > _HIDDEN_CLASS_RARITY:
        return

    hc = HIDDEN_CLASSES[unlocked]
    player["hidden_class"] = unlocked
    player["origin_class"] = player["class"]   # remember the class they came from
    player["class"] = unlocked
    save_players(data)

    await update_character_sheet(bot, player, member)

    # ── Grant Discord role in the member's guild ────────────────────────────
    if member.guild:
        await _grant_hidden_class_role(member.guild, member, unlocked, hc["color"])

    # ── Stage 1: Ominous foreboding message ────────────────────────────────
    foreboding = discord.Embed(
        title="🌑  Something Stirs in the World of Aetheria…",
        description=(
            "*The air grows heavy. Ancient seals tremble.\n"
            "The threads of fate are shifting — something hidden is awakening.\n\n"
            "A hero among heroes stands at the threshold of legend.*"
        ),
        color=0x1a1a2e,
    )
    foreboding.set_footer(text="Aetheria Online • A power sealed since the dawn of time…")

    # Post foreboding to all guilds, remember the messages to follow up
    foreboding_messages: list[discord.Message] = []
    for guild in bot.guilds:
        ch = discord.utils.get(guild.text_channels, name=ANNOUNCEMENTS_CHANNEL)
        if ch:
            try:
                msg = await ch.send(embed=foreboding)
                foreboding_messages.append(msg)
            except discord.Forbidden:
                pass

    # ── 4-second dramatic pause ─────────────────────────────────────────────
    import asyncio
    await asyncio.sleep(4)

    # ── Stage 2: Full reveal ────────────────────────────────────────────────
    r = RACES.get(player["race"], {})
    reveal = discord.Embed(
        title=f"✦  A HIDDEN CLASS HAS AWAKENED  ✦",
        description=(
            f"# {hc['emoji']}  {unlocked}\n\n"
            f"*\"{hc['reveal']}\"*\n\n"
            f"**{member.display_name}** has transcended their mortal class.\n"
            f"They are now one of the rarest beings in all of Aetheria."
        ),
        color=hc["color"],
    )
    reveal.add_field(
        name="The Legend",
        value=hc["lore"],
        inline=False,
    )
    reveal.add_field(
        name="Who?",
        value=f"{r.get('emoji', '')} **{player['race']}** · Level **{player['level']}** · {member.mention}",
        inline=True,
    )
    reveal.add_field(
        name="Class Role",
        value=f"🎖️ **{unlocked}** role granted",
        inline=True,
    )
    reveal.set_thumbnail(url=member.display_avatar.url)
    reveal.set_footer(text="✦  These classes cannot be chosen. Only the most worthy are chosen by them.  ✦")

    for guild in bot.guilds:
        ch = discord.utils.get(guild.text_channels, name=ANNOUNCEMENTS_CHANNEL)
        if ch:
            try:
                await ch.send(embed=reveal)
            except discord.Forbidden:
                pass


# ══════════════════════════════════════════════════════════════════════════════
# ── WORLD EVENTS ──────────────────────────────────════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════

WORLD_EVENTS: list[dict] = [
    {
        "title":  "🐉  Dragon Sighting Over the Shattered Peaks",
        "color":  0xFF5722,
        "desc":   "A colossal shadow darkens the sky above the Shattered Peaks. Witnesses describe scales the colour of midnight and eyes like burning stars. The Dragon Queen Seraphex has been seen circling — and she is not alone.",
        "footer": "Adventurers are warned to travel in groups.",
    },
    {
        "title":  "🌀  Void Rift Detected in the Ancient Catacombs",
        "color":  0x311B92,
        "desc":   "Guild scouts report a growing tear in reality deep within the Ancient Catacombs. Strange creatures with no eyes and no sound have been seen slipping through. The Arcane Council has declared a state of alert.",
        "footer": "Approach the rift only if you dare.",
    },
    {
        "title":  "🌙  Blood Moon Rises Over Aetheria",
        "color":  0x880E4F,
        "desc":   "The moon bleeds crimson tonight. Vampires stir restlessly. Dark magic is amplified tenfold. Strange howls echo from the Verdant Labyrinth, and the dead refuse to stay buried.",
        "footer": "The night holds more danger than usual.",
    },
    {
        "title":  "⚡  Titan Awakens in the Frozen Wastes",
        "color":  0x795548,
        "desc":   "A tremor measuring 9 on the Runic Scale has been detected in the Frozen Wastes. A Titan — sealed for over a thousand years beneath the glaciers — has begun to stir. Its first steps have already flattened three settlements.",
        "footer": "Only a Titan Slayer could hope to stand against it.",
    },
    {
        "title":  "✨  Celestial Alignment: The Starfall Convergence",
        "color":  0x1A237E,
        "desc":   "For the first time in 400 years, all seven arcane stars have aligned. Mages report their spells casting themselves. Ancient runes glow without being activated. Magic is wild and unpredictable tonight.",
        "footer": "A rare night for discovery — and catastrophe.",
    },
    {
        "title":  "🔥  The Burning Wastes Expand",
        "color":  0xE64A19,
        "desc":   "The Lava Elementals of the Burning Wastes have breached their ancient containment wards. Villages to the east have been evacuated. The Drakonian clans are mobilising, claiming this is an omen of rebirth.",
        "footer": "Heroes near the Burning Wastes should exercise extreme caution.",
    },
    {
        "title":  "💀  The Lich King Stirs",
        "color":  0x212121,
        "desc":   "Necromancers across the realm have reported the same vision in their scrying mirrors — the Lich King Malachar, defeated a century ago, slowly reassembling his phylactery. His undead legions have begun marching from the Shadow Realm.",
        "footer": "The dead walk again. Aetheria must prepare.",
    },
    {
        "title":  "🌊  The Drowned Harbour Awakens",
        "color":  0x006064,
        "desc":   "The sunken ruins of Old Aetheria's harbour have risen from the sea floor. Ancient treasure — and ancient curses — have surfaced with them. Sea Serpents guard the perimeter. The brave may find relics beyond measure.",
        "footer": "Fortune favours the reckless.",
    },
    {
        "title":  "🧚  The Fae Wild Bleeds Into Our World",
        "color":  0x7B1FA2,
        "desc":   "Fairies have been spotted beyond the Verdant Labyrinth — further into civilised lands than ever before. Wherever they dance, reality warps: flowers bloom in winter, time slips, and people forget their names.",
        "footer": "Do not make deals with the Fae. Ever.",
    },
    {
        "title":  "👁️  The Shadow Realm Expands",
        "color":  0x1A237E,
        "desc":   "Dark Elf sentinels stationed at the Shadow Realm border have gone silent. Their last message: *'It is watching us back.'* The shadow now creeps beyond its boundaries, devouring light wherever it spreads.",
        "footer": "Only those who master shadow can hope to reclaim it.",
    },
    {
        "title":  "🏔️  Ancient Dwarven Vault Unearthed",
        "color":  0x5D4037,
        "desc":   "Deep in the Shattered Peaks, Dwarven miners have broken through to a sealed vault dating back to the First Era. Inside: weapons, armour, and artefacts of unimaginable craftsmanship — and a warning etched in blood-rune: *'Do not wake what sleeps here.'*",
        "footer": "The Dwarven Blacksmiths are already arguing over who gets first pick.",
    },
    {
        "title":  "🕊️  Celestial Host Descends on the Storm Coast",
        "color":  0xFFF8E1,
        "desc":   "A host of Angels has descended upon the Storm Coast without warning or explanation. They have formed a wall of divine light facing the sea. No one knows what approaches from the deep — but they are preparing for war.",
        "footer": "Pray the Angels hold.",
    },
    {
        "title":  "🦊  The Kitsune Festival of Illusions",
        "color":  0xFF8F00,
        "desc":   "The Kitsune clans have declared the Festival of a Thousand Illusions. For three days and nights, reality in the Emerald Swamp will not be trusted. Heroes who enter may see their deepest fears — or their greatest desires.",
        "footer": "What is real? In the Emerald Swamp tonight, no one can say.",
    },
    {
        "title":  "⚔️  The Great Guild War: Ceasefire Broken",
        "color":  0xC62828,
        "desc":   "After six months of uneasy peace, the Ceasefire Accord between the Northern and Southern Guilds has collapsed. Skirmishes have already begun near the Obsidian Plateau. Heroes are being recruited on both sides for enormous gold bounties.",
        "footer": "Choose your allegiances carefully.",
    },
    {
        "title":  "💎  The Philosopher's Stone — A Second One Found?",
        "color":  0x6A1B9A,
        "desc":   "A wandering merchant arrived in the capital claiming to carry a second Philosopher's Stone — a relic thought to be unique. Alchemists are furious. Collectors are desperate. And someone has already tried to steal it.",
        "footer": "Aetheria's rarest relic may no longer be so rare.",
    },
]

# Interval in minutes between world event announcements
_EVENT_INTERVAL_MIN = 120
_event_next_fire: datetime = datetime.now(timezone.utc) + timedelta(minutes=_EVENT_INTERVAL_MIN)


@tasks.loop(minutes=5)
async def world_event_loop():
    """Every 5 minutes, check if it's time to fire a random world event."""
    global _event_next_fire
    now = datetime.now(timezone.utc)
    if now < _event_next_fire:
        return

    # Pick a random event
    event = random.choice(WORLD_EVENTS)
    embed = discord.Embed(
        title=event["title"],
        description=event["desc"],
        color=event["color"],
    )
    embed.set_footer(text=f"Aetheria Online • World Event  •  {event['footer']}")
    await _post_to_announcements(embed)

    # Chronicle
    chron_embed = discord.Embed(
        title=f"🌍 {event['title']}",
        description=event["desc"][:500],
        color=event["color"],
    )
    chron_embed.set_footer(text="Aetheria Chronicle • World Event")
    await _post_to_chronicle(chron_embed)
    se.log_chronicle("world_event", f"World event concluded: {event['title']}")

    # Schedule next event: base interval ± 30 min randomness
    jitter = random.randint(-30, 30)
    _event_next_fire = now + timedelta(minutes=_EVENT_INTERVAL_MIN + jitter)
    print(f"[Aetheria] World event fired. Next in ~{_EVENT_INTERVAL_MIN + jitter} min.")


@world_event_loop.before_loop
async def before_world_event_loop():
    await bot.wait_until_ready()


# ══════════════════════════════════════════════════════════════════════════════
# ── NPC SYSTEM ────────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

# ── NPC autocomplete ──────────────────────────────────────────────────────────

async def _npc_ac(interaction: discord.Interaction, current: str):
    choices = npc_eng.npc_autocomplete_choices(current)
    return [app_commands.Choice(name=label[:100], value=nid) for label, nid in choices]

# ── Shop UI ───────────────────────────────────────────────────────────────────

class _BuySelect(discord.ui.Select):
    def __init__(self, npc: dict, uid: str, stock: dict, rep: int):
        self.npc = npc
        self.uid = uid
        options = [
            discord.SelectOption(
                label=item,
                description=f"🪙 {npc_eng.price_with_rep(info['price'], rep):,} each — {info['qty']} left",
                value=item,
            )
            for item, info in stock.items()
        ][:25]
        super().__init__(placeholder="Choose an item to buy (1×)…", options=options, row=0)

    async def callback(self, interaction: discord.Interaction):
        uid  = str(interaction.user.id)
        item = self.values[0]
        players = load_players()
        if uid not in players:
            await interaction.response.send_message("❌ Create a character first with `/create`!", ephemeral=True)
            return
        player = players[uid]
        rep    = npc_eng.get_reputation(uid, self.npc["id"])
        db     = npc_eng.load_npc_db()
        raw    = db.get("stock", {}).get(self.npc["id"], {}).get("items", {}).get(item)
        if not raw:
            await interaction.response.send_message("❌ That item is no longer available.", ephemeral=True)
            return
        price = npc_eng.price_with_rep(raw["price"], rep)
        if player["gold"] < price:
            await interaction.response.send_message(
                f"❌ Need 🪙 **{price:,}** — you have 🪙 **{player['gold']:,}**.", ephemeral=True
            )
            return
        ok, msg, cost = npc_eng.buy_from_npc(uid, self.npc, item, 1)
        if ok:
            player["gold"] -= cost
            player.setdefault("inventory", {})[item] = player["inventory"].get(item, 0) + 1
            save_players(players)
        await interaction.response.send_message(f"{'✅' if ok else '❌'} {msg}", ephemeral=True)


class _SellSelect(discord.ui.Select):
    def __init__(self, npc: dict, uid: str, player: dict):
        self.npc = npc
        self.uid = uid
        inv = player.get("inventory", {})
        options = [
            discord.SelectOption(label=f"{item} ×{qty}", value=item)
            for item, qty in inv.items()
        ][:25]
        if not options:
            options = [discord.SelectOption(label="(Inventory empty)", value="__empty__")]
        super().__init__(placeholder="Choose an item to sell (1×)…", options=options, row=1)

    async def callback(self, interaction: discord.Interaction):
        uid  = str(interaction.user.id)
        item = self.values[0]
        if item == "__empty__":
            await interaction.response.send_message("Your inventory is empty.", ephemeral=True)
            return
        players = load_players()
        if uid not in players:
            await interaction.response.send_message("❌ No character found.", ephemeral=True)
            return
        player = players[uid]
        inv = player.get("inventory", {})
        if not inv.get(item):
            await interaction.response.send_message(f"❌ You don't have **{item}**.", ephemeral=True)
            return
        BASE_SELL = {
            "Health Potion": 75, "Mana Potion": 85, "Elixir of Fortune": 320,
            "Ancient Rune": 200, "Shadow Essence": 340, "Dragon Scale Fragment": 500,
        }
        base = BASE_SELL.get(item, 50)
        ok, msg, earned = npc_eng.sell_to_npc(uid, self.npc, item, 1, base)
        if ok:
            inv[item] -= 1
            if inv[item] == 0:
                del inv[item]
            player["gold"] += earned
            save_players(players)
        await interaction.response.send_message(f"{'✅' if ok else '❌'} {msg}", ephemeral=True)


class _ShopView(discord.ui.View):
    def __init__(self, npc: dict, uid: str, stock: dict, rep: int, player: dict):
        super().__init__(timeout=90)
        self.add_item(_BuySelect(npc, uid, stock, rep))
        if player.get("inventory"):
            self.add_item(_SellSelect(npc, uid, player))


# ── Forge UI ──────────────────────────────────────────────────────────────────

class _ForgeSelect(discord.ui.Select):
    def __init__(self, npc: dict, uid: str, recipes: list):
        self.npc = npc
        self.uid = uid
        options = [
            discord.SelectOption(
                label=("✦ " if r["legendary"] else "") + r["name"],
                description=r["reason"][:100],
                value=r["name"],
            )
            for r in recipes
        ][:25]
        super().__init__(placeholder="Choose a recipe to forge…", options=options)

    async def callback(self, interaction: discord.Interaction):
        uid       = str(interaction.user.id)
        item_name = self.values[0]
        players   = load_players()
        if uid not in players:
            await interaction.response.send_message("❌ Create a character first!", ephemeral=True)
            return
        player = players[uid]
        ok, msg = npc_eng.craft_blacksmith_item(player, self.npc, item_name)
        if ok:
            save_players(players)
            npc_eng.change_reputation(uid, self.npc["id"], 2)
        await interaction.response.send_message(f"{'✅' if ok else '❌'} {msg}", ephemeral=True)


class _ForgeView(discord.ui.View):
    def __init__(self, npc: dict, uid: str, recipes: list):
        super().__init__(timeout=90)
        self.add_item(_ForgeSelect(npc, uid, recipes))


# ── Training UI ───────────────────────────────────────────────────────────────

class _TrainSelect(discord.ui.Select):
    def __init__(self, npc: dict, uid: str, opts: list):
        self.npc = npc
        self.uid = uid
        options = [
            discord.SelectOption(
                label=o["name"],
                description=o["reason"][:100],
                value=o["name"],
                emoji=("✅" if o["learned"] else ("🔮" if o["can_learn"] else "🔒")),
            )
            for o in opts
        ][:25]
        super().__init__(placeholder="Choose an ability to learn…", options=options)

    async def callback(self, interaction: discord.Interaction):
        uid     = str(interaction.user.id)
        ability = self.values[0]
        players = load_players()
        if uid not in players:
            await interaction.response.send_message("❌ Create a character first!", ephemeral=True)
            return
        player   = players[uid]
        training = self.npc["training"].get(ability)
        if not training:
            await interaction.response.send_message("❌ Unknown ability.", ephemeral=True)
            return
        ok, msg = npc_eng.learn_ability(player, self.npc["id"], ability, training)
        if ok:
            save_players(players)
            npc_eng.change_reputation(uid, self.npc["id"], 3)
            if isinstance(interaction.user, discord.Member):
                await update_character_sheet(bot, player, interaction.user)
        await interaction.response.send_message(f"{'✅' if ok else '❌'} {msg}", ephemeral=True)


class _TrainView(discord.ui.View):
    def __init__(self, npc: dict, uid: str, opts: list):
        super().__init__(timeout=90)
        self.add_item(_TrainSelect(npc, uid, opts))


# ── Talk action buttons ───────────────────────────────────────────────────────

class _OpenShopBtn(discord.ui.Button):
    def __init__(self, npc: dict):
        super().__init__(label="🛒 Browse Shop", style=discord.ButtonStyle.primary)
        self.npc = npc

    async def callback(self, interaction: discord.Interaction):
        uid     = str(interaction.user.id)
        players = load_players()
        player  = players.get(uid, {})
        stock   = npc_eng.get_npc_stock(self.npc)
        rep     = npc_eng.get_reputation(uid, self.npc["id"])
        if not stock:
            await interaction.response.send_message("*Out of stock today — come back tomorrow!*", ephemeral=True)
            return
        embed = discord.Embed(title=f"🛒 {self.npc['name']} — Today's Stock", color=0xFFD700)
        for item, info in stock.items():
            price = npc_eng.price_with_rep(info["price"], rep)
            embed.add_field(name=item, value=f"🪙 **{price:,}**  •  `{info['qty']}`×", inline=True)
        embed.add_field(name="📊 Reputation", value=npc_eng.rep_bar(rep), inline=False)
        embed.set_footer(text="Top row: Buy  •  Bottom row: Sell  •  Stock refreshes daily")
        view = _ShopView(self.npc, uid, stock, rep, player)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


class _OpenForgeBtn(discord.ui.Button):
    def __init__(self, npc: dict):
        super().__init__(label="⚒️ View Forge", style=discord.ButtonStyle.primary)
        self.npc = npc

    async def callback(self, interaction: discord.Interaction):
        uid     = str(interaction.user.id)
        players = load_players()
        if uid not in players:
            await interaction.response.send_message("❌ Create a character first!", ephemeral=True)
            return
        player  = players[uid]
        recipes = npc_eng.get_blacksmith_recipes(self.npc, player)
        embed   = discord.Embed(
            title=f"⚒️ {self.npc['name']} — Forge",
            description="Select a recipe below to craft it.",
            color=0x607D8B,
        )
        for r in recipes:
            mats = ", ".join(f"{qty}× {mat}" for mat, qty in r["recipe"]["mats"].items())
            embed.add_field(
                name=("⚡ " if r["legendary"] else "") + r["name"],
                value=f"{r['recipe']['desc']}\n**Mats:** {mats}  •  🪙 {r['recipe'].get('gold', 0):,}\n{r['reason']}",
                inline=False,
            )
        view = _ForgeView(self.npc, uid, recipes)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


class _HearRumorBtn(discord.ui.Button):
    def __init__(self, npc: dict):
        super().__init__(label="🍺 Hear a Rumour", style=discord.ButtonStyle.secondary)
        self.npc = npc

    async def callback(self, interaction: discord.Interaction):
        ws    = se.load_world_state()
        rumor = npc_eng.get_innkeeper_rumor(self.npc, ws, interaction.user.display_name)
        embed = discord.Embed(
            title=f"🍺 {self.npc['name']} leans in…",
            description=f'*"{rumor}"*',
            color=0x795548,
        )
        embed.set_footer(text="Aetheria Online • Tavern Rumours")
        await interaction.response.send_message(embed=embed, ephemeral=True)
        npc_eng.change_reputation(str(interaction.user.id), self.npc["id"], 1)


class _OpenTrainBtn(discord.ui.Button):
    def __init__(self, npc: dict):
        super().__init__(label="🔮 View Training", style=discord.ButtonStyle.primary)
        self.npc = npc

    async def callback(self, interaction: discord.Interaction):
        uid     = str(interaction.user.id)
        players = load_players()
        if uid not in players:
            await interaction.response.send_message("❌ Create a character first!", ephemeral=True)
            return
        player = players[uid]
        opts   = npc_eng.get_training_options(self.npc, player)
        embed  = discord.Embed(
            title=f"🔮 {self.npc['name']} — Training",
            description="Permanent stat bonuses. Select one to learn.",
            color=0x673AB7,
        )
        for o in opts:
            t = o["training"]
            embed.add_field(
                name=o["name"],
                value=f"{t['desc']}\n🪙 {t.get('gold', 0):,}  •  Req Lv {t.get('level_req', 1)}\n{o['reason']}",
                inline=False,
            )
        embed.add_field(name="👛 Your Gold", value=f"🪙 **{player['gold']:,}**", inline=True)
        view = _TrainView(self.npc, uid, opts)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


class _ViewMountBtn(discord.ui.Button):
    def __init__(self, npc: dict):
        super().__init__(label="🐎 View Mounts", style=discord.ButtonStyle.primary)
        self.npc = npc

    async def callback(self, interaction: discord.Interaction):
        uid    = str(interaction.user.id)
        mounts = npc_eng.get_player_mounts(uid)
        owned  = mounts.get("owned", [])
        active = mounts.get("active")
        embed  = discord.Embed(title=f"🐎 {self.npc['name']} — Mount Catalogue", color=0x8D6E63)
        for name, m in npc_eng.MOUNT_REGISTRY.items():
            if name == active:    status = "🟢 **Equipped**"
            elif name in owned:   status = "✅ Owned"
            else:
                req    = f"  •  Req Lv **{m['level_req']}**" if m.get("level_req", 1) > 1 else ""
                status = f"🪙 **{m['gold']:,}**{req}"
            bonus_parts = []
            if m.get("bonus_xp"):   bonus_parts.append(f"+{m['bonus_xp']}% XP")
            if m.get("bonus_gold"): bonus_parts.append(f"+{m['bonus_gold']}% Gold")
            bonus_str = f"  •  {' / '.join(bonus_parts)}" if bonus_parts else ""
            embed.add_field(name=f"{m['emoji']} {name}", value=f"{m['desc']}{bonus_str}\n{status}", inline=False)
        embed.set_footer(text="/mount buy <name>  •  /mount equip <name>")
        await interaction.response.send_message(embed=embed, ephemeral=True)


class _OpenBankBtn(discord.ui.Button):
    def __init__(self):
        super().__init__(label="🏦 Check Account", style=discord.ButtonStyle.secondary)

    async def callback(self, interaction: discord.Interaction):
        uid      = str(interaction.user.id)
        interest = npc_eng._apply_bank_interest(uid)
        acc      = npc_eng.get_bank_account(uid)
        players  = load_players()
        wallet   = players.get(uid, {}).get("gold", 0)
        embed    = discord.Embed(title="🏦 Royal Bank of Valoria — Your Account", color=0x1565C0)
        embed.add_field(name="🏦 Bank Balance", value=f"🪙 **{acc['balance']:,}**", inline=True)
        embed.add_field(name="👛 Wallet",        value=f"🪙 **{wallet:,}**",           inline=True)
        if interest:
            embed.add_field(name="📈 Interest Today", value=f"🪙 **+{interest:,}** (2%)", inline=False)
        embed.set_footer(text="2% daily interest  •  /bank deposit / withdraw / transfer")
        await interaction.response.send_message(embed=embed, ephemeral=True)


class NpcTalkView(discord.ui.View):
    def __init__(self, npc: dict, uid: str):
        super().__init__(timeout=120)
        ntype = npc["type"]
        if ntype == "merchant":
            self.add_item(_OpenShopBtn(npc))
        if ntype == "blacksmith":
            self.add_item(_OpenForgeBtn(npc))
        if ntype == "innkeeper":
            self.add_item(_HearRumorBtn(npc))
        if ntype == "mage_master":
            self.add_item(_OpenTrainBtn(npc))
        if ntype == "stable_master":
            self.add_item(_ViewMountBtn(npc))
        if ntype == "banker":
            self.add_item(_OpenBankBtn())


# ── /talk ─────────────────────────────────────────────────────────────────────

@tree.command(name="talk", description="Talk to an NPC in Aetheria — merchants, innkeepers, faction leaders and more.")
@app_commands.describe(npc="The NPC to approach (start typing to search).")
@app_commands.autocomplete(npc=_npc_ac)
async def cmd_talk(interaction: discord.Interaction, npc: str):
    npc_data = npc_eng.NPC_REGISTRY.get(npc) or npc_eng.npc_by_name(npc)
    if not npc_data:
        await interaction.response.send_message(
            "❌ NPC not found. Use the autocomplete to search for valid NPCs.", ephemeral=True
        )
        return

    uid     = str(interaction.user.id)
    players = load_players()
    player  = players.get(uid)
    ws      = se.load_world_state()

    greeting = npc_eng.get_npc_greeting(npc_data, interaction.user.display_name, ws)
    rep      = npc_eng.get_reputation(uid, npc_data["id"])

    type_labels = {
        "merchant":         "🏪 Merchant",
        "innkeeper":        "🍺 Innkeeper",
        "blacksmith":       "⚒️ Blacksmith",
        "quest_giver":      "📋 Quest Giver",
        "mage_master":      "🔮 Mage Master",
        "stable_master":    "🐎 Stable Master",
        "banker":           "🏦 Banker",
        "guild_master_npc": "🏛️ Guild Master",
        "faction_leader":   "👑 Faction Leader",
    }
    color_map = {
        "merchant": 0xFFD700, "innkeeper": 0x795548, "blacksmith": 0x607D8B,
        "quest_giver": 0x2196F3, "mage_master": 0x673AB7, "stable_master": 0x8D6E63,
        "banker": 0x1565C0, "guild_master_npc": 0x4CAF50, "faction_leader": 0xE53935,
    }

    embed = discord.Embed(
        title=f"{npc_data['emoji']}  {npc_data['name']}",
        description=greeting,
        color=color_map.get(npc_data["type"], 0x9E9E9E),
    )
    embed.add_field(name="📍 Location", value=npc_data["location"],                      inline=True)
    embed.add_field(name="⚑ Faction",  value=npc_data["faction"],                        inline=True)
    embed.add_field(name="🔖 Role",     value=type_labels.get(npc_data["type"], "NPC"),   inline=True)
    embed.add_field(name="📜 About",    value=npc_data["description"],                    inline=False)
    if player:
        embed.add_field(name="📊 Your Reputation", value=npc_eng.rep_bar(rep), inline=False)
    embed.set_footer(text="Aetheria Online • NPC System")

    view = NpcTalkView(npc_data, uid) if player else None
    await interaction.response.send_message(embed=embed, view=view)
    npc_eng.change_reputation(uid, npc_data["id"], 1)


# ── /npcshop ──────────────────────────────────────────────────────────────────

@tree.command(name="npcshop", description="Browse and buy items directly from an NPC merchant.")
@app_commands.describe(npc="The merchant NPC to shop at.")
@app_commands.autocomplete(npc=_npc_ac)
async def cmd_npcshop(interaction: discord.Interaction, npc: str):
    npc_data = npc_eng.NPC_REGISTRY.get(npc) or npc_eng.npc_by_name(npc)
    if not npc_data or npc_data["type"] != "merchant":
        await interaction.response.send_message(
            "❌ That NPC isn't a merchant. Try `/talk` and use autocomplete to find merchants (Arkon, Selene, Borik).",
            ephemeral=True,
        )
        return

    uid     = str(interaction.user.id)
    players = load_players()
    if uid not in players:
        await interaction.response.send_message("❌ Create a character first with `/create`!", ephemeral=True)
        return
    player = players[uid]
    stock  = npc_eng.get_npc_stock(npc_data)
    rep    = npc_eng.get_reputation(uid, npc_data["id"])

    embed = discord.Embed(
        title=f"🛒 {npc_data['name']} — Today's Stock",
        description=f"📍 {npc_data['location']}",
        color=0xFFD700,
    )
    if not stock:
        embed.description = "*Out of stock today — come back tomorrow!*"
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    for item, info in stock.items():
        price = npc_eng.price_with_rep(info["price"], rep)
        embed.add_field(name=item, value=f"🪙 **{price:,}**  •  `{info['qty']}`× left", inline=True)
    embed.add_field(name="📊 Reputation", value=npc_eng.rep_bar(rep), inline=False)
    embed.add_field(name="👛 Your Gold",  value=f"🪙 **{player['gold']:,}**",            inline=True)
    embed.set_footer(text="Top menu: Buy  •  Bottom menu: Sell  •  Stock refreshes daily")

    view = _ShopView(npc_data, uid, stock, rep, player)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


# ── /train ────────────────────────────────────────────────────────────────────

@tree.command(name="train", description="Learn permanent stat abilities from a Mage Master NPC.")
@app_commands.describe(npc="The Mage Master NPC to train with.")
@app_commands.autocomplete(npc=_npc_ac)
async def cmd_train(interaction: discord.Interaction, npc: str):
    npc_data = npc_eng.NPC_REGISTRY.get(npc) or npc_eng.npc_by_name(npc)
    if not npc_data or npc_data["type"] != "mage_master":
        await interaction.response.send_message(
            "❌ That NPC isn't a Mage Master. Try Archmage Eldor (Seraphis) or Mystic Selara (Sylvandor).",
            ephemeral=True,
        )
        return

    uid     = str(interaction.user.id)
    players = load_players()
    if uid not in players:
        await interaction.response.send_message("❌ Create a character first with `/create`!", ephemeral=True)
        return
    player = players[uid]
    opts   = npc_eng.get_training_options(npc_data, player)

    embed = discord.Embed(
        title=f"🔮 {npc_data['name']} — Training",
        description=(
            f"*{random.choice(npc_data['greetings']).format(name=interaction.user.display_name)}*\n\n"
            "Abilities grant **permanent stat bonuses** to your character."
        ),
        color=0x673AB7,
    )
    for o in opts:
        t = o["training"]
        embed.add_field(
            name=o["name"],
            value=f"{t['desc']}\n🪙 **{t.get('gold', 0):,}**  •  Req Lv **{t.get('level_req', 1)}**\n{o['reason']}",
            inline=False,
        )
    embed.add_field(name="👛 Your Gold",   value=f"🪙 **{player['gold']:,}**",   inline=True)
    embed.add_field(name="⚡ Known",        value=", ".join(player.get("abilities", [])) or "None", inline=True)
    view = _TrainView(npc_data, uid, opts)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


# ── /bank ─────────────────────────────────────────────────────────────────────

bank_group = app_commands.Group(name="bank", description="Royal Bank of Valoria — store and transfer gold.")
tree.add_command(bank_group)


@bank_group.command(name="balance", description="Check your bank balance and collect daily 2% interest.")
async def bank_balance(interaction: discord.Interaction):
    uid      = str(interaction.user.id)
    interest = npc_eng._apply_bank_interest(uid)
    acc      = npc_eng.get_bank_account(uid)
    players  = load_players()
    wallet   = players.get(uid, {}).get("gold", 0)

    embed = discord.Embed(title="🏦 Royal Bank of Valoria", color=0x1565C0)
    embed.add_field(name="🏦 Bank Balance", value=f"🪙 **{acc['balance']:,}**", inline=True)
    embed.add_field(name="👛 Wallet",        value=f"🪙 **{wallet:,}**",           inline=True)
    if interest:
        embed.add_field(name="📈 Interest Earned Today", value=f"🪙 **+{interest:,}** (2% daily)", inline=False)
    embed.set_footer(text="2% daily interest on deposited gold  •  Bank with Vesper in Valoria")
    await interaction.response.send_message(embed=embed)


@bank_group.command(name="deposit", description="Deposit gold from your wallet into the bank.")
@app_commands.describe(amount="Amount of gold to deposit.")
async def bank_deposit_cmd(interaction: discord.Interaction, amount: int):
    uid     = str(interaction.user.id)
    players = load_players()
    if uid not in players:
        await interaction.response.send_message("❌ Create a character first with `/create`!", ephemeral=True)
        return
    player = players[uid]
    ok, msg = npc_eng.bank_deposit(uid, player, amount)
    if ok:
        save_players(players)
    await interaction.response.send_message(f"{'✅' if ok else '❌'} {msg}")


@bank_group.command(name="withdraw", description="Withdraw gold from the bank to your wallet.")
@app_commands.describe(amount="Amount of gold to withdraw.")
async def bank_withdraw_cmd(interaction: discord.Interaction, amount: int):
    uid     = str(interaction.user.id)
    players = load_players()
    if uid not in players:
        await interaction.response.send_message("❌ Create a character first with `/create`!", ephemeral=True)
        return
    player = players[uid]
    ok, msg = npc_eng.bank_withdraw(uid, player, amount)
    if ok:
        save_players(players)
    await interaction.response.send_message(f"{'✅' if ok else '❌'} {msg}")


@bank_group.command(name="transfer", description="Transfer gold from your bank account to another player's bank account.")
@app_commands.describe(recipient="The player to send gold to.", amount="Amount to transfer.")
async def bank_transfer_cmd(interaction: discord.Interaction, recipient: discord.Member, amount: int):
    from_uid = str(interaction.user.id)
    to_uid   = str(recipient.id)
    if from_uid == to_uid:
        await interaction.response.send_message("❌ You can't transfer gold to yourself.", ephemeral=True)
        return
    ok, msg = npc_eng.bank_transfer(from_uid, to_uid, amount)
    if ok:
        await interaction.response.send_message(f"✅ {msg} → Sent to **{recipient.display_name}**.")
    else:
        await interaction.response.send_message(f"❌ {msg}", ephemeral=True)


# ── /mount ────────────────────────────────────────────────────────────────────

mount_group = app_commands.Group(name="mount", description="Mount system — browse, buy, and equip mounts from Garron's Stables.")
tree.add_command(mount_group)


@mount_group.command(name="list", description="View the full mount catalogue and your owned mounts.")
async def mount_list(interaction: discord.Interaction):
    uid    = str(interaction.user.id)
    mounts = npc_eng.get_player_mounts(uid)
    owned  = mounts.get("owned", [])
    active = mounts.get("active")

    embed = discord.Embed(
        title="🐎 Aetheria Mount Catalogue",
        description="Available at **Garron's Royal Stables** — Valoria",
        color=0x8D6E63,
    )
    for name, m in npc_eng.MOUNT_REGISTRY.items():
        if name == active:
            status = "🟢 **Equipped**"
        elif name in owned:
            status = "✅ Owned"
        else:
            req    = f"  •  Req Lv **{m['level_req']}**" if m.get("level_req", 1) > 1 else ""
            status = f"🪙 **{m['gold']:,}**{req}"
        bonus_parts = []
        if m.get("bonus_xp"):   bonus_parts.append(f"+{m['bonus_xp']}% XP")
        if m.get("bonus_gold"): bonus_parts.append(f"+{m['bonus_gold']}% Gold")
        bonus_str = f"  •  {' / '.join(bonus_parts)}" if bonus_parts else ""
        embed.add_field(
            name=f"{m['emoji']} {name}",
            value=f"{m['desc']}{bonus_str}\n{status}",
            inline=False,
        )
    embed.set_footer(text="/mount buy <name>  •  /mount equip <name>  •  /talk garron to visit the stables")
    await interaction.response.send_message(embed=embed)


async def _mount_ac(interaction: discord.Interaction, current: str):
    return [
        app_commands.Choice(name=f"{m['emoji']} {name}", value=name)
        for name, m in npc_eng.MOUNT_REGISTRY.items()
        if current.lower() in name.lower()
    ][:25]


@mount_group.command(name="buy", description="Purchase a mount from Garron's Royal Stables.")
@app_commands.describe(mount="The mount to purchase.")
@app_commands.autocomplete(mount=_mount_ac)
async def mount_buy_cmd(interaction: discord.Interaction, mount: str):
    uid     = str(interaction.user.id)
    players = load_players()
    if uid not in players:
        await interaction.response.send_message("❌ Create a character first with `/create`!", ephemeral=True)
        return
    player = players[uid]
    ok, msg = npc_eng.buy_mount(uid, mount, player)
    if ok:
        save_players(players)
        m     = npc_eng.MOUNT_REGISTRY.get(mount, {})
        embed = discord.Embed(
            title=f"{m.get('emoji', '🐎')} Mount Purchased!",
            description=msg,
            color=0x8D6E63,
        )
        embed.set_footer(text="Use /mount equip to switch your active mount  •  Bonuses apply on /daily")
        await interaction.response.send_message(embed=embed)
    else:
        await interaction.response.send_message(f"❌ {msg}", ephemeral=True)


@mount_group.command(name="equip", description="Equip one of your owned mounts.")
@app_commands.describe(mount="The mount to make active.")
@app_commands.autocomplete(mount=_mount_ac)
async def mount_equip_cmd(interaction: discord.Interaction, mount: str):
    uid = str(interaction.user.id)
    ok, msg = npc_eng.equip_mount(uid, mount)
    if ok:
        m = npc_eng.MOUNT_REGISTRY.get(mount, {})
        await interaction.response.send_message(
            f"🐎 {msg}\n*{m.get('desc', '')}*\nMount bonuses apply on your next `/daily`."
        )
    else:
        await interaction.response.send_message(f"❌ {msg}", ephemeral=True)


# ── Events ─────────────────────────────────────────────────────────────────────

@tree.command(name="setup", description="Initialize Aetheria Online: create channels, categories and data files. Administrator only.")
@app_commands.default_permissions(administrator=True)
async def cmd_setup(interaction: discord.Interaction):
    if not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message("This command only works inside a server.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild
    log_lines: list[str] = []

    # ── 1. Category ────────────────────────────────────────────────────────
    category_name = "🌍 AETHERIA SYSTEM"
    category = discord.utils.get(guild.categories, name=category_name)
    if category is None:
        try:
            category = await guild.create_category(category_name)
            log_lines.append(f"✅ Created category **{category_name}**")
        except discord.Forbidden:
            log_lines.append(f"❌ Missing permission to create category — grant **Manage Channels**")
            category = None
    else:
        log_lines.append(f"ℹ️ Category **{category_name}** already exists")

    # ── 2. Channels ────────────────────────────────────────────────────────
    required_channels = [
        CHRONICLE_CHANNEL,           # weltchronik
        SHEET_CHANNEL,               # charakter-blaetter
        GUILD_QUEST_CHANNEL,         # quests
        ANNOUNCEMENTS_CHANNEL,       # welt-events
    ]
    channels_created: dict[str, discord.TextChannel] = {}
    for ch_name in required_channels:
        ch = discord.utils.get(guild.text_channels, name=ch_name)
        if ch is None:
            try:
                kwargs: dict = {}
                if category:
                    kwargs["category"] = category
                ch = await guild.create_text_channel(ch_name, **kwargs)
                log_lines.append(f"✅ Created **#{ch_name}**")
            except discord.Forbidden:
                log_lines.append(f"❌ Cannot create **#{ch_name}** — missing Manage Channels permission")
                continue
        else:
            if category and ch.category != category:
                try:
                    await ch.edit(category=category)
                    log_lines.append(f"↔️  Moved **#{ch_name}** into category")
                except discord.Forbidden:
                    log_lines.append(f"⚠️  Cannot move **#{ch_name}** — missing Manage Channels permission")
            else:
                log_lines.append(f"ℹ️ **#{ch_name}** already exists")
        channels_created[ch_name] = ch

    # ── 3. Data files ──────────────────────────────────────────────────────
    (Path(__file__).parent / "data").mkdir(parents=True, exist_ok=True)

    if not DATA_FILE.exists():
        save_players({})
        log_lines.append("✅ Created **players.json**")
    else:
        log_lines.append("ℹ️ **players.json** already exists")

    if not se.WORLD_STATE_FILE.exists():
        se.save_world_state(dict(se.DEFAULT_WORLD_STATE))
        log_lines.append("✅ Created **world_state.json** with default world state")
    else:
        log_lines.append("ℹ️ **world_state.json** already exists")

    if not se.STORY_FILE.exists():
        se.save_story_history([])
        log_lines.append("✅ Created **story_history.json**")
    else:
        log_lines.append("ℹ️ **story_history.json** already exists")

    if not se.CHRONICLE_FILE.exists():
        se.save_chronicle([])
        log_lines.append("✅ Created **chronicle.json**")
    else:
        log_lines.append("ℹ️ **chronicle.json** already exists")

    # ── 4. First chronicle entry ───────────────────────────────────────────
    weltchronik = channels_created.get(CHRONICLE_CHANNEL)
    if weltchronik:
        history = [m async for m in weltchronik.history(limit=1)]
        if not history:
            first_embed = discord.Embed(
                title="📜 The Chronicle of Aetheria Has Begun",
                description=(
                    "The actions of players will shape the future of this world.\n\n"
                    "*Every boss slain, every city taken, every legend born — "
                    "it will be recorded here.*"
                ),
                color=0xFFD700,
            )
            first_embed.set_footer(
                text=f"Aetheria Online • Chronicle begins "
                     f"{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')} UTC"
            )
            await weltchronik.send(embed=first_embed)
            se.log_chronicle("custom", "The Chronicle of Aetheria has begun.")
            log_lines.append("✅ Posted first chronicle entry in **#weltchronik**")

        # ── 5. World state summary ─────────────────────────────────────────
        ws = se.load_world_state()
        ws_embed = discord.Embed(
            title="🌍 Aetheria — Current World State",
            color=0x1565C0,
        )
        ws_embed.add_field(
            name="📅 Current Age",
            value=ws.get("current_age", "Age of Heroes"),
            inline=True,
        )
        ws_embed.add_field(
            name="👑 Ruler of Valoria",
            value=ws.get("ruler_valoria") or "*Vacant*",
            inline=True,
        )
        ws_embed.add_field(
            name="👑 Ruler of Umbra",
            value=ws.get("ruler_umbra") or "*Vacant*",
            inline=True,
        )
        alive = "\n".join(ws.get("alive_bosses", [])) or "*None*"
        dead  = "\n".join(ws.get("dead_bosses",  [])) or "*None*"
        ws_embed.add_field(name="🐉 Alive World Bosses",  value=alive, inline=True)
        ws_embed.add_field(name="💀 Slain World Bosses",  value=dead,  inline=True)
        ws_embed.set_footer(text="Aetheria Online • World State")
        await weltchronik.send(embed=ws_embed)
        log_lines.append("✅ Posted world state in **#weltchronik**")

    # ── Summary ────────────────────────────────────────────────────────────
    summary = discord.Embed(
        title="✅  Aetheria Setup Complete",
        description="\n".join(log_lines),
        color=0x4CAF50,
    )
    summary.set_footer(text="Aetheria Online • /setup")
    await interaction.followup.send(embed=summary, ephemeral=True)


@bot.event
async def on_ready():
    await tree.sync()
    print(f"[Aetheria] Logged in as {bot.user} (ID: {bot.user.id})")
    print(f"[Aetheria] Slash commands synced and ready.")
    await bot.change_presence(
        activity=discord.Activity(type=discord.ActivityType.playing, name="Aetheria Online | /create")
    )
    if not world_event_loop.is_running():
        world_event_loop.start()
    print(f"[Aetheria] World event loop started. First event in ~{_EVENT_INTERVAL_MIN} min.")

# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    token = os.environ.get("DISCORD_TOKEN")
    if not token:
        raise RuntimeError("DISCORD_TOKEN environment variable is not set.")
    bot.run(token)
