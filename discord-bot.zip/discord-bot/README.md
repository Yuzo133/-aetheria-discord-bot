# Aetheria Online — Discord RPG Bot

A Discord slash-command RPG bot built with discord.py.

## Commands

| Command | Description |
|---------|-------------|
| `/start` | Create your hero and begin your journey |
| `/profile [user]` | View your stats (or another player's) |
| `/daily` | Claim your daily XP + gold reward (24h cooldown) |

## Leveling System

- Level cap: **100**
- XP scales 15% per level (level 1 needs 100 XP, level 2 needs 115 XP, etc.)
- Daily rewards: **30–80 XP** and **50–200 gold**

## Tier Badges

| Level Range | Tier |
|-------------|------|
| 1–19 | Common |
| 20–44 | Uncommon |
| 45–69 | Rare |
| 70–89 | Epic |
| 90–100 | Legendary |

## Data

Player data is stored in `data/players.json` as a JSON object keyed by Discord user ID.

## Setup

1. Set `DISCORD_TOKEN` in Replit Secrets
2. Invite your bot with `applications.commands` + `bot` scopes
3. Run `python discord-bot/bot.py`
