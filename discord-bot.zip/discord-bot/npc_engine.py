"""
Aetheria NPC Engine
===================
NPC definitions, dialogue (world-reactive), reputation, dynamic stock,
bank system, and mount system. No LLM required — template-driven.

Import this as:  import npc_engine as npc_eng
"""

import json
import random
from datetime import datetime, timezone, date
from pathlib import Path

NPC_DB_FILE = Path(__file__).parent / "data" / "npc_database.json"

# ── Persistence ──────────────────────────────────────────────────────────────

def load_npc_db() -> dict:
    if NPC_DB_FILE.exists():
        with open(NPC_DB_FILE) as f:
            return json.load(f)
    return {"stock": {}, "reputation": {}, "bank": {}, "mounts": {}}

def save_npc_db(data: dict) -> None:
    NPC_DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(NPC_DB_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# ── NPC Registry ─────────────────────────────────────────────────────────────

NPC_REGISTRY: dict[str, dict] = {

    # ── MERCHANTS ──────────────────────────────────────────────────────────
    "arkon": {
        "id": "arkon", "name": "Arkon the Merchant", "type": "merchant",
        "emoji": "🏪", "location": "Valoria — Market Square", "faction": "Valoria",
        "description": "A portly merchant with a silver tongue and a nose for rare goods. Thirty years in the Valorian market have made him indispensable.",
        "greetings": [
            "Ah, {name}! Business calls, does it? You've come to the right stall.",
            "Welcome, welcome! I have just what you need — whatever that may be.",
            "A traveller! Excellent. My goods are the finest in all of Aetheria.",
        ],
        "base_stock": {
            "Health Potion":      {"price": 80,  "qty": 10},
            "Mana Potion":        {"price": 90,  "qty": 8},
            "Elixir of Fortune":  {"price": 350, "qty": 3},
        },
        "rare_stock": [
            ("Ancient Rune",            0.25, 240),
            ("Shadow Essence",          0.15, 380),
            ("Dragon Scale Fragment",   0.12, 580),
            ("Philosopher's Stone Shard", 0.04, 2000),
        ],
        "sell_ratio": 0.45,
    },
    "selene": {
        "id": "selene", "name": "Selene the Trader", "type": "merchant",
        "emoji": "🏪", "location": "Sylvandor — Forest Edge", "faction": "Sylvandor",
        "description": "An elven trader with ancient knowledge of magical reagents. She trades only with those who have earned her trust.",
        "greetings": [
            "The forest hears your footsteps, {name}. State your needs.",
            "Few reach my stall without purpose. What do you seek?",
            "I trade in things of power. Are you ready for that?",
        ],
        "base_stock": {
            "Mana Potion":    {"price": 85,  "qty": 12},
            "Ancient Rune":   {"price": 220, "qty": 5},
            "Shadow Essence": {"price": 380, "qty": 4},
        },
        "rare_stock": [
            ("Elixir of Fortune",  0.25, 290),
            ("Crystal of Eternity", 0.06, 3000),
            ("Dragon Scale Fragment", 0.14, 520),
        ],
        "sell_ratio": 0.50,
    },
    "borik": {
        "id": "borik", "name": "Borik the Traveling Merchant", "type": "merchant",
        "emoji": "🛒", "location": "Wandering — currently near the Crossroads", "faction": "Neutral",
        "description": "A dwarven merchant who travels every road in Aetheria. His cart always has something unusual.",
        "greetings": [
            "Ho there! Caught me at a good time — just restocked from the eastern markets!",
            "Come, come! Borik has something for everyone!",
            "The road is long but the goods are worth it! What d'you need?",
        ],
        "base_stock": {
            "Health Potion":         {"price": 75, "qty": 15},
            "Mana Potion":           {"price": 80, "qty": 10},
            "Dragon Scale Fragment": {"price": 540, "qty": 2},
        },
        "rare_stock": [
            ("Ancient Rune",         0.30, 200),
            ("Elixir of Fortune",    0.20, 270),
            ("Shadow Essence",       0.12, 400),
            ("Void Shard",           0.06, 1400),
        ],
        "sell_ratio": 0.40,
    },

    # ── INNKEEPERS ─────────────────────────────────────────────────────────
    "borin_inn": {
        "id": "borin_inn", "name": "Borin of the Golden Dragon Inn", "type": "innkeeper",
        "emoji": "🍺", "location": "Valoria — Golden Dragon Inn", "faction": "Valoria",
        "description": "A stout, jovial innkeeper who knows every rumour worth knowing. His ale is the best in Valoria.",
        "greetings": [
            "Welcome to the Golden Dragon, {name}! Pull up a chair!",
            "Ahh, {name}! The usual? Or are ye after information today?",
            "The fire's warm and the ale is cold, {name}. Sit down!",
        ],
        "rumors": [
            "A traveling knight swore the northern pass is being patrolled by something unnatural.",
            "A merchant came through yesterday claiming he saw lights in the old ruins east of here.",
            "The King's tax collectors have been disappearing on the southern road. Nobody's asking questions.",
            "They say the Void is stirring again. I don't know what that means, but I don't like the sound of it.",
            "Heard there's a new guild forming. Ambitious folk. Could be trouble.",
            "A cloaked figure was asking about you in here last night, {name}. Left before I could get a name.",
        ],
    },
    "elara": {
        "id": "elara", "name": "Elara of the Silver Moon Tavern", "type": "innkeeper",
        "emoji": "🌙", "location": "Umbra — Silver Moon Tavern", "faction": "Umbra",
        "description": "A sharp-eyed woman who runs the most popular tavern in the shadow city. She knows things she shouldn't.",
        "greetings": [
            "You look like you've seen better days, {name}. Sit. Drink.",
            "Another wanderer seeks the Silver Moon's warmth. Welcome, {name}.",
            "I don't ask questions. I just pour drinks. But I listen. Sit down.",
        ],
        "rumors": [
            "Someone's buying up all the shadow ore. They're paying five times market price. Nobody knows why.",
            "A figure in black passed through last week — left a gold coin for every person they spoke to. No name.",
            "The old temple on the hill has been occupied. The locals won't say by what.",
            "I heard the Necromancer's Guild is recruiting. Quietly, of course.",
            "Three separate travelers came through claiming to have the same dream. I don't believe in coincidences.",
        ],
    },

    # ── BLACKSMITHS ────────────────────────────────────────────────────────
    "durak": {
        "id": "durak", "name": "Durak Ironhammer", "type": "blacksmith",
        "emoji": "⚒️", "location": "Valoria — Ironhammer Forge", "faction": "Valoria",
        "description": "A master dwarven blacksmith whose family has worked this forge for three generations.",
        "greetings": [
            "The forge burns bright today, {name}. What do you need made?",
            "Ye've got good timing — I've just the right materials in. What can Durak do for ye?",
            "Quality work takes time. Tell me what you need.",
        ],
        "recipes": {
            "Iron Shield":       {"mats": {"Dragon Scale Fragment": 2}, "gold": 500, "desc": "A sturdy shield crafted from dragon scales."},
            "Shadow Blade":      {"mats": {"Shadow Essence": 3, "Ancient Rune": 1}, "gold": 800, "desc": "A blade that drinks shadow."},
            "Rune-Carved Armor": {"mats": {"Ancient Rune": 4, "Dragon Scale Fragment": 3}, "gold": 1200, "desc": "Armour etched with protective runes."},
            "Stormforged Axe":   {"mats": {"Dragon Scale Fragment": 5}, "gold": 1000, "desc": "An axe that crackles with static."},
        },
        "legendary_recipes": {
            "Void Reaper": {
                "mats": {"Shadow Essence": 5, "Dragon Scale Fragment": 5, "Ancient Rune": 5},
                "gold": 5000, "level_req": 50,
                "desc": "A legendary blade said to tear the fabric of reality.",
            },
            "Titan's Aegis": {
                "mats": {"Dragon Scale Fragment": 10, "Ancient Rune": 3},
                "gold": 8000, "level_req": 70,
                "desc": "The shield of a titan, rebuilt from fragments.",
            },
        },
    },
    "valen": {
        "id": "valen", "name": "Valen Steelborn", "type": "blacksmith",
        "emoji": "⚒️", "location": "Khaz-Dur — The Deep Forge", "faction": "Khaz-Dur",
        "description": "A half-giant blacksmith who works only the rarest metals, deep in the dwarven mountains.",
        "greetings": [
            "I don't make ordinary things, {name}. If you want quality, you've found it.",
            "The Deep Forge has burned for a thousand years. Step close — what do you need?",
            "Few find the Deep Forge. Fewer leave empty-handed. Speak.",
        ],
        "recipes": {
            "Deepstone Gauntlets": {"mats": {"Ancient Rune": 2, "Dragon Scale Fragment": 2}, "gold": 600, "desc": "Gauntlets carved from deepstone."},
            "Bloodsteel Sword":    {"mats": {"Shadow Essence": 2, "Dragon Scale Fragment": 3}, "gold": 900, "desc": "Forged in the blood of warriors past."},
        },
        "legendary_recipes": {
            "Heartstone Hammer": {
                "mats": {"Dragon Scale Fragment": 8, "Ancient Rune": 6, "Shadow Essence": 4},
                "gold": 7000, "level_req": 60,
                "desc": "The ancestral weapon of the Deep Kings.",
            },
        },
    },

    # ── QUEST GIVERS ───────────────────────────────────────────────────────
    "roderik": {
        "id": "roderik", "name": "Captain Roderik", "type": "quest_giver",
        "emoji": "📋", "location": "Valoria — City Gate", "faction": "Valoria",
        "description": "A grizzled captain of the Valorian Guard who hands out field assignments to proven adventurers.",
        "greetings": [
            "Adventurer! The city needs capable hands. Head to #quests for available assignments.",
            "{name}. Good timing. We're short on field agents today — check #quests.",
            "I don't waste time on pleasantries. The assignments are posted in #quests.",
        ],
    },
    "lyra": {
        "id": "lyra", "name": "Ranger Lyra", "type": "quest_giver",
        "emoji": "🏹", "location": "Sylvandor — Forest Watch Post", "faction": "Sylvandor",
        "description": "A master ranger who scouts the borderlands and assigns patrol missions to trustworthy heroes.",
        "greetings": [
            "The forest is not safe, {name}. Will you help protect it? Check #quests.",
            "I've been tracking something disturbing. I need another set of eyes. See #quests.",
            "Quiet — you'll startle the wildlife. Your mission is in #quests.",
        ],
    },
    "eldrin_q": {
        "id": "eldrin_q", "name": "Scholar Eldrin", "type": "quest_giver",
        "emoji": "📚", "location": "Seraphis — The Grand Library", "faction": "Seraphis",
        "description": "An ancient scholar who sends adventurers on research expeditions into dangerous ruins.",
        "greetings": [
            "Ah, {name}! I was hoping someone capable would come by. See #quests for my current needs.",
            "Knowledge must be recovered at any cost. Check #quests for my research tasks.",
            "The archives are incomplete. You could help me change that — see #quests.",
        ],
    },

    # ── MAGE MASTERS ───────────────────────────────────────────────────────
    "eldor": {
        "id": "eldor", "name": "Archmage Eldor", "type": "mage_master",
        "emoji": "🔮", "location": "Seraphis — Tower of Aeons", "faction": "Seraphis",
        "description": "The oldest living archmage in Aetheria. He teaches only those who prove worthy.",
        "greetings": [
            "You have come seeking power. Let us see if you deserve it, {name}.",
            "Magic is not given — it is earned. Are you prepared to earn it?",
            "The arcane arts are not a toy. Step forward, {name}, and we will see.",
        ],
        "training": {
            "Arcane Surge":   {"gold": 1000, "level_req": 20, "desc": "+10 MAG permanently.",   "bonus": {"mag": 10}},
            "Iron Skin Rune": {"gold": 1200, "level_req": 25, "desc": "+8 DEF permanently.",    "bonus": {"def": 8}},
            "Shadow Step":    {"gold": 1500, "level_req": 30, "desc": "+12 AGI permanently.",   "bonus": {"agi": 12}},
            "Berserker's Oath": {"gold": 2000, "level_req": 40, "desc": "+15 STR permanently.", "bonus": {"str": 15}},
            "Void Mastery":   {"gold": 5000, "level_req": 60, "desc": "+25 MAG permanently. Requires Arcane Surge.", "bonus": {"mag": 25}, "requires": "Arcane Surge"},
        },
    },
    "selara": {
        "id": "selara", "name": "Mystic Selara", "type": "mage_master",
        "emoji": "🌟", "location": "Sylvandor — The Spirit Grove", "faction": "Sylvandor",
        "description": "A spirit-bonded mystic who teaches nature magic and elemental harmony.",
        "greetings": [
            "The spirits speak of you, {name}. They are... cautiously optimistic.",
            "You seek the old magic. Good. Sit down and clear your mind.",
            "Nature does not rush. Neither will your training. Welcome, {name}.",
        ],
        "training": {
            "Nature's Veil": {"gold": 800,  "level_req": 15, "desc": "+8 AGI and +8 DEF permanently.", "bonus": {"agi": 8, "def": 8}},
            "Spirit Bond":   {"gold": 1000, "level_req": 20, "desc": "+10 MAG permanently.",           "bonus": {"mag": 10}},
            "Earthen Fury":  {"gold": 2500, "level_req": 35, "desc": "+18 STR permanently.",           "bonus": {"str": 18}},
        },
    },

    # ── STABLE MASTER ──────────────────────────────────────────────────────
    "garron": {
        "id": "garron", "name": "Garron Horsekeeper", "type": "stable_master",
        "emoji": "🐎", "location": "Valoria — Royal Stables", "faction": "Valoria",
        "description": "The royal stable master who breeds and sells the finest mounts in Aetheria.",
        "greetings": [
            "Aye, {name}! Looking for a fine mount today?",
            "The horses are well-rested and ready for riders. What'll it be, {name}?",
            "A hero without a mount is just a very tired person. Let's fix that, {name}.",
        ],
        "mounts": {
            "Ironhoof Stallion": {"gold": 2000,  "emoji": "🐴", "level_req": 1,  "desc": "A powerful warhorse bred for battle. +10% XP bonus."},
            "Shadow Mare":       {"gold": 5000,  "emoji": "🖤", "level_req": 30, "desc": "A dark-coated mare that vanishes in low light. +20% gold bonus."},
            "Storm Drake":       {"gold": 15000, "emoji": "⚡", "level_req": 60, "desc": "A young wingless drake — blindingly fast. +15% XP and gold.", "bonus_xp": 15, "bonus_gold": 15},
            "Celestial Steed":   {"gold": 50000, "emoji": "✨", "level_req": 80, "desc": "A luminous horse from the celestial plane. +25% XP and gold.", "bonus_xp": 25, "bonus_gold": 25},
        },
    },

    # ── BANKER ─────────────────────────────────────────────────────────────
    "vesper": {
        "id": "vesper", "name": "Vesper — Royal Bank of Valoria", "type": "banker",
        "emoji": "🏦", "location": "Valoria — Royal Bank", "faction": "Valoria",
        "description": "Chief cashier of the Royal Bank of Valoria. His ledgers are perfect; his patience is not.",
        "greetings": [
            "Welcome to the Royal Bank of Valoria, {name}. Your funds are safe here.",
            "Ah, {name}. I see your account balance is... let us discuss that.",
            "The Bank has stood five hundred years. Your gold is in good hands, {name}.",
        ],
        "daily_interest_pct": 2,
    },

    # ── GUILD MASTER NPC ───────────────────────────────────────────────────
    "thorn": {
        "id": "thorn", "name": "Guildmaster Thorn", "type": "guild_master_npc",
        "emoji": "🏛️", "location": "Valoria — Guild Hall", "faction": "Neutral",
        "description": "The neutral arbiter of all guild affairs. He has recorded a thousand guild rises and falls.",
        "greetings": [
            "Another guild seeker. Hmm. What do you want, {name}?",
            "The Guild Hall is neutral ground, {name}. Leave your feuds at the door.",
            "I've seen a thousand guilds rise and fall. Why will yours be different, {name}?",
        ],
    },

    # ── FACTION LEADERS ────────────────────────────────────────────────────
    "alaric": {
        "id": "alaric", "name": "King Alaric", "type": "faction_leader",
        "emoji": "👑", "location": "Valoria — Royal Palace", "faction": "Valoria", "realm": "Valoria",
        "replaceable": True,
        "description": "The king of Valoria, ruler of the most powerful human kingdom in Aetheria.",
        "greetings": [
            "Rise, {name}. I have heard of your deeds. Valoria has need of heroes.",
            "The crown is heavy. But heavier still is the knowledge of what threatens this kingdom.",
            "I do not grant audiences lightly. You have earned this one, {name}.",
        ],
    },
    "elyndra": {
        "id": "elyndra", "name": "Lady Elyndra", "type": "faction_leader",
        "emoji": "🌿", "location": "Sylvandor — The Canopy Throne", "faction": "Sylvandor", "realm": "Sylvandor",
        "replaceable": True,
        "description": "The ancient elven lady who has governed Sylvandor for four hundred years.",
        "greetings": [
            "The forest brought you to me, {name}. That means something.",
            "I have governed this land since before your grandparents were born. Choose your words carefully.",
            "Sylvandor welcomes those who respect it. Are you such a person, {name}?",
        ],
    },
    "thrain": {
        "id": "thrain", "name": "High King Thrain", "type": "faction_leader",
        "emoji": "⛏️", "location": "Khaz-Dur — The Deep Throne", "faction": "Khaz-Dur", "realm": "Khaz-Dur",
        "replaceable": True,
        "description": "The undefeated High King of the dwarven mountain kingdom of Khaz-Dur.",
        "greetings": [
            "Hmph. You've come a long way, {name}. Best make it worth your while.",
            "Khaz-Dur doesn't impress easily. But word of your deeds has reached even the Deep Throne.",
            "I respect strength. You have it, or you wouldn't be standing here.",
        ],
    },
    "vexar": {
        "id": "vexar", "name": "Lord Vexar", "type": "faction_leader",
        "emoji": "🌑", "location": "Umbra — Shadow Keep", "faction": "Umbra", "realm": "Umbra",
        "replaceable": True,
        "description": "The mysterious ruler of the shadow city of Umbra. His true nature remains unknown.",
        "greetings": [
            "You came to Umbra of your own will, {name}. Interesting. Most are brought here against theirs.",
            "I respect boldness. It is rarer than gold. What do you want?",
            "The shadows told me you were coming. I never ignore what the shadows say.",
        ],
    },
    "seraphiel": {
        "id": "seraphiel", "name": "Archangel Seraphiel", "type": "faction_leader",
        "emoji": "😇", "location": "Seraphis — The Celestial Spire", "faction": "Seraphis", "realm": "Seraphis",
        "replaceable": False,
        "description": "The divine ruler of Seraphis, a true celestial being.",
        "greetings": [
            "I have watched over Aetheria for a thousand years, {name}. I have watched you too.",
            "The light guides all who seek it sincerely. Welcome to Seraphis.",
            "You stand in the presence of the divine. Do not be afraid — I see hearts, not faces.",
        ],
    },
}

# Helper: all NPC names for autocomplete
NPC_NAMES: list[str] = sorted(npc["name"] for npc in NPC_REGISTRY.values())

def npc_by_name(query: str) -> dict | None:
    """Fuzzy find an NPC by partial name (case-insensitive)."""
    q = query.lower()
    for npc in NPC_REGISTRY.values():
        if q == npc["id"] or q in npc["name"].lower():
            return npc
    return None

def npc_autocomplete_choices(current: str) -> list[tuple[str, str]]:
    """Return (label, value=id) pairs matching current input."""
    results = []
    cur = current.lower()
    for nid, npc in NPC_REGISTRY.items():
        if cur in npc["name"].lower() or cur in nid:
            results.append((f"{npc['emoji']} {npc['name']} — {npc['location']}", nid))
    return results[:25]

# ── Reputation ───────────────────────────────────────────────────────────────

REP_MAX = 100
REP_MIN = -100

def get_reputation(uid: str, npc_id: str) -> int:
    db = load_npc_db()
    return db.get("reputation", {}).get(uid, {}).get(npc_id, 0)

def change_reputation(uid: str, npc_id: str, delta: int) -> int:
    db = load_npc_db()
    db.setdefault("reputation", {}).setdefault(uid, {})
    current = db["reputation"][uid].get(npc_id, 0)
    new_rep = max(REP_MIN, min(REP_MAX, current + delta))
    db["reputation"][uid][npc_id] = new_rep
    save_npc_db(db)
    return new_rep

def rep_bar(rep: int) -> str:
    filled = int(10 * (rep - REP_MIN) / (REP_MAX - REP_MIN))
    bar = "▰" * filled + "▱" * (10 - filled)
    if rep >= 60:   label = "Trusted"
    elif rep >= 20: label = "Friendly"
    elif rep >= -20: label = "Neutral"
    elif rep >= -60: label = "Unfriendly"
    else:            label = "Hostile"
    return f"`{bar}` {label} ({rep:+d})"

def price_with_rep(base_price: int, rep: int) -> int:
    """Reputation gives up to -10% (trusted) or +10% (hostile) on prices."""
    discount = rep / REP_MAX * 0.10
    return max(1, int(base_price * (1 - discount)))

# ── Dynamic Stock ────────────────────────────────────────────────────────────

def _today() -> str:
    return date.today().isoformat()

def get_npc_stock(npc: dict) -> dict[str, dict]:
    """Return today's stock for a merchant NPC, refreshing if a new day."""
    if npc["type"] not in ("merchant",):
        return {}

    db  = load_npc_db()
    nid = npc["id"]
    stock_entry = db.get("stock", {}).get(nid, {})

    if stock_entry.get("date") == _today():
        return stock_entry.get("items", {})

    # Build fresh stock for today
    items: dict[str, dict] = {}
    for item, info in npc.get("base_stock", {}).items():
        items[item] = {"price": info["price"], "qty": info["qty"]}

    # Roll rare stock
    for item, chance, price in npc.get("rare_stock", []):
        if random.random() < chance:
            items[item] = {"price": price, "qty": random.randint(1, 3)}

    db.setdefault("stock", {})[nid] = {"date": _today(), "items": items}
    save_npc_db(db)
    return items

def buy_from_npc(uid: str, npc: dict, item: str, qty: int = 1) -> tuple[bool, str, int]:
    """
    Attempt to buy `qty` of `item` from `npc`.
    Returns (success, message, total_cost).
    Caller must deduct gold from player dict and save.
    """
    db    = load_npc_db()
    nid   = npc["id"]
    stock = db.get("stock", {}).get(nid, {}).get("items", {})

    if item not in stock:
        return False, f"**{npc['name']}** doesn't have **{item}** in stock today.", 0
    if stock[item]["qty"] < qty:
        return False, f"Not enough stock — only **{stock[item]['qty']}** left.", 0

    rep   = get_reputation(uid, nid)
    price = price_with_rep(stock[item]["price"], rep) * qty

    stock[item]["qty"] -= qty
    if stock[item]["qty"] == 0:
        del stock[item]
    db["stock"][nid]["items"] = stock
    save_npc_db(db)
    change_reputation(uid, nid, 1)
    return True, f"Bought **{qty}× {item}** for 🪙 **{price:,}**.", price

def sell_to_npc(uid: str, npc: dict, item: str, qty: int = 1, base_price: int = 0) -> tuple[bool, str, int]:
    """
    Sell `qty` of `item` to `npc`.
    Returns (success, message, gold_earned).
    Caller must remove item from inventory and add gold, then save.
    """
    sell_ratio = npc.get("sell_ratio", 0.40)
    rep        = get_reputation(uid, npc["id"])
    rep_bonus  = rep / REP_MAX * 0.05   # up to +5% sell price from rep
    earned     = max(1, int(base_price * (sell_ratio + rep_bonus))) * qty

    change_reputation(uid, npc["id"], 1)
    return True, f"Sold **{qty}× {item}** for 🪙 **{earned:,}**.", earned

# ── Blacksmith Crafting ──────────────────────────────────────────────────────

def get_blacksmith_recipes(npc: dict, player: dict) -> list[dict]:
    """Return all recipes (standard + legendary) with can_craft status."""
    level = player.get("level", 1)
    inv   = player.get("inventory", {})
    gold  = player.get("gold", 0)
    out   = []

    def _check(name, recipe, legendary=False):
        mats_ok = all(inv.get(m, 0) >= qty for m, qty in recipe["mats"].items())
        lvl_ok  = level >= recipe.get("level_req", 1)
        gold_ok = gold >= recipe.get("gold", 0)
        out.append({
            "name":      name,
            "recipe":    recipe,
            "legendary": legendary,
            "can_craft": mats_ok and lvl_ok and gold_ok,
            "reason":    (
                "❌ Missing materials" if not mats_ok else
                f"❌ Requires Level {recipe.get('level_req', 1)}" if not lvl_ok else
                f"❌ Need 🪙 {recipe.get('gold', 0):,}" if not gold_ok else
                "✅ Ready"
            ),
        })

    for name, recipe in npc.get("recipes", {}).items():
        _check(name, recipe)
    for name, recipe in npc.get("legendary_recipes", {}).items():
        _check(name, recipe, legendary=True)
    return out

def craft_blacksmith_item(player: dict, npc: dict, item_name: str) -> tuple[bool, str]:
    """Deduct materials + gold, add item. Returns (success, message)."""
    recipes = {**npc.get("recipes", {}), **npc.get("legendary_recipes", {})}
    if item_name not in recipes:
        return False, "Unknown recipe."
    recipe = recipes[item_name]

    inv   = player.get("inventory", {})
    level = player.get("level", 1)
    gold  = player.get("gold", 0)

    if level < recipe.get("level_req", 1):
        return False, f"You need Level {recipe['level_req']} to forge **{item_name}**."
    cost = recipe.get("gold", 0)
    if gold < cost:
        return False, f"You need 🪙 **{cost:,}** to forge **{item_name}** (you have 🪙 **{gold:,}**)."
    for mat, qty in recipe["mats"].items():
        if inv.get(mat, 0) < qty:
            return False, f"Missing materials: need {qty}× **{mat}**."

    # Deduct
    for mat, qty in recipe["mats"].items():
        inv[mat] -= qty
        if inv[mat] == 0:
            del inv[mat]
    player["gold"]    -= cost
    player["inventory"] = inv
    player.setdefault("inventory", {})[item_name] = player.get("inventory", {}).get(item_name, 0) + 1
    return True, f"Forged **{item_name}** successfully! 🪙 -{cost:,} spent."

# ── Mage Master Training ─────────────────────────────────────────────────────

def get_training_options(npc: dict, player: dict) -> list[dict]:
    """Return training abilities with can_train status for this player."""
    level     = player.get("level", 1)
    gold      = player.get("gold", 0)
    abilities = player.get("abilities", [])
    out       = []
    for name, t in npc.get("training", {}).items():
        already = name in abilities
        req     = t.get("requires")
        req_ok  = (req is None) or (req in abilities)
        lvl_ok  = level >= t.get("level_req", 1)
        gold_ok = gold  >= t.get("gold", 0)
        out.append({
            "name":     name,
            "training": t,
            "learned":  already,
            "can_learn": not already and req_ok and lvl_ok and gold_ok,
            "reason": (
                "✅ Already learned" if already else
                f"🔒 Requires {req}" if not req_ok else
                f"❌ Requires Level {t.get('level_req', 1)}" if not lvl_ok else
                f"❌ Need 🪙 {t.get('gold', 0):,}" if not gold_ok else
                "✅ Available"
            ),
        })
    return out

def learn_ability(player: dict, npc_id: str, ability_name: str, training: dict) -> tuple[bool, str]:
    """Deduct gold, add ability + stat bonuses. Caller saves player dict."""
    if ability_name in player.get("abilities", []):
        return False, f"You already know **{ability_name}**."
    if player["gold"] < training["gold"]:
        return False, f"Not enough gold. Need 🪙 **{training['gold']:,}**."

    player["gold"] -= training["gold"]
    player.setdefault("abilities", []).append(ability_name)
    tb = player.setdefault("train_bonuses", {"str": 0, "def": 0, "agi": 0, "mag": 0, "hp": 0})
    for stat, val in training["bonus"].items():
        tb[stat] = tb.get(stat, 0) + val
    return True, f"Learned **{ability_name}**! Stats permanently increased."

# ── Mount System ─────────────────────────────────────────────────────────────

MOUNT_REGISTRY = NPC_REGISTRY["garron"]["mounts"]

def get_player_mounts(uid: str) -> dict:
    db = load_npc_db()
    return db.get("mounts", {}).get(uid, {"owned": [], "active": None})

def buy_mount(uid: str, mount_name: str, player: dict) -> tuple[bool, str]:
    """Purchase a mount. Caller saves player + npc_db."""
    if mount_name not in MOUNT_REGISTRY:
        return False, "Unknown mount."
    mount = MOUNT_REGISTRY[mount_name]
    mounts = get_player_mounts(uid)
    if mount_name in mounts["owned"]:
        return False, f"You already own the **{mount_name}**."
    level = player.get("level", 1)
    if level < mount.get("level_req", 1):
        return False, f"Requires Level **{mount.get('level_req', 1)}**."
    if player["gold"] < mount["gold"]:
        return False, f"Not enough gold. Need 🪙 **{mount['gold']:,}**."

    player["gold"] -= mount["gold"]
    mounts["owned"].append(mount_name)
    if not mounts["active"]:
        mounts["active"] = mount_name

    db = load_npc_db()
    db.setdefault("mounts", {})[uid] = mounts
    save_npc_db(db)
    return True, f"You now own the **{mount['emoji']} {mount_name}**! {mount['desc']}"

def equip_mount(uid: str, mount_name: str) -> tuple[bool, str]:
    db = load_npc_db()
    mounts = db.get("mounts", {}).get(uid, {"owned": [], "active": None})
    if mount_name not in mounts["owned"]:
        return False, f"You don't own the **{mount_name}**."
    mounts["active"] = mount_name
    db.setdefault("mounts", {})[uid] = mounts
    save_npc_db(db)
    m = MOUNT_REGISTRY.get(mount_name, {})
    return True, f"Equipped **{m.get('emoji', '🐎')} {mount_name}**!"

def get_active_mount_bonuses(uid: str) -> dict:
    """Return {bonus_xp_pct, bonus_gold_pct} for the player's active mount."""
    mounts = get_player_mounts(uid)
    active = mounts.get("active")
    if not active or active not in MOUNT_REGISTRY:
        return {"bonus_xp": 0, "bonus_gold": 0}
    m = MOUNT_REGISTRY[active]
    return {"bonus_xp": m.get("bonus_xp", 0), "bonus_gold": m.get("bonus_gold", 0)}

# ── Bank System ──────────────────────────────────────────────────────────────

DAILY_INTEREST_PCT = 2   # 2% daily interest on bank balance

def get_bank_account(uid: str) -> dict:
    db = load_npc_db()
    return db.get("bank", {}).get(uid, {"balance": 0, "last_interest": None})

def _apply_bank_interest(uid: str) -> int:
    """Apply daily interest if a day has passed. Returns interest earned."""
    db  = load_npc_db()
    acc = db.get("bank", {}).get(uid, {"balance": 0, "last_interest": None})
    if acc["balance"] == 0:
        return 0
    today = _today()
    if acc.get("last_interest") == today:
        return 0
    interest = int(acc["balance"] * DAILY_INTEREST_PCT / 100)
    acc["balance"]       += interest
    acc["last_interest"]  = today
    db.setdefault("bank", {})[uid] = acc
    save_npc_db(db)
    return interest

def bank_deposit(uid: str, player: dict, amount: int) -> tuple[bool, str]:
    if amount <= 0:
        return False, "Amount must be positive."
    if player["gold"] < amount:
        return False, f"You only have 🪙 **{player['gold']:,}** on hand."
    db  = load_npc_db()
    acc = db.get("bank", {}).get(uid, {"balance": 0, "last_interest": None})
    player["gold"] -= amount
    acc["balance"] += amount
    db.setdefault("bank", {})[uid] = acc
    save_npc_db(db)
    return True, f"Deposited 🪙 **{amount:,}**. Bank balance: 🪙 **{acc['balance']:,}**."

def bank_withdraw(uid: str, player: dict, amount: int) -> tuple[bool, str]:
    if amount <= 0:
        return False, "Amount must be positive."
    db  = load_npc_db()
    acc = db.get("bank", {}).get(uid, {"balance": 0, "last_interest": None})
    if acc["balance"] < amount:
        return False, f"Your bank balance is only 🪙 **{acc['balance']:,}**."
    acc["balance"] -= amount
    player["gold"] += amount
    db.setdefault("bank", {})[uid] = acc
    save_npc_db(db)
    return True, f"Withdrew 🪙 **{amount:,}**. Bank balance: 🪙 **{acc['balance']:,}**."

def bank_transfer(from_uid: str, to_uid: str, amount: int) -> tuple[bool, str]:
    if amount <= 0:
        return False, "Amount must be positive."
    db    = load_npc_db()
    f_acc = db.get("bank", {}).get(from_uid, {"balance": 0})
    t_acc = db.get("bank", {}).get(to_uid,   {"balance": 0})
    if f_acc["balance"] < amount:
        return False, f"Your bank balance is only 🪙 **{f_acc['balance']:,}**."
    f_acc["balance"] -= amount
    t_acc["balance"] += amount
    db.setdefault("bank", {})[from_uid] = f_acc
    db.setdefault("bank", {})[to_uid]   = t_acc
    save_npc_db(db)
    return True, f"Transferred 🪙 **{amount:,}**. Your balance: 🪙 **{f_acc['balance']:,}**."

# ── World-Reactive Dialogue ──────────────────────────────────────────────────

def get_world_reaction(npc: dict, ws: dict) -> str | None:
    """Return a world-reactive line based on the current world state, or None."""
    ntype     = npc["type"]
    dead      = ws.get("dead_bosses", [])
    active_w  = ws.get("active_wars", [])
    val_ruler = ws.get("ruler_valoria") or "King Alaric"
    umbra_ruler = ws.get("ruler_umbra") or "Lord Vexar"

    reactions = []

    # Boss deaths
    if "Ignaroth" in dead and ntype in ("innkeeper", "merchant", "quest_giver"):
        reactions.append("🔥 They say Ignaroth is dead. The Ember Peaks have gone cold for the first time in centuries. My prices on fire-related goods have... adjusted accordingly.")
    if "Astralion" in dead and ntype in ("innkeeper", "mage_master"):
        reactions.append("⭐ Astralion slain. Scholars are still arguing about whether that's a good thing. The astral plane has gone quiet.")
    if "Umbryx" in dead and ntype == "innkeeper":
        reactions.append("🌑 The shadow over the Hollow Wastes finally lifted. People are emerging from their homes after three hundred years of darkness.")
    if "Glacerius" in dead and ntype in ("innkeeper", "merchant"):
        reactions.append("❄️ The northern blizzard died with Glacerius. The trade routes are opening up. Good for business.")
    if "Tempestus" in dead and ntype == "innkeeper":
        reactions.append("🌩️ The storm over the Stormspire is gone. Sailors are already adjusting their charts. A new age of exploration may be starting.")

    # Active wars
    for war in active_w:
        pa, pb = war.get("parties", ["?", "?"])
        reactions.append(f"⚔️ The war between **{pa}** and **{pb}** is on everyone's lips. I'd keep my head down if I were you.")

    # Ruler changes
    if ntype == "faction_leader":
        faction = npc.get("faction", "")
        if faction == "Valoria" and val_ruler not in (None, "King Alaric"):
            reactions.append(f"👑 Valoria bends the knee to **{val_ruler}** now. An... interesting development.")
        if faction == "Umbra" and umbra_ruler not in (None, "Lord Vexar"):
            reactions.append(f"🌑 **{umbra_ruler}** rules Umbra. The Shadow Keep has new masters.")

    if reactions:
        return random.choice(reactions)
    return None

def get_npc_greeting(npc: dict, player_name: str, ws: dict) -> str:
    """Return a formatted greeting with world context injected."""
    greeting = random.choice(npc["greetings"]).format(name=player_name)
    reaction = get_world_reaction(npc, ws)
    if reaction:
        return f"{greeting}\n\n*{reaction}*"
    return greeting

def get_innkeeper_rumor(npc: dict, ws: dict, player_name: str) -> str:
    """Return a rumor, with world-event rumors prioritised."""
    dead   = ws.get("dead_bosses", [])
    active = ws.get("active_wars", [])

    world_rumors = []
    if dead:
        world_rumors.append(f"Word is spreading fast — **{'** and **'.join(dead)}** {'has' if len(dead)==1 else 'have'} been slain. The balance of power in Aetheria shifts.")
    for war in active:
        pa, pb = war.get("parties", ["?", "?"])
        world_rumors.append(f"The war between **{pa}** and **{pb}** is pulling mercenaries from across the land. Coin is flowing, but so is blood.")

    base_rumors = [r.format(name=player_name) for r in npc.get("rumors", [])]
    pool = world_rumors + base_rumors
    return random.choice(pool) if pool else "Nothing unusual to report today."
